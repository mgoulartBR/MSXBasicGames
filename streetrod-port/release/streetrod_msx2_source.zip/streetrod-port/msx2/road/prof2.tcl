set throttle off
proc w {a} { return [expr {[peek $a] + 256 * [peek [expr {$a + 1}]]}] }
proc tap {row mask} { keymatrixdown $row $mask; after time 0.12 [list keymatrixup $row $mask] }
set ::last -1; set ::t1 0
proc hubkeys {} { if {[w 0xF014] == 7} { tap 8 0x01; after time 1.6 hubkeys } }
proc poll {} {
    set st [w 0xF014]
    if {$st != $::last} { set ::last $st
        switch $st { 9 { after time 1 { tap 8 0x01 } } 7 { after time 3 hubkeys } 1 { set ::t1 [machine_info time] } } }
    if {$st == 1 && [machine_info time] > $::t1 + 14} { set f [open $::env(OUT) w]; set l {}; for {set i 0} {$i<12} {incr i} { lappend l [w [expr {$::env(PA)+2*$i}]] }; puts $f $l; close $f; exit }
    after time 0.5 poll
}
after time 5 poll
after time 200 { exit }
