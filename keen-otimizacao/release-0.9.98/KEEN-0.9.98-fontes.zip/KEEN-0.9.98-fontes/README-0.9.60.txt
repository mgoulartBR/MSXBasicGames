Keen Dreams 0.9.60

Base de jogo: 0.9.56. Nova arte da tela de título sem traço, fornecida pelo usuário, convertida para SCREEN 7 (512 x 212, 16 cores RGB333), sem recorte. Mantido PRESS SPACE TO START.

A ROM foi gerada substituindo o recurso nos bancos 37 a 40 e atualizando os fingerprints de diagnóstico. Não foi necessário recompilar o código. Comparação binária confirmou que nenhum byte fora da arte e fingerprints mudou.

Validado em openMSX: pixels e paleta da tela; espera por Espaço e soltura; retorno ao SCREEN 5 e paleta do jogo; entrada em Bridge Bottoms.

Para regenerar a arte: python3 tools/build_title.py. O build existente inclui assets/title/screen7.bin no offset 0x94000, via src/project_config.js. Toolchain externa: MSXgl 1.5.2 e SDCC 4.6.
