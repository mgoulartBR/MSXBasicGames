Keen Dreams MSX - 0.9.61
Base: 0.9.60.

HUD
Painel turquesa de 72 x 32 pixels, bordas brancas, placar superior, capacete/vidas e flor/municao abaixo. Contadores sem zeros a esquerda. Placar ate 9.999.999; vidas ate 99; municao ate 65535 (fonte estreita acima de 999). No chefe, o contador de municao mostra bombas.
Redesenho separado por campo e por pagina. Os limites do ator HUD foram atualizados em todas as fases. Enderecamento circular de VRAM e alinhamento de meio byte para cameras em coordenadas impares. Nao requer nova paleta ou cache de texturas. Chaves/bombas fora do chefe permanecem no inventario; nao aparecem como letras extras no painel desta referencia.

AUDIO
Efeitos novos sintetizados no PSG interno, canal A. Salto normal, arremesso, coleta de municao/pontos, acerto em inimigos, chave em Melon Mines, vida extra por pontuacao, morte e conclusao de fase. Bombas arremessadas no chefe usam efeito proprio. Nao inclui trilha musical nem conversao dos sons originais do PC.
Atualizacao via H.TIMI; a rotina fica no banco fixo e preserva AF/BC/DE/HL, sem trocar bancos ou chamar bibliotecas dentro da interrupcao. O hook anterior e preservado. Duracoes ajustadas para 50/60 Hz. Prioridades impedem efeitos pequenos de cortar morte/conclusao. Bits de direcao I/O do PSG e mixer dos outros canais sao preservados.

VALIDACAO
ROM ASCII16 de 2 MiB, recursos e limites de bancos verificados. Dados globais/inicializados terminam em EFFD, abaixo do limite F000 estabelecido pelo projeto.
openMSX 19.1 / C-BIOS MSX2 e MSX2+: inicio, transicao do titulo para Tuberia, entrada em fase, HUD, salto, arremesso, consumo de municao e retorno do PSG ao silencio. WAV de aproximadamente quatro segundos capturado diretamente no emulador. Ainda precisa ser testada em hardware real.
A screenshot de referencia usa valores controlados 20700/8/29; a ROM continua iniciando com a campanha normal, 0 pontos e 3 vidas.

BUILD
MSXgl da mesma toolchain da base (commit ab4b26feda36189e677aa23b56acfdc3218f7953), SDCC incluso. Execute MSXGL_ROOT=/caminho/MSXgl bash scripts/build.sh. O build completo recompila os arquivos; o projeto inclui agora a fonte do core15 exigida pelo script original.
