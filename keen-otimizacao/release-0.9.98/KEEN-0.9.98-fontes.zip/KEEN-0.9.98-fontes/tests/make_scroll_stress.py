from pathlib import Path
import sys
p=Path(sys.argv[1]);s=(p/'build/game-test.tcl').read_text();s=s[:s.index('after time 10 {')]
s=s.replace(' screenshot -raw $::env(KEEN_TEST_OUTPUT)/$name.png','')
s+=r'''
set throttle off
proc stress {n} {
 if {$n==0} {keymatrixup 8 17;exit}
 if {$n%8==0} {keymatrixdown 8 1}
 if {$n%8==6} {keymatrixup 8 1}
 snap stress$n
 after time 0.25 [list stress [expr {$n-1}]]
}
after time 10 {keymatrixdown 8 16;after time 0.2 {stress 60}}
'''
(p/'build/scroll-stress.tcl').write_text(s)
