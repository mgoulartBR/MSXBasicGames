"""Differential execution of actual baseline/optimized Carrot C on the real map."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'build/logic-baseline/combat.c').read_text();ref=s[s.index('static void Carrot'):s.index('#include "inventory.c"')].replace('Carrot(void)','ReferenceCarrot(void)')
source='''#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdint.h>
#include "msxgl.h"
u16 test_map[5032];u8 test_props[1168];
#define GAME_MAP test_map
#define GAME_COLLISION test_props
#include "game.c"
#include "pickups.c"
#include "combat.c"
'''+ref+r'''
static uint32_t rng=271828;
static unsigned rnd(void){rng=rng*1664525u+1013904223u;return rng>>16;}
int main(int argc,char**argv){
 FILE*f=fopen(argv[1],"rb");assert(f&&fread(test_map,1,sizeof test_map,f)==sizeof test_map);fclose(f);
 f=fopen(argv[2],"rb");assert(f&&fread(test_props,1,sizeof test_props,f)==sizeof test_props);fclose(f);
 unsigned count=0,hits=0;
 for(unsigned scenario=0;scenario<2000;scenario++){
  Game_Reset();CombatReset();enemy.active=1;
  if(scenario){enemy.x=512+rnd()%33000;enemy.y=512+rnd()%8400;enemy.dir=rnd()&1;enemy.ground=rnd()&1;enemy.vy=(int)(rnd()%121)-40;enemy.tick=rnd()%5;enemy.frame=enemy.dir?21:16;}
  if(scenario%5==0){enemy.state=1;enemy.timer=1+rnd()%350;}
  for(unsigned t=0;t<700;t++){
   // Include discontinuities like the emulated visual-load fixture.
   if(scenario%7==0 && t%11==0){enemy.x=24000+rnd()%8000;enemy.y=6500+rnd()%1200;}
   CombatObject initial=enemy;u16 returns=flower_returns;
   ReferenceCarrot();CombatObject expected=enemy;u16 expected_returns=flower_returns;
   enemy=initial;flower_returns=returns;
   if(rest_valid && enemy.ground && enemy.state==0 && enemy.tick<4 && enemy.x==rest_x && enemy.y==rest_y && enemy.dir==rest_dir && enemy.vy==0)hits++;
   Carrot();
   if(memcmp(&enemy,&expected,sizeof enemy)||flower_returns!=expected_returns){
    printf("FAIL scenario=%u tick=%u old=(%u,%u) actual=(%u,%u,%u,%u) expected=(%u,%u,%u,%u)\n",scenario,t,initial.x,initial.y,enemy.x,enemy.y,enemy.dir,enemy.frame,expected.x,expected.y,expected.dir,expected.frame);return 1;
   }
   simulation_ticks++;count++;
  }
 }
 printf("PASS: %u actual C steps identical, %u cache-hit candidates; real map, both directions, slopes, walls, air, flower timers and discontinuities.\n",count,hits);
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'check.c').write_text(source)
 subprocess.run(['cc','-O2','-std=c99','-I'+str(root/'tests/host'),'-I'+str(root/'src'),str(p/'check.c'),'-o',str(p/'check')],check=True)
 subprocess.run([str(p/'check'),str(root/'assets/scene/map.bin'),str(root/'assets/scene/collision.bin')],check=True)
