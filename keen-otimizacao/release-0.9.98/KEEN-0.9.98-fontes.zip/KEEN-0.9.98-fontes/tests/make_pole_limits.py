from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/stage-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
after time 10 {
 debug write memory $enemy_mode 3
 place [expr {105*256-184}] [expr {28*256}];keymatrixdown 8 32
 after time 3 {set top_y [word $raw_player_y]}
 after time 3.5 {
  check {[byte $climbing] && [word $raw_player_y]==$top_y} "Stop at pole top"
  keymatrixdown 8 1
 }
 after time 3.6 {check {![byte $climbing]} "No instant regrab with Up held";keymatrixup 8 1;keymatrixup 8 32}
 after time 4.5 {place [expr {105*256-184}] [expr {28*256}];keymatrixdown 8 64}
 after time 6.5 {
  keymatrixup 8 64
  check {![byte $climbing] && [byte $grounded]} "Leave bottom and land"
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS pole top limit, jump regrab grace, slide off bottom and land.";close $f;exit
 }
}
'''
(r/'build/pole-limits.tcl').write_text(s)
