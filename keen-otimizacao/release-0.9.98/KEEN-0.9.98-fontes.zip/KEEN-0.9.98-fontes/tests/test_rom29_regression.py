"""Campaign and Bridge regression fixtures; these deliberately control test state."""
from pathlib import Path
import os,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
r=Path(__file__).resolve().parents[1]
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1')
boot='\n'+''.join(f'after time {t} {{keymatrixdown 8 1;after time 0.4 {{keymatrixup 8 1}}}}\n' for t in (25,30))
def run(case):
 kind,stage=case;out=r/'build'/f'0929-{kind}-{stage}';out.mkdir(exist_ok=True)
 generator=r/'tests'/('make_bridge29_enemy_test.py' if kind=='bridge_enemy' else f'make_{kind}_test.py');args=[sys.executable,str(generator),str(r),str(out/'test.tcl')]
 if kind=='campaign':args.append(str(stage))
 subprocess.run(args,check=True)
 s=(out/'test.tcl').read_text().replace('after time 3 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}','').replace('after time 10 {','after time 40 {',1).replace('after time 45 {','after time 120 {')+boot
 if kind=='campaign':
  a=s.index(' if {$::stage!=2} {');b=s.index('\n after time 3 restarted',a)
  s=s[:a]+''' keymatrixdown 4 128
 after time 2 {keymatrixup 4 128}
'''+s[b:]
  s=s.replace('after time 3 restarted','after time 5 restarted')
 (out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
 with (out/'emulator.log').open('w') as log:
  subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=dict(env,KEEN_TEST_OUTPUT=str(out)),stdout=log,stderr=log,timeout=150,check=True)
 assert not (out/'FAIL.txt').read_text().strip(),(case,(out/'FAIL.txt').read_text())
 result=(out/'PASS.txt').read_text();assert result.startswith('PASS:'),(case,result);print(result.strip(),flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,[('campaign',i) for i in (1,2,3)]+[('bridge_enemy',3)]))
