from pathlib import Path
import re,subprocess,os
root=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(root/'build/keen_msx.map').read_text(),re.M)}
for case,machine in [('plus','C-BIOS_MSX2+'),('ef','C-BIOS_MSX2+'),('plusram','C-BIOS_MSX2+'),('msx2','C-BIOS_MSX2'),('lowram','C-BIOS_MSX2+'),('badbank','C-BIOS_MSX2+')]:
 out=root/'build'/('0915-'+case);out.mkdir(exist_ok=True)
 rom=root/'build/keen_msx.rom'
 if case=='ef':
  b=bytearray(rom.read_bytes());b[:2]=b'EF';rom=out/'fault.rom';rom.write_bytes(b)
 if case=='badbank':
  b=bytearray(rom.read_bytes());b[20*16384]^=1;rom=out/'fault.rom';rom.write_bytes(b)
 script='''set throttle off
set save_settings_on_exit false
proc word {a} {expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {$n>>8}]}
proc space {} {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
proc finish {msg} {set f [open $::out/result.txt w];puts $f $msg;close $f;exit}
proc capture {} {screenshot $::out/boot.png;set f [open $::out/boot.vram wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f}
'''+f'set out {{{out}}}\n'
 if case=='ef':script+='after time 3 {debug write ioports 0xa8 [expr {([debug read ioports 0xa8]&0xc3)|0x14}];reg PC 0x401c}\n'
 if case=='lowram':script+='debug set_bp 0x401c {} {putword 0xfc4a 0xe600}\nafter time 25 {capture;finish "CAPTURE low RAM guard"}\n'
 elif case=='ef':
  b=bytearray(rom.read_bytes());b[:2]=b'EF';rom=out/'fault.rom';rom.write_bytes(b)
 if case=='badbank':script+='after time 25 {capture;finish "CAPTURE faulty bank guard"}\n'
 else:
  if case=='plusram':script+='after time 23 {keymatrixdown 3 32;after time 0.8 {keymatrixup 3 32}}\n'
  script+=f'''after time 25 {{capture;space}}
after time 28 {{space}}
after time 32 {{
 if {{[debug read memory {s['world_active']}]!=1}} {{finish "FAIL world"}}
 putword {s['world_x']} 608;putword {s['world_y']} 448;space
}}
after time 38 {{
 if {{[debug read memory {s['scene_ready']}]!=165 || [debug read memory {s['active_level']}]!=2}} {{finish "FAIL stage2"}}
 if {{[debug read memory {s['hot_enabled']}]!={1 if case=='plusram' else 0}}} {{finish "FAIL hot mode"}}
 set before [word {s['render_count']}]
}}
after time 40 {{
 if {{[word {s['render_count']}] == $before}} {{finish "FAIL stalled"}}
 finish "PASS diagnostic -> title -> Tuberia -> Melon Mines; render advances"
}}
'''
 (out/'test.tcl').write_text(script)
 env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=60,check=True)
 print(case,(out/'result.txt').read_text().strip(),flush=True)

 if case not in ["lowram","badbank"]:assert (out/"result.txt").read_text().startswith("PASS")
