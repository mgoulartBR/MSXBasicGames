from pathlib import Path
import re,sys,subprocess
r=Path(sys.argv[1]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
for t in ['game','world','keydoor']:subprocess.run([sys.executable,str(r/f'tests/make_{t}_test.py'),str(r)],check=True)
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+='\nset throttle on\nset fixture_frame 90\nset fixture_disabled 0\nset fixture_enabled 0\nset fixture_case 0\nset z80_freq 7159090\nset z80_freq_locked false\n'
s+=r'''
proc hw_fixture {} {
 if {!$::fixture_enabled} {return}
 debug write memory $::cpu_mode 4
 set t [expr {$::world_collision+1026}]
 putword $t [expr {([word $::camera_px]+32)*16}]
 putword [expr {$t+2}] [expr {([word $::camera_py]+64)*16}]
 debug write memory [expr {$t+8}] 1
 debug write memory [expr {$t+9}] $::fixture_frame
 for {set i 1} {$i<6} {incr i} {debug write memory [expr {$t+$i*13+8}] 0}
 debug write memory [expr {$::enemy+10}] 0
 debug write memory [expr {$::world_collision+1128}] $::fixture_disabled
}
proc hold {} {
 if {!$::fixture_enabled} {return}
 place [expr {1200+$::fixture_case*17}] [expr {160+$::fixture_case*45}]
 debug write memory $::enemy_mode 1
 debug write memory $::combat_dirty 1
 after time 0.03 hold
}
proc capture_hw {n} {
 if {[byte $::render_commit]} {after time 0.001 [list capture_hw $n];return}
 snap hw$n
 set f [open $::env(KEEN_TEST_OUTPUT)/hw$n.allvram wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/hw$n.regs wb];puts -nonewline $f [debug read_block "VDP regs" 0 64];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/hw$n.state wb];puts -nonewline $f [debug read_block memory [expr {$::world_collision+1128}] 10];close $f
 if {$n<15} {set ::fixture_case [expr {($n+1)/2}];set ::fixture_disabled [expr {($n+1)%2}];set ::fixture_frame [expr {90+(($n+1)/2)%4}];after time 0.5 [list capture_hw [expr {$n+1}]]} else {exit}
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2} "Melon loaded"
  set ::fixture_enabled 1;hold
  after time 1 {capture_hw 0}
 }
}
after time 30 {exit}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} hw_fixture\n'
s+=f'\nset hw_flip_stamp -1\ndebug set_bp {syms["HWFlip"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21 && [byte [expr {{$::world_collision+1130}}]]==0}} {{set ::hw_flip_stamp [machine_info time]}}\n'
s+=f'debug set_bp {syms["DiagCapture"]&65535} {{[byte {syms["g_CurrentSegment"]}]==14 && $::hw_flip_stamp>=0}} '+r"""{
 set f [open $::env(KEEN_TEST_OUTPUT)/vblank.txt a]
 puts $f "[expr {1000*([machine_info time]-$::hw_flip_stamp)}] [expr {[debug read {VDP status regs} 2]&64}]"
 close $f;set ::hw_flip_stamp -1
}
"""
(r/'build/hw-test.tcl').write_text(s)
