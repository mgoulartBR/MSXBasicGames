from pathlib import Path
import sys,subprocess,re
p=Path(sys.argv[1])
subprocess.run([sys.executable,str(p/'tests/make_vertical_bench.py'),str(p/'build/keen_msx.map'),str(p/'build/combat-bench.tcl')],check=True)
s=(p/'build/combat-bench.tcl').read_text()
d={n:int(a,16)for a,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',(p/'build/keen_msx.map').read_text())}
s='\n'.join(f'set {n} {d[n]}'for n in ['shots_fired','flower_hits','flower_returns','defeats','actors_old','front_page','cost_bg','cost_actor','cost_game','cost_restore','cost_edges'])+'\n'+s
s=s.replace('proc sample {} {', 'proc fire {} {keymatrixdown 3 1;after time 0.12 {keymatrixup 3 1};after time 0.40 fire}\nproc sample {} {')
s=s.replace('  lappend records', '  set active 0\n  for {set i 0} {$i<15} {incr i} {incr active [debug read memory [expr {$::actors_old+90*[debug read memory $::front_page]+6*$i+5}]]}\n  lappend records')
s=s.replace('[word $::drawn_camera_px]"','[word $::drawn_camera_px],$active"')
s=s.replace('interval,camera_y,delta_y,camera_x','interval,camera_y,delta_y,camera_x,visible_actors')
s=s.replace('  close $o;exit','  puts $o "shots=[word $::shots_fired] hits=[word $::flower_hits] returns=[word $::flower_returns] defeats=[word $::defeats]"\n  close $o;exit')
s=s.replace('keymatrixdown 8 16;jump;', 'keymatrixdown 8 16;jump;fire;')
(p/'build/combat-bench.tcl').write_text(s)

s=(p/'build/combat-bench.tcl').read_text()
s=s.replace('camera_x,visible_actors','camera_x,visible_actors,restore,edges,actors,game')
s=s.replace(',$active"', ',$active,[debug read memory $::cost_restore],[debug read memory $::cost_edges],[debug read memory $::cost_actor],[debug read memory $::cost_game]"')
(p/'build/combat-bench.tcl').write_text(s)

# Controlled performance workload only: the playable ROM still starts empty.
if 'flower_ammo' in d:
 s=(p/'build/combat-bench.tcl').read_text()
 s=s.replace('after time 10 {', 'after time 10 {if {[info exists ::env(KEEN_BENCH_AMMO)]} {debug write memory '+str(d['flower_ammo'])+' $::env(KEEN_BENCH_AMMO);debug write memory '+str(d['flower_ammo']+1)+' 0};')
 (p/'build/combat-bench.tcl').write_text(s)

if 'flower_ammo' in d:
 s=(p/'build/combat-bench.tcl').read_text()
 refill='if {[info exists ::env(KEEN_BENCH_AMMO)] && [word '+str(d['flower_ammo'])+']==0} {debug write memory '+str(d['flower_ammo'])+' $::env(KEEN_BENCH_AMMO);debug write memory '+str(d['flower_ammo']+1)+' 0};'
 s=s.replace('proc sample {} {','proc sample {} {'+refill)
 (p/'build/combat-bench.tcl').write_text(s)
