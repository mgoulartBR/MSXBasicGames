#!/usr/bin/env python3
"""Execute the ROM's detector against an OCM I/O test double in openMSX."""
import re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
out=root/'build/ocm-cpu';out.mkdir(exist_ok=True)
cases=[('msx2','C-BIOS_MSX2',12,1,1,4,1),('plus','C-BIOS_MSX2+',12,1,1,4,1),('rev1','C-BIOS_MSX2+',1,1,1,4,1),('rev0','C-BIOS_MSX2+',0,1,1,0,0),('rev31','C-BIOS_MSX2+',31,1,1,0,0),('rejected','C-BIOS_MSX2+',12,0,0,0,1),('ignored','C-BIOS_MSX2+',12,1,0,0,1)]
for name,machine,revision,ack,apply,status,count in cases:
 result=out/f'{name}.txt';result.unlink(missing_ok=True)
 script=out/f'{name}.tcl'
 script.write_text(f'''set throttle off
source {{{root/'tests/ocm_fixture.tcl'}}}
set keen_ocm::ports(79) {revision}
set keen_ocm::acknowledge {ack}
set keen_ocm::apply_clock {apply}
proc check {{ok msg}} {{if {{!$ok}} {{set f [open {{{result}}} w];puts $f "FAIL $msg";close $f;exit}}}}
proc word {{a}} {{expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}}}
proc enter_first_level {{}} {{
 if {{[debug read memory {syms['world_active']}]!=1}} {{after time 0.1 enter_first_level;return}}
 keymatrixdown 8 16
 after time 0.6 {{keymatrixup 8 16;keymatrixdown 8 1}}
 after time 0.9 {{keymatrixup 8 1}}
}}
after time 0.1 enter_first_level
after time 10 {{
 check [expr {{[debug read memory {syms['scene_ready']}]==165}}] boot
 check [expr {{[debug read memory {syms['cpu_mode']}]=={status}}}] status
 check [expr {{[llength $keen_ocm::commands]=={count}}}] command_count
 foreach cmd $keen_ocm::commands {{check [expr {{$cmd eq "212 10"}}] "unexpected write $cmd"}}
 check [expr {{$keen_ocm::selected==8}}] restore_device
 check [expr {{$keen_ocm::ports(67)==165 && ($keen_ocm::ports(66)&254)==214 && ($keen_ocm::ports(71)&248)==184 && ($keen_ocm::ports(72)&254)==162}}] unrelated_settings
 if {{{status}==4}} {{check [expr {{$z80_freq==8060000 && $z80_freq_locked}}] clock}}
 set keen_start_ticks [word {syms['simulation_ticks']}]
 after time 2 {{
  set dt [expr {{([word {syms['simulation_ticks']}]-$keen_start_ticks)&65535}}]
  check [expr {{$dt>=135 && $dt<=145}}] physics
  set f [open {{{result}}} w];puts $f "PASS {name}: status={status}, commands=$keen_ocm::commands, physics=$dt ticks/2s; OCM protocol fixture only.";close $f;exit
 }}
}}
''')
 with (out/f'{name}.log').open('w') as log:
  subprocess.run(['openmsx','-machine',machine,'-cart',str(root/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(script)],stdout=log,stderr=log,timeout=30,check=True)
 text=result.read_text();print(text.strip());assert text.startswith('PASS'),text
