from pathlib import Path
import sys,re
r=Path(sys.argv[1]);tag=sys.argv[2];mp=Path(sys.argv[3]);syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
alias={'player_x':'stable_x','player_y':'stable_y','grounded':'stable_grounded','player_frame':'stable_frame','simulation_ticks':'stable_ticks'}
def sub(m):
 n=m[1];lookup=n[4:] if n.startswith('raw_') else alias.get(n,n)
 return f'set {n} {syms[lookup]}' if lookup in syms else m[0]
s=re.sub(r'^set (\w+) (\d+)$',sub,s,flags=re.M)
s+='\nset enabled 0\nset frames 0\nset run 0\nset hw_frames 0\nset throttle off\n'
s+=r'''
proc fixture {} {
 if {!$::enabled} {return}
 putword $::raw_player_x 32000;putword $::raw_player_y 6400
 debug write memory $::hero_frame [expr {$::run%2 ? int([machine_info time]*8)%8 : 0}]
 debug write memory $::hero_visible 1
 debug write memory [expr {$::enemy+10}] 0
}
proc hold {} {
 if {!$::enabled} {return}
 place 2000 400
 debug write memory $::enemy_mode 0
 debug write memory $::combat_dirty 1
 after time 0.03 hold
}
proc start {} {
 set ::frames 0;set ::hw_frames 0;set ::started [machine_info time]
 after time 10 finish
}
proc finish {} {
 set f [open $::env(KEEN_TEST_OUTPUT)/bench.txt a]
 puts $f "run=$::run frequency=$::z80_freq animated=[expr {$::run%2}] frames=$::frames hw_frames=$::hw_frames seconds=[expr {[machine_info time]-$::started}]";close $f
 incr ::run
 if {$::run==2} {set ::z80_freq 7159090}
 if {$::run<4} {after time 1 start} else {exit}
}
after time 10 {
 check {[byte $::active_level]==1} {First stage loaded}
 set ::z80_freq 3579545;set ::z80_freq_locked false
 set ::enabled 1;hold;after time 1 start
}
after time 60 {exit}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} fixture\n'
hook='DiagCapture' if 'DiagCapture' in syms else 'HWFlip'
bank=14 if hook=='DiagCapture' else 21
s+=f'debug set_bp {syms[hook]&65535} {{[byte {syms["g_CurrentSegment"]}]=={bank} && $::enabled}} '+r'{incr ::frames;if {[byte [expr {$::world_collision+1131+[byte $::front_page]}]]} {incr ::hw_frames}}'+'\n'
(r/f'build/hero-bench-{tag}.tcl').write_text(s)
