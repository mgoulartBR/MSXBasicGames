"""Generate openMSX checks from this build's symbols."""
import pathlib,re,sys
root=pathlib.Path(sys.argv[1]); mapfile=root/'build/keen_msx.map'
symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+main\s*$',mapfile.read_text(),re.M)}
header='\n'.join(f'set {n} {symbols[n]}' for n in ('scene_ready','camera_x','camera_y','render_count','front_page'))
body=r'''
set throttle on
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {addr} { return [debug read memory $addr] }
proc word {addr} { return [expr {[byte $addr]+256*[byte [expr {$addr+1}]]}] }
proc check {condition message} {
    if {![uplevel 1 [list expr $condition]]} {
        set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w]
        puts $f $message
        close $f
        exit
        error $message
    }
}
proc dump_vram {name address size} {
    set f [open $::env(KEEN_TEST_OUTPUT)/$name wb]
    puts -nonewline $f [debug read_block VRAM $address $size]
    close $f
}
after time 10 {
    check {[byte $scene_ready]==165} "Scene did not initialize"
    check {[word $render_count]==1} "Initial draw counter"
    check {[byte $camera_x]==118 && [byte $camera_y]==24} "Initial camera"
    dump_vram atlas-vram.bin 65536 65536
    dump_vram spawn-vram.bin [expr {[byte $front_page]*32768}] 27136
    screenshot -raw $env(KEEN_TEST_OUTPUT)/spawn.png
    # At the right and bottom limit, pressing toward the border must not redraw.
    keymatrixdown 8 192
    after time 0.25 {
        keymatrixup 8 192
        check {[byte $camera_x]==118 && [byte $camera_y]==24} "Right/bottom bounds"
        check {[word $render_count]==1} "Unnecessary boundary redraw"
        keymatrixdown 8 16
        after time 0.6 {
            keymatrixup 8 16
            check {[byte $camera_x]<118} "Left camera movement"
            keymatrixdown 8 32
            after time 0.6 {
                keymatrixup 8 32
                check {[byte $camera_y]<24} "Up camera movement"
                # Allow an in-flight render to complete before collecting a frame.
                after time 0.4 {
                    dump_vram scrolled-vram.bin [expr {[byte $front_page]*32768}] 27136
                    screenshot -raw $env(KEEN_TEST_OUTPUT)/scrolled.png
                    set f [open $env(KEEN_TEST_OUTPUT)/camera.txt w]
                    puts $f "[byte $camera_x] [byte $camera_y]"
                    close $f
                    keymatrixdown 8 1
                    after time 0.6 {
                        keymatrixup 8 1
                        check {[byte $camera_x]==118 && [byte $camera_y]==24} "Return to start"
                        check {[word $render_count]>3} "Render counter advance"
                        set f [open $env(KEEN_TEST_OUTPUT)/PASS.txt w]
                        puts $f "PASS: boot, ASCII16, camera left/up, right/bottom bounds, return to spawn."
                        puts $f "Draws=[word $render_count]; camera=[byte $camera_x],[byte $camera_y]"
                        close $f
                        exit
                    }
                }
            }
        }
    }
}
'''
(root/'build/scene-test.tcl').write_text(header+'\n'+body)
