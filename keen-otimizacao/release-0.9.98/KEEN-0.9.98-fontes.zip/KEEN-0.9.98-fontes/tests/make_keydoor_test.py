from pathlib import Path
import sys,re
r=Path(sys.argv[1]);s=(r/'build/world-test.tcl').read_text().split('after time 10 {')[0]
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s+=f'\nset raw_grounded {syms["grounded"]}\n'
s+=r'''
proc controls {in} {
 foreach {bit mask} {1 16 2 128 4 32 8 64 16 1} {if {$in&$bit} {keymatrixdown 8 $mask} else {keymatrixup 8 $mask}}
}
proc place {x y} {
 if {[byte $::render_commit]} {after time 0.001 [list place $x $y];return}
 putword $::raw_player_x [expr {$x*16}];putword $::raw_player_y [expr {$y*16}]
 putword $::raw_player_vx 0;putword $::raw_player_vy 0
 debug write memory $::raw_grounded 0;debug write memory $::climbing 0
 debug write memory $::cart_riding 255;debug write memory $::combat_dirty 1
}
proc until {condition command started} {
 if {[expr $condition]} {eval $command;return}
 check {[machine_info time]-$started<12} "Timeout: $condition"
 after time 0.005 [list until $condition $command $started]
}
proc waitfor {condition command} {until $condition $command [machine_info time]}
proc collect_key {} {
 controls 0
 after time 0.8 {place 1208 928;after time 1 {snap key_available;controls 2;waitfor {[byte $::key_owned]==1} got_key}}
}
proc got_key {} {
 controls 0
 check {[byte $::key_taken]==1 && [byte $::key_rise]>0} "Original key collected"
 after time 1 {
  check {[byte $::key_owned]==1 && [byte $::key_taken]==1} "No duplicate collection"
  check {[word $::flower_ammo]==0} "Key does not alter Flower Power"
  snap key_owned
  place 1184 1328
  after time 1 {controls 2;waitfor {[byte $::door_state]==1} unlocking}
 }
}
proc unlocking {} {
 controls 0
 check {[byte $::key_owned]==0 && [byte $::door_ticks]<24} "One key consumed at contact"
 snap door_opening
 waitfor {[byte $::door_state]==2} opened
}
proc opened {} {
 check {[byte $::key_owned]==0 && [byte $::door_ticks]==24} "Door animation completes once"
 controls 2
 waitfor {[word $::player_x]>1248*16} passed
}
proc passed {} {
 controls 0
 after time 1 {
  check {[byte $::door_state]==2 && ![byte $::key_owned]} "Open door remains open"
  snap door_open
  # Original lethal floor between the two deep tracks, outside both carts.
  place 512 1264
  waitfor {[byte $::death_ticks]>0} dying
 }
}
proc dying {} {
 waitfor {![byte $::death_ticks] && [word $::player_y]<200*16} after_death
}
proc after_death {} {
 check {![byte $::key_owned] && ![byte $::key_taken] && ![byte $::door_state] && ![byte $::door_ticks]} "Death restores key and locked door"
 # Collect again through ordinary contact, then exercise manual restart.
 place 1200 928
 after time 1 {controls 2;waitfor {[byte $::key_owned]==1} restart_key}
}
proc restart_key {} {
 controls 0;keymatrixdown 4 128
 after time 0.5 {keymatrixup 4 128}
 waitfor {![byte $::key_taken] && [word $::player_y]<200*16} restarted
}
proc restarted {} {
 check {![byte $::key_owned] && ![byte $::door_state]} "R clears inventory and restores door"
 after time 1 {
  snap reset_spawn
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
  puts $f "PASS: original key position; key HUD; closed door blocks from both sides; one key consumed; raising/open door; walk through; death and R restore objects. Isolated geometry fixtures reposition Keen; collection and opening use normal controls."
  close $f;exit
 }
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2 && [byte $::scene_ready]==165} "Melon loaded"
  place 1184 1328
  after time 1 {controls 2}
  after time 2.5 {
   controls 0
   check {[word $::player_x]==76*256-305 && ![byte $::door_state] && ![byte $::key_owned]} "Locked door blocks from left"
   snap door_locked
   place 1248 1328
   after time 1 {controls 1}
   after time 2.5 {
    controls 0
    check {[word $::player_x]==76*256+241-64 && ![byte $::door_state]} "Locked door blocks from right"
    collect_key
   }
  }
 }
}
after time 90 {check {0} "Overall timeout"}
'''
(r/'build/keydoor-test.tcl').write_text(s)
