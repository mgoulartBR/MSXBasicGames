from pathlib import Path
import re,sys
r=Path(sys.argv[1]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+='\nset throttle on\nset enabled 0\nset case 0\nset pending -1\nset positions {{864 96 0 1} {864 144 43 0} {864 96 31 1} {864 144 15 0} {864 96 45 1}}\n'
s+=r'''
proc fixture {} {
 if {!$::enabled} {return}
 lassign [lindex $::positions $::case] x y frame hw
 putword $::raw_player_x [expr {$x*16}];putword $::raw_player_y [expr {$y*16}]
 debug write memory $::hero_frame $frame;debug write memory $::hero_visible 1
}
proc hold {} {
 if {!$::enabled} {return}
 lassign [lindex $::positions $::case] x y frame hw
 place $x $y
 debug write memory $::enemy_mode 3;debug write memory $::combat_dirty 1
 after time 0.03 hold
}
proc capture {n} {
 if {[byte $::render_commit]} {after time 0.001 [list capture $n];return}
 set expected [lindex [lindex $::positions $n] 3]
 check {[byte [expr {$::world_collision+1131+[byte $::front_page]}]]==$expected} "Hardware/fallback selection $n"
 snap transition$n
 if {$n<4} {incr ::case;after time 1.5 [list set ::pending [expr {$n+1}]]} else {
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f {PASS: hardware, foreground bitmap fallback, return to hardware, second foreground bitmap frame, return to hardware.};close $f;exit
 }
}
after time 10 {set ::enabled 1;hold;after time 1.5 {set ::pending 0}}
after time 25 {check {0} {Overall timeout}}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} fixture\n'
s+=f'debug set_bp {syms["HWFlip"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21 && $::pending>=0}} '+r'{set n $::pending;set ::pending -1;after time 0.001 [list capture $n]}'+'\n'
(r/'build/hero-transition-test.tcl').write_text(s)
