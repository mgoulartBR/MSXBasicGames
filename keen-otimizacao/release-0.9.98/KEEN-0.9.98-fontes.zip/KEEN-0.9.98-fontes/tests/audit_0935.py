"""Original ninth map, full object roster, previous binary identity and cache bounds."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,re,hashlib
r=Path(__file__).resolve().parents[1];maps=json.loads((r/'assets/generated/maps.json').read_text());rows=[]
for level in (1,2,3,4,5,7,9,10,12):
 m=next(x for x in maps if x['id']==level);bs=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-1<=bx-x<=2 and -2<=by-y<=3 for bx,by in bs)for x in range(m['width'])for y in range(m['height']));assert peak<=8;rows.append((level,len(bs),peak))
m=next(x for x in maps if x['id']==12);keys=sorted(set(zip(*m['planes'][:2])));raw=(r/'assets/bay/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<2697H',raw)]==list(zip(*m['planes'][:2]))
spawns=re.findall(r'\{(\d+),(\d+),(\d+)\}',(r/'src/bay_spawns.h').read_text())
assert sorted((int(y)*93+int(x),int(v))for x,y,v in spawns)==sorted((i,v)for i,v in enumerate(m['planes'][2])if v in (41,45))
with ZipFile(r.parent/'deliverables/v0.9.34/keen-dreams-msx-0.9.34-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass','city','apple','grove'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'deliverables/v0.9.34/KEEN0934.ROM').read_bytes()).hexdigest()=='32d87cf801c07116f5c35a38174236e79e8527be95ed6422d2ba453e9fcd0fea'
world=json.loads((r/'assets/tuberia/manifest.json').read_text());assert any(n[1]==9 for n in world['nodes']);assert any(p[3]==256 for p in world['patches']);assert world['unique_bitmaps']<=544
assert "opaque_sprites[9][166]" in (r/"src/opaque_sprites.h").read_text(), "Nine renderer mask tables"
print('PASS: 2697 original background/foreground cells; four original actors; baseline 0.9.34 preserved; %d unchanged previous-stage binaries; ninth Tuberia portal and completion flag 256; bonus cache census %s.'%(count,rows))
