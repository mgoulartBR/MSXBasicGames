"""Isolated ROM CartStep comparison, not a gameplay FPS benchmark.
Repeat 4096 calls after normal Melon load; preserve real CPU, code and map.
Usage: bench_cart_cache.py label ROM MAP
"""
import sys,re,os,subprocess,csv,json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parents[1];label=sys.argv[1];rom=Path(sys.argv[2]).resolve();mp=Path(sys.argv[3])
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
out=r/'build'/('cart-bench-'+label);out.mkdir(exist_ok=True)
s='\n'.join(f'set sym({k}) {v}' for k,v in syms.items())+'\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {a} {return [debug read memory $a]}
proc word {a} {return [expr {[byte $a]+256*[byte [expr {$a+1}]]}]}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
set started 0
set count 0
set elapsed 0
set log [open $::env(KEEN_TEST_OUTPUT)/calls.csv w]
puts $log "call,seconds,carts"
proc start {} {
 if {!$::started} {
  set ::started 1
  debug write memory $::sym(cart_riding) 255
  debug write memory $::sym(climbing) 0
  putword $::sym(camera_px) 60000;putword $::sym(camera_py) 60000
  set ::call_sp [reg SP];set ::ret [word $::call_sp]
  set ::return_bp [debug set_bp $::ret "\[reg SP\]==[expr {$::call_sp+2}]" {finish_call}]
 }
 set ::start_time [machine_info time]
}
proc finish_call {} {
 set delta [expr {[machine_info time]-$::start_time}]
 set ::elapsed [expr {$::elapsed+$delta}]
 binary scan [debug read_block memory $::sym(carts) 18] H* state
 puts $::log "$::count,$delta,$state"
 incr ::count
 if {$::count==4096} {
  close $::log
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS $::count calls $::elapsed seconds";close $f;exit
 }
 # Re-enter the same void routine with the same caller return address.
 reg SP $::call_sp
 putword $::call_sp $::ret
 reg PC [expr {$::sym(CartStep)&65535}]
 set ::start_time [machine_info time]
}
debug set_bp [expr {$sym(CartStep)&65535}] {[byte $sym(active_level)]==2 && [byte $sym(g_CurrentSegment)]==7} {start}
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 40 {putword $::sym(world_x) 608;putword $::sym(world_y) 448;keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 110 {exit}
'''
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING')
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with (out/'emulator.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=100,check=True)
assert (out/'PASS.txt').read_text().startswith('PASS '),(out/'emulator.log').read_text()
rows=list(csv.DictReader((out/'calls.csv').open()));assert len(rows)==4096
summary=dict(calls=len(rows),seconds=sum(float(x['seconds']) for x in rows),rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest())
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(label,summary)
