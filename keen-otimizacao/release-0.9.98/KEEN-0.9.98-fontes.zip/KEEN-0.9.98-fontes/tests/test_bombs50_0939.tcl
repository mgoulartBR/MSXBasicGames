set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc verify {} {
 set count [word 61299]
 if {$count!=50} {error "Expected 50 bombs; actual=$count"}
 set f [open $::env(KEEN_BOMBS_TEST_LOG) w];puts $f "PASS: native CampaignNew initializes exactly 50 bombs.";close $f;exit
}
debug set_bp 35219 {[debug read memory 49156]==99} verify
foreach t {5 10 15 20 25 30} {after time $t {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}}
after time 60 {set f [open $::env(KEEN_BOMBS_TEST_LOG) w];puts $f "FAIL: timeout";close $f;exit}
