from pathlib import Path
import re,sys
r=Path(sys.argv[1]);out=Path(sys.argv[2]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {v}' for n,v in syms.items())+r'''
set throttle off
set save_settings_on_exit false
# Dismiss the startup title before the existing gameplay fixtures.
after time 3 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
set renderer SDL
set sound_driver null
set held 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {
 if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}
}
proc waitfor {c cb} {if {[expr $c]} {eval $cb} else {after time 0.03 [list waitfor $c $cb]}}
proc actor {i} {expr {$::world_map+9600+16*$i}}
proc hold {x y} {set ::hx $x;set ::hy $y;set ::held 1}
proc fixture {} {
 if {$::held} {putword $::player_x [expr {$::hx*16}];putword $::player_y [expr {$::hy*16}]
 putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1}
}
proc snap {name} {
 if {[byte $::render_commit]} {after time 0.001 [list snap $name];return}
 foreach {suffix device start size} [list vram VRAM 0 131072 regs {VDP regs} 0 64] {
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f}
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w];puts $f "[word $::drawn_camera_px] [word $::drawn_camera_py] [byte $::front_page] [byte $::hardware_scroll]";close $f
}
proc moving {} {
 set t [actor 0];lappend ::xs [word $t]
 if {[llength $::xs]<25} {after time 0.12 moving;return}
 check {[llength [lsort -unique $::xs]]>3} "Tater walks on original platform"
 check {[byte [expr {$t+10}]]==1} "Nearby enemy active"
 snap tater
 putword $::shots [expr {[word $t]+128}];putword [expr {$::shots+2}] [expr {[word [expr {$t+2}]]+128}]
 putword [expr {$::shots+4}] 0;putword [expr {$::shots+6}] 0;putword [expr {$::shots+8}] 140
 debug write memory [expr {$::shots+10}] 1;debug write memory [expr {$::shots+13}] 0
 set ::hits [word $::flower_hits];set ::returns [word $::flower_returns]
 waitfor {[word $::flower_hits]>$::hits} flowered
}
proc cadence {} {
 if {![info exists ::cadence_on] || !$::cadence_on} {return}
 set a [actor 0];set clock [word $::simulation_ticks];set timer [word [expr {$a+8}]]
 if {$::cadence_samples>0} {
  check {(($clock-$::last_clock)&65535)==1} "Exactly one BridgeTick per simulation tick"
  check {$timer==$::last_timer-1} "Flower timer advances on every simulation tick"
 }
 set ::last_clock $clock;set ::last_timer $timer;incr ::cadence_samples
 if {[byte [expr {$a+13}]]!=1} {set ::cadence_on 0}
}
proc flowered {} {
 set ::cadence_on 1;set ::cadence_samples 0
 check {[byte [expr {[actor 0]+13}]]==1} "Tater transformed by actual projectile"
 after time 0.3 {snap flower}
 waitfor {[word $::flower_returns]>$::returns} restored
}
proc restored {} {
 check {$::cadence_samples>=300} "Native flower cadence observed for at least 300 ticks"
 check {[byte [expr {[actor 0]+13}]]==0} "Flower timed recovery"
 hold 440 836
 after time 2 melons
}
proc melons {} {
 check {[byte [expr {[actor 5]+10}]] && [byte [expr {[actor 6]+10}]]} "Both original Melon Lips active"
 check {[byte [expr {[actor 0]+10}]]==0} "Distant Tater sleeps"
 set ::asleep [word [actor 0]]
 waitfor {[byte [expr {[actor 7]+10}]] || [byte [expr {[actor 8]+10}]]} seed
}
proc seed {} {
 check {[word [actor 0]]==$::asleep} "Distant enemy position unchanged"
 snap melons
 # Verify a native renderer record for a Melon Lips frame.
 set seen 0
 for {set i 0} {$i<52} {incr i} {set a [expr {$::actors_old+$i*6}];set frame [byte [expr {$a+4}]]
 if {[byte [expr {$a+5}]] && $frame>=136 && $frame<=139} {set seen 1}}
 check {$seen} "Melon drawn by ROM renderer"
 # Put one real hostile seed on Keen, then exercise actual collision/restart.
 set t [actor 7];putword $t [expr {$::hx*16+128}];putword [expr {$t+2}] [expr {$::hy*16+128}]
 putword [expr {$t+4}] 0;putword [expr {$t+6}] 0;putword [expr {$t+8}] 100
 debug write memory [expr {$t+10}] 1;debug write memory [expr {$t+11}] 140
 set ::lives [byte $::game_lives]
 waitfor {[byte $::death_ticks]>0} killed
}
proc killed {} {
 set ::held 0;set ::reset_audited 0;set ::carrot_audited 0;debug write memory $::climbing 0
 waitfor {$::reset_audited && $::carrot_audited && [byte $::game_lives]<$::lives && [byte $::scene_ready]==165 && [byte $::death_ticks]==0 && [byte $::restart_pending]==0 && [word $::player_x]==528*16} restarted
}
proc audit_reset {} {
 if {[info exists ::reset_audited] && !$::reset_audited} {check {[word [actor 0]]==19*256 && ![byte [expr {[actor 7]+10}]]} "Enemy reset and hostile seed cleared";set ::reset_audited 1}
}
proc audit_carrot {} {
 if {[info exists ::carrot_audited] && !$::carrot_audited && $::reset_audited && ![byte $::death_ticks] && ![byte $::restart_pending]} {
  check {[word $::enemy]==33*256 && [word [expr {$::enemy+2}]]==46*256} "Original Carrot Courier spawn before first resumed tick"
  set ::carrot_audited 1
 }
}
proc restarted {} {
 check {[byte $::active_level]==3 && [word $::player_x]==528*16} "Death restarts Bridge at original spawn"
 check {$::reset_audited} "Enemy reset and hostile seed cleared at the reset boundary"
 check {$::carrot_audited} "Original Carrot Courier spawn audited before movement"
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
 puts $f "PASS: Bridge entry, Tater real-map movement, actual Flower Power contact/recovery, distant sleep, both Melon Lips active/rendered, native hostile seeds, death/restart and original Carrot spawn; exact per-tick Bridge/flower cadence verified for $::cadence_samples calls. Player/projectile positioning fixtures."
 close $f;exit
}
after time 10 {
 putword $::world_x 848;putword $::world_y 848;keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
 after time 4 {
 check {[byte $::active_level]==3 && [byte $::scene_ready]==165} "Bridge loaded"
 hold 304 260;set ::xs {};after time 1 moving
 }
}
after time 100 {check {0} "Timeout"}
'''
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {syms["BridgeTick"]&65535} {{[byte $::g_CurrentSegment]==15}} cadence\n'
s+=f'\ndebug set_bp {syms["HillReset"]&65535} {{[byte $::g_CurrentSegment]==15 && [byte $::active_level]==3}} audit_reset\n'
s+=f'\ndebug set_bp {syms["CombatTick"]&65535} {{[byte $::g_CurrentSegment]==7 && [byte $::active_level]==3}} audit_carrot\n'
out.write_text(s)
