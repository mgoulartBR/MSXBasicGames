from pathlib import Path
import re,subprocess
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
for name,freq in [('z80',3579545),('fast',10000000)]:
 out=r/'build'/('0911-p2-'+name);out.mkdir(exist_ok=True)
 fields=['phase2_done','phase2_status','phase2_hz','phase2_cpu','phase2_logic','phase2_cpu_ticks','phase2_vdp','phase2_checksum','phase2_steps','phase2_shots','phase2_hits']
 report='\n'.join(f'puts $f "{n} [{'debug read memory' if n in fields[:4] else 'word'} {s[n]}]"' for n in fields)
 script=f'''set throttle off
set save_settings_on_exit false
set z80_freq {freq}
set z80_freq_locked false
set logic_writes 0
set cpu_writes 0
proc word {{a}} {{expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}}}
debug set_watchpoint write_io {{0x98 0x9b}} {{}} {{
 set stage [debug read memory {s['phase2_stage']}]
 if {{$stage==1}} {{incr logic_writes}}
 if {{$stage==2}} {{incr cpu_writes}}
}}
after time 10 {{keymatrixdown 4 8;after time 0.3 {{keymatrixup 4 8}}}}
after time 13 {{keymatrixdown 8 1;after time 0.3 {{keymatrixup 8 1}}}}
after time 90 {{
 set f [open {{{out/'result.txt'}}} w]
 puts $f "actual_clock [machine_info z80_freq]"
 puts $f "logic_vdp_writes $logic_writes"
 puts $f "cpu_vdp_writes $cpu_writes"
 {report}
 close $f
 screenshot {{{out/'result.png'}}}
 exit
}}
'''
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],stdout=log,stderr=log,timeout=60,check=True)
 v=dict(line.split() for line in (out/'result.txt').read_text().splitlines());print(name,v,flush=True)
 assert v['phase2_done']=='1' and v['phase2_status']=='0' and v['phase2_steps']=='700'
 assert v['logic_vdp_writes']=='0' and v['cpu_vdp_writes']=='0'
 assert all(int(v[k])>0 for k in ['phase2_logic','phase2_cpu_ticks','phase2_vdp'])
 assert abs(int(v['actual_clock'])-freq)<freq/100
