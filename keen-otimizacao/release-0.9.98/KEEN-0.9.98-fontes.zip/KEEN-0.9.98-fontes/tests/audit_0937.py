"""Original tenth map, full object roster, previous binary identity and cache bounds."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,re,hashlib
r=Path(__file__).resolve().parents[1];maps=json.loads((r/'assets/generated/maps.json').read_text());rows=[]
for level in (1,2,3,4,5,7,9,10,12,14,15):
 m=next(x for x in maps if x['id']==level);bs=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-1<=bx-x<=2 and -2<=by-y<=3 for bx,by in bs)for x in range(m['width'])for y in range(m['height']));assert peak<=8;rows.append((level,len(bs),peak))
m=next(x for x in maps if x['id']==15);keys=sorted(set(zip(*m['planes'][:2])));raw=(r/'assets/boobus/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<1050H',raw)]==list(zip(*m['planes'][:2]))
assert [(i%m['width'],i//m['width'],v)for i,v in enumerate(m['planes'][2])if v]==[(3,26,1),(21,26,61)]
with ZipFile(r.parent/'deliverables/v0.9.36/keen-dreams-msx-0.9.36-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass','city','apple','grove','bay','swamp'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'deliverables/v0.9.36/KEEN0936.ROM').read_bytes()).hexdigest()=='6a67701461671d563d45a717949410307a79091055a7eb7e990ee86365611333'
world=json.loads((r/'assets/tuberia/manifest.json').read_text());assert any(n[1]==11 for n in world['nodes']);assert not any(p[3]==1024 for p in world['patches']);assert world['unique_bitmaps']<=544
assert "opaque_sprites[11][166]" in (r/"src/opaque_sprites.h").read_text(), "Eleven renderer mask tables"
print('PASS: 1050 original background/foreground cells; original Keen and Boobus positions, no invented pickups; baseline 0.9.36 preserved; %d unchanged previous-stage binaries; eleventh original Tuberia portal and completion bit 1024; bonus cache census %s.'%(count,rows))
b=(r/'build/keen_msx.rom').read_bytes();assert b[:16384]==b[46*16384:47*16384], 'Sealed fixed-bank reference'
