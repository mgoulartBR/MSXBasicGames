"""Full Game_Tick equivalence, original vs hero property cache; host semantics only."""
from pathlib import Path
import ctypes as C,subprocess,random,json
r=Path(__file__).resolve().parents[1];out=r/'build/hero-cache-equivalence';out.mkdir(exist_ok=True)
header='''#include "msxgl.h"
#include <string.h>
u8 world_map[9835],world_collision[1168],active_level;
volatile u8 death_ticks,combat_dirty;
volatile u16 defeats,camera_px,camera_py;
u16 MapTile(u16 i){u16 n=i+(i>>3);return (((u16)world_map[n]|((u16)world_map[n+1]<<8))>>(i&7))&511;}
'''
fields='player_x player_y player_vx player_vy grounded facing_left player_frame floor_type jump_hold simulation_ticks wall_hits ceiling_hits slope_hits respawns jump_previous walk_time climbing pole_column pole_cooldown pole_anim level_done cart_riding key_owned key_taken key_rise door_state door_ticks death_ticks defeats combat_dirty stable_x stable_y stable_ticks stable_grounded stable_frame'.split()
footer='''
void Init(const u8* m,const u8* p,int level){memcpy(world_map,m,9835);memcpy(world_collision,p,1168);active_level=level;simulation_ticks=0;death_ticks=0;Game_Reset();}
void Reset(void){Game_Reset();death_ticks=0;}
void Snapshot(int*s){
'''+''.join(f'*s++={n};' for n in fields)+'''for(int i=0;i<3;i++){*s++=carts[i].x;*s++=carts[i].y;*s++=carts[i].dir;*s++=carts[i].delta;}}
'''
libs=[]
for name in ['baseline','candidate']:
 game=r/('build/0927-baseline/game.c' if name=='baseline' else 'experiments/batch-cache-four/game.c')
 world=r/('build/0927-baseline/world.c' if name=='baseline' else 'experiments/batch-cache-four/world.c')
 src=header+'\n#include "'+str(game)+'"\n#include "'+str(r/'src/keydoor.c')+'"\nvoid MapSet'+world.read_text().split('void MapSet',1)[1]+footer
 p=out/(name+'.c');p.write_text(src)
 subprocess.run(['gcc','-shared','-fPIC','-O2','-I'+str(r/'tests/host'),'-I'+str(r/'src'),str(p),'-o',str(out/(name+'.so'))],check=True)
 libs.append(C.CDLL(str(out/(name+'.so'))))
ss=[(C.c_int*(len(fields)+12))() for _ in libs];rng=random.Random(927);checks=edits=0
for level,stage in enumerate(['scene','melon','bridge'],1):
 raw=(r/f'assets/{stage}/packed_map.bin').read_bytes();m=(C.c_ubyte*9835).from_buffer_copy(raw.ljust(9835,b'\0'));p=(C.c_ubyte*1168).from_buffer_copy((r/f'assets/{stage}/stage_data.bin').read_bytes())
 for l in libs:l.Init(m,p,level)
 for step in range(20000):
  # Long runs, reversals, variable jump holds, climb commands, and idle steps.
  inp=([2,1,0,4,8][(step//173)%5]) | (16 if step%121<rng.randrange(8,43) else 0)
  if step%197==0:
   libs[0].Snapshot(ss[0]);x=ss[0][0]>>8;y=(ss[0][1]+496)>>8
   if x<p[1120] and y<p[1121]:
    tile=rng.randrange(292)
    for l in libs:l.MapSet(y*p[1120]+x,tile)
    edits+=1
  for l,s in zip(libs,ss):l.Game_Tick(inp);l.Snapshot(s)
  assert list(ss[0])==list(ss[1]),(stage,step,[(fields[i] if i<len(fields) else str(i),a,b) for i,(a,b) in enumerate(zip(*ss)) if a!=b])
  checks+=1
  if ss[0][fields.index('level_done')] or ss[0][fields.index('death_ticks')] or step%1000==999:
   for l in libs:l.Reset()
result=dict(equal_full_physics_steps=checks,map_edits=edits,stages=['scene','melon','bridge'])
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
