"""Validate profiler accounting and export measurements (Tcl list parser)."""
from pathlib import Path
import tkinter,csv,json,sys,hashlib
r=Path(sys.argv[1]);out=r/'build/088-profile-summary';out.mkdir(exist_ok=True)
tcl=tkinter.Tcl()
def split(s):return tcl.splitlist(s)
def pairs(s):
 a=split(s);return dict(zip(a[::2],a[1::2]))
def load(path):
 scenes={}
 for line in path.read_text().splitlines():
  a=split(line);kind=a[0];k=int(a[1])
  if kind=='SCENE':
   d=dict(zip(a[2::2],a[3::2]));d['totals']={x:float(y) for x,y in pairs(d['totals']).items()};d['functions']={};d['sites']={};scenes[k]=d
  elif kind=='FUNCTION':scenes[k]['functions'][a[2]]={'calls':int(a[3]),'seconds':float(a[4]),'wait_seconds':float(a[5])}
  elif kind=='WAIT_SITE':scenes[k]['sites'][a[2]]={'calls':int(a[3]),'seconds':float(a[4])}
  elif kind=='COMMANDS':scenes[k]['commands']={x:float(y) for x,y in pairs(a[2]).items()}
  elif kind=='VISIBLE':scenes[k]['visible']={int(x):int(y) for x,y in pairs(a[2]).items()}
 return scenes
all_data={};rows=[];funcrows=[]
labels=['normal_static','frozen_visible_static','active_hidden_static','frozen_hidden_static','normal_vertical_scroll']
for hz in [3579545,7159090]:
 data=load(r/f'build/088-profile-{hz}/profile.txt');assert len(data)==5
 all_data[hz]=data
 for i,d in data.items():
  sec=float(d['seconds']);frames=int(d['frames']);b=d['totals']['busy'];w=d['totals']['wait'];both=d['totals']['both']
  assert int(d['frequency'])==hz and d['locked']=='false'
  assert 0<=both<=min(w,b)<=sec and w<=sec and b<=sec
  assert abs(sum(v for k,v in d['commands'].items() if k.endswith(',time'))-b)<0.01
  expected=0 if i in (2,3) else 3
  assert d['visible']=={expected:frames},(hz,i,d['visible'],frames)
  for n,v in d['functions'].items():
   assert 0<=v['wait_seconds']<=v['seconds']<=sec+0.001
   funcrows.append([hz,labels[i],n,v['calls'],v['seconds'],v['wait_seconds'],1000*v['seconds']/v['calls']])
  row=dict(hz=hz,scenario=labels[i],seconds=sec,frames=frames,fps=frames/sec,wait_ms_per_frame=w*1000/frames,busy_ms_per_frame=b*1000/frames,busy_outside_wait_ms_per_frame=(b-both)*1000/frames,wait_percent=100*w/sec,busy_percent=100*b/sec,visible_enemies=expected)
  rows.append(row)
control=load(r/'build/088-profile-control-7159090/profile.txt')
assert len(control)==5
for i,d in control.items():
 assert int(d['frames'])==int(all_data[7159090][i]['frames']),('profiler changes throughput',i,d['frames'])
rom=r/'build/keen_msx.rom';assert hashlib.sha256(rom.read_bytes()).hexdigest()=='4a530502772d2b5cf60d5898de769a72346cf2cd3676217fd1456531cab4bb14'
with (out/'scenarios.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (out/'functions.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['hz','scenario','function','calls','inclusive_seconds','wait_seconds','ms_per_call']);w.writerows(funcrows)
(out/'profile.json').write_text(json.dumps(all_data,indent=2))
(out/'PASS.txt').write_text('PASS: 10 windows, busy/wait intersections, command-time accounting, visible counts every frame; 5 control windows with identical presentation counts; ROM unchanged.\n')
for row in rows:print(row)
