"""Revalidate the first five stages against the current ROM."""
from pathlib import Path
import subprocess,sys,hashlib
r=Path(__file__).resolve().parents[1]
rom=(r/'build/keen_msx.rom').read_bytes();digest=hashlib.sha256(rom).hexdigest()
for name,script,directory in [('hill','test_rom29_hill.py','0929-hill-rom'),('mines','test_rom29_mines.py','0929-mines-rom'),('bridge','test_rom29_bridge.py','0929-bridge-rom'),('rapids','test_rom30_rapids.py','0930-rapids-rom'),('pass','test_rom31_pass.py','0931-pass-rom'),('city','test_rom32_city.py','0932-city-rom')]:
 with (r/'build'/('0933-'+name+'-rom.log')).open('w') as log:subprocess.run([sys.executable,str(r/'tests'/script)],stdout=log,stderr=log,check=True)
 assert (r/'build/keen_msx.rom').read_bytes()==rom
 (r/'build'/directory/'ROM-SHA256.txt').write_text(digest+'\n')
 print(name,'PASS',flush=True)
