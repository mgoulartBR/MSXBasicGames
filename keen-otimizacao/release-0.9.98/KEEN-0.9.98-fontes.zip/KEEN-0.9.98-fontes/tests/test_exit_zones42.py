from pathlib import Path
import json,re,subprocess
r=Path(__file__).resolve().parents[1]
maps={m['id']:m for m in json.loads((r/'assets/generated/maps.json').read_text())}
ids=[1,2,3,4,5,7,9,10,12,14,15,16]
source=(r/'tests/host/test_boobus.c').read_text()
source=source[:source.index('int main(')]+"int main(void){\n"
count=0
for stage,mid in enumerate(ids,1):
 m=maps[mid];w=m['width'];signs=[(i%w,i//w)for i,t in enumerate(m['planes'][1])if t==110]
 for side in [0,1]:
  for row in range(m['height']):
   expected=any((x>=w//2)==bool(side) and row+48/256<y+2 and row+496/256>y for x,y in signs)
   source+=f"active_level={stage};player_y={row}*256;assert(ExitBoundary({side})=={int(expected)});\n"
   count+=1
source+=f'puts("PASS: {count} side/height checks against EXIT signs in original maps; boss arena has no side exit.");return 0;}}\n'
# Retain the external stubs from the original test.
source+=(r/'tests/host/test_boobus.c').read_text().split('#include "grove_stubs.inc"')[-1]
source='#define KEY_SPACE 0\n'+source
source=source.replace('../../src/','../src/').replace('"rapid_reset.inc"','"host/rapid_reset.inc"').replace('"grove_stubs.inc"','"host/grove_stubs.inc"')
# All remaining local stub headers are found through -I tests/host.
p=r/'tests/exit42_generated.c';p.write_text(source)
exe=r/'build/host42-exits'
subprocess.run(['gcc','-O2','-ffunction-sections','-fdata-sections','-Wno-implicit-function-declaration','-I'+str(r/'tests/host'),'-I'+str(r/'src'),str(p),'-Wl,--gc-sections','-o',str(exe)],check=True)
subprocess.run([str(exe)],check=True)
