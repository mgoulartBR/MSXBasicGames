"""Check source-map identity, fixed cache bounds, and baseline resources."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,hashlib,re
r=Path(__file__).resolve().parents[1]
original=json.loads((r/'assets/generated/maps.json').read_text())
rows=[]
for level in (1,2,3,4,5,7):
 m=next(x for x in original if x['id']==level)
 bonuses=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-2<=bx-x<=2 and -2<=by-y<=3 for bx,by in bonuses)for x in range(m['width'])for y in range(m['height']))
 assert peak<=8;rows.append((level,len(bonuses),peak))
m=next(x for x in original if x['id']==7);keys=sorted(set(zip(*m['planes'][:2])))
raw=(r/'assets/city/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<11918H',raw)]==list(zip(*m['planes'][:2]))
spawns=re.findall(r'\{(\d+),(\d+),(\d+)\}',(r/'src/city_spawns.h').read_text())
assert sorted((int(y)*202+int(x),int(v))for x,y,v in spawns)==sorted((i,v)for i,v in enumerate(m['planes'][2])if v in (47,45,43,52,49,31))
with ZipFile(r.parent/'reference31/keen-dreams-msx-0.9.31-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'reference31/KEEN0931.ROM').read_bytes()).hexdigest()=='669f83de1cdd4350eca70222dfeb12d77a7a0f73efc7cf217987f6f629ed45ef'
print('PASS: all 11918 original background/foreground cells and 21 object positions; baseline 0.9.31 preserved; %d unchanged previous-stage binaries; bonus cache census %s.'%(count,rows))
