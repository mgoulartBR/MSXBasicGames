"""Compare actual pre-cache and current cart C, tick by tick, on host.
Host checks semantics; ROM fixtures and emulated timings remain separate gates.
Usage: python tests/compare_cart_cache.py build/0926-baseline/cart.c
"""
from pathlib import Path
import ctypes as C, subprocess, sys, random, json
r=Path(__file__).resolve().parents[1];out=r/'build/cart-cache-equivalence';out.mkdir(exist_ok=True)
base=Path(sys.argv[1]).resolve()
header='''
#include <stdint.h>
#include <string.h>
typedef uint8_t u8;typedef int8_t i8;typedef uint16_t u16;typedef int16_t i16;
typedef struct {u16 x,y;i8 dir,delta;} Cart;
u8 world_map[9835],world_collision[1168],active_level;
u16 player_x,player_y; i16 player_vy;
u8 climbing,combat_dirty,grounded,floor_type,jump_hold;
volatile u16 camera_px,camera_py;
unsigned wall_calls;
#define MAP_WIDTH (world_collision[1120])
#define MAP_HEIGHT (world_collision[1121])
u16 MapTile(u16 i){u16 n=i+(i>>3);return (((u16)world_map[n]|((u16)world_map[n+1]<<8))>>(i&7))&511;}
'''
game=(r/'src/game.c').read_text();wall=game[game.index('static u8 Wall('):game.index('// Exact wallclip')].replace('    u16 tile;','    u16 tile;++wall_calls;').replace('GAME_COLLISION','world_collision')
mapset=(r/'src/world.c').read_text().split('void MapSet',1)[1]
footer='''
void Init(const u8* map,const u8* props){memcpy(world_map,map,9835);memcpy(world_collision,props,1168);active_level=2;CartReset();}
void Setup(int n,int x,int y,int dir){carts[n].x=x;carts[n].y=y;carts[n].dir=dir;}
void Hero(int x,int y,int vy,int climb,int ride,int cx,int cy){player_x=x;player_y=y;player_vy=vy;climbing=climb;cart_riding=ride;camera_px=cx;camera_py=cy;combat_dirty=0;}
void Step(int oldbottom){CartStep();CartContact(oldbottom);}
void State(int* s){int j=0;for(int i=0;i<3;i++){s[j++]=carts[i].x;s[j++]=carts[i].y;s[j++]=carts[i].dir;s[j++]=carts[i].delta;}s[j++]=player_x;s[j++]=player_y;s[j++]=player_vy;s[j++]=cart_riding;s[j++]=climbing;s[j++]=combat_dirty;s[j++]=grounded;s[j++]=floor_type;s[j++]=jump_hold;}
'''
libs=[]
for name,path in [('baseline',base),('candidate',r/'src/cart.c')]:
 source=path.read_text().replace('#include "cart.h"','')
 if name=='baseline':source='u8 cart_cache_valid;\n'+source
 p=out/(name+'.c');p.write_text(header+wall+source+'\nvoid MapSet'+mapset+footer)
 subprocess.run(['gcc','-shared','-fPIC','-O2','-Wall','-Wextra',str(p),'-o',str(out/(name+'.so'))],check=True)
 lib=C.CDLL(str(out/(name+'.so')));libs.append(lib)
mapdata=(C.c_ubyte*9835).from_buffer_copy((r/'assets/melon/packed_map.bin').read_bytes())
props=(C.c_ubyte*1168).from_buffer_copy((r/'assets/melon/stage_data.bin').read_bytes())
for lib in libs:lib.Init(mapdata,props)
states=[(C.c_int*21)() for _ in libs];rng=random.Random(926);checks=0

def compare():
 global checks
 for lib,s in zip(libs,states):lib.State(s)
 assert list(states[0])==list(states[1]),(checks,list(states[0]),list(states[1]))
 checks+=1
# Long original paths, offscreen, with periodic rider/contact/visibility changes.
for tick in range(30000):
 if tick%79==0:
  n=(tick//79)%3;libs[0].State(states[0]);x,y=states[0][n*4:n*4+2]
  for lib in libs:lib.Hero(x+320,y-432,0,0,255,0 if tick%2 else x>>4,y>>4)
 if tick%113==0:
  for lib in libs:lib.Hero(0,0,-40,1,255,60000,60000)
 for lib in libs:lib.Step(0xffff)
 compare()
steady=[C.c_uint.in_dll(lib,'wall_calls').value for lib in libs]
# Random coordinates, wraparound/bounds, row and direction changes, resets,
# and edits to the very cells about to be queried (also after a warmed cache).
for tick in range(10000):
 if tick%31==0:
  for lib in libs:lib.CartReset()
 if tick%7==0:
  n=rng.randrange(3);args=(n,rng.randrange(65536),rng.randrange(65536),rng.choice([-1,1]))
  for lib in libs:lib.Setup(*args)
 if tick%3==0:
  libs[0].State(states[0]);n=rng.randrange(3);x,y,d,_=states[0][4*n:4*n+4]
  nx=(x+d*32)&65535;lead=((nx+(752 if d>0 else 0))>>8)&255;row=((y+288)>>8)&255
  width=props[1120];height=props[1121]
  if lead<width and row+1<height:
   for yy in (row,row+1):
    tile=rng.randrange(292)
    for lib in libs:lib.MapSet(yy*width+lead,tile)
 if tick%11==0:
  args=(rng.randrange(65536),rng.randrange(65536),rng.randrange(-40,41),rng.randrange(2),rng.choice([0,1,2,255]),rng.randrange(3000),rng.randrange(3000))
  for lib in libs:lib.Hero(*args)
 oldbottom=rng.randrange(65536)
 for lib in libs:lib.Step(oldbottom)
 compare()
result=dict(tick_comparisons=checks,steady_ticks=30000,steady_wall_calls_baseline=steady[0],steady_wall_calls_candidate=steady[1],wall_call_reduction_percent=100*(1-steady[1]/steady[0]))
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
