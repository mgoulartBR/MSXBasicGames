"""Native ROM ending test. Explicit arena positioning fixture, real C projectiles.
Tests all three story pages, held-input protection and fresh campaign reset.
"""
from pathlib import Path
import re,subprocess,os,sys
r=Path(__file__).resolve().parents[1]
machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+'
rom=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else r/'build/keen_msx.rom'
hits=int(sys.argv[3]) if len(sys.argv)>3 else 12
initial=int(sys.argv[4]) if len(sys.argv)>4 else 0
out=r/'build'/f'0941-finale-{machine}-{hits}';out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}' for n,a in sym.items())+f'\nset expected_hits {hits}\nset initial_bombs {initial}\n'
s+=r'''
set throttle on
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set phase boot
set pages 0
set hits 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
proc hp {} {byte [expr {$::world_map+7216}]}
proc fail {msg} {screenshot -raw $::env(KEEN_TEST_OUTPUT)/failure.png;append msg " bank=[byte $::g_CurrentSegment] world=[byte $::world_active] pc=[reg PC]";set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {fail $msg}}
proc start {} {
 if {[byte $::world_active]!=1} {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 1 start};return}
 if {[byte $::world_draw_busy]} {after time 0.1 start;return}
 check {[word $::boobus_bombs]==$::initial_bombs} "Campaign initial bombs"
 set ::phase enter;putword $::world_x 704;putword $::world_y 176;putword $::boobus_bombs 50
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 0.3 entered}
}
proc entered {} {
 if {[byte $::active_level]!=11 || [byte $::world_active] || [byte $::scene_ready]!=165} {after time 0.1 entered;return}
 check {[hp]==$::expected_hits} "Boss initial HP"
 set ::phase fire;after time 0.5 fire
}
proc fixture {} {
 if {$::phase ne "fire" || ![hp]} {return}
 set a [expr {$::world_map+7200}]
 putword $a [expr {21*256}];putword [expr {$a+2}] [expr {15*256}]
 debug write memory [expr {$a+12}] 1;debug write memory [expr {$a+13}] 0
 putword $::player_x [expr {21*256-512}];putword $::player_y [expr {15*256+512}]
 putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1
}
proc fire {} {set ::before_hp [hp];keymatrixdown 3 1;after time 0.01 hit}
proc hit {} {
 if {[hp]==$::before_hp} {after time 0.01 hit;return}
 keymatrixup 3 1;set ::release_render [word $::render_count];incr ::hits
 check {[hp]==$::expected_hits-$::hits && [word $::boobus_bombs]==50-$::hits && ![byte $::death_ticks]} "Native projectile damage"
 if {[hp]} {after time 0.1 rearmed;return}
 set ::phase dying
 check {[word $::game_score]+65536*[word [expr {$::game_score+2}]]==100000} "Full 32-bit victory score"
}
proc rearmed {} {if {(([word $::render_count]-$::release_render)&65535)<2} {after time 0.1 rearmed;return};fire}
proc page {} {
 incr ::pages;set ::phase finale
 check {$::pages<=3 && ![byte $::world_active] && ![hp]} "Finale instead of world return"
 keymatrixdown 8 1
 after time 2 page_snapshot
}
proc page_snapshot {} {
 check {$::phase eq "finale"} "Held input skipped page"
 screenshot -raw $::env(KEEN_TEST_OUTPUT)/page-$::pages.png
 set f [open $::env(KEEN_TEST_OUTPUT)/page-$::pages.vram wb];puts -nonewline $f [debug read_block VRAM 0 27136];close $f
 keymatrixup 8 1
 after time 0.3 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
 if {$::pages==3} {after time 2 newgame}
}
proc newgame {} {
 if {![byte $::world_active] || [byte $::world_draw_busy]} {after time 0.1 newgame;return}
 check {$::pages==3 && [word $::world_completed]==0 && [word $::game_score]==0 && [word [expr {$::game_score+2}]]==0 && [word $::boobus_bombs]==$::initial_bombs && [byte $::game_lives]==3} "Fresh campaign resets score, progress, bombs and lives"
 screenshot -raw $::env(KEEN_TEST_OUTPUT)/newgame.png
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: $::expected_hits native C projectiles, 100000 points, 3 finale pages, held SPACE does not skip, fresh SPACE restarts campaign with reset progress/score/lives/bombs. Arena position was an explicit fixture.";close $f;exit
}
after time 3 start
after time 180 {fail "Timeout phase=$::phase pages=$::pages hits=$::hits"}
'''
s+=f'\ndebug set_bp {sym["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {sym["FinaleAck"]&65535} {{[byte $::g_CurrentSegment]==99}} page\n'
(out/'test.tcl').write_text(s)
for n in ['PASS.txt','FAIL.txt']:
 (out/n).unlink(missing_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine',machine,'-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=180,check=True)
assert not (out/'FAIL.txt').exists(),(out/'FAIL.txt').read_text()
assert (out/'PASS.txt').exists(),(out/'emulator.log').read_text()
print((out/'PASS.txt').read_text())
