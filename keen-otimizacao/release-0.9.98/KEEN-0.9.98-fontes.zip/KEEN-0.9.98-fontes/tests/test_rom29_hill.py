"""ROM render/interaction fixtures at original spawns, plus keyboard-only entry.
State-controlled render fixtures are separate from natural-input checks.
"""
from pathlib import Path
import os,re,subprocess,sys,json
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0929-hill-rom' if machine=='C-BIOS_MSX2+' else '0929-hill-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_TEST_OUTPUT=str(out))
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
syms['WorldInput']=int(re.search(r'([0-9A-F]{8})\s+\d+ _WorldInput:',(r/'src/out/keen_msx_s8_b1.lst').read_text())[1],16)+0x8000
s='\n'.join(f'set {n} {a}' for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set row8 0
set names {}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc actor {i} {expr {$i==11?$::enemy:$::world_map+9600+16*$i}}
proc fixture {} {if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc control {} {
 if {$::phase==0} {
  if {[byte $::world_active]!=1} {return}
  if {[word $::world_x]>704} {keys 16} else {keys 1;set ::phase 1;after time 0.3 {keys 0}}
 } elseif {$::phase==1} {
  if {[byte $::world_active]!=0 || [byte $::active_level]!=1 || [byte $::scene_ready]!=165} {return}
  keys 0;set ::phase 2;set ::startx [word $::player_x];set ::starty [word $::player_y]
  after time 0.4 {keys 17;after time 1 {keys 0;after time 0.5 natural_done}}
 }
}
proc natural_done {} {
 check {[word $::player_x]<$::startx} "Keyboard movement from original spawn"
 check {![byte $::death_ticks]} "Natural starting movement survives"
 # Controlled visual tests begin here. Original enemy positions are preserved.
 set ::phase 3;keys 0;debug write memory $::enemy_mode 1;set ::held 1;set ::index 0;set ::pose 0
 next_pose
}
proc next_pose {} {
 if {$::index==12} {
  set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: keyboard-only Tuberia entry and initial movement/jump; original twelve spawn neighborhoods; all carrot and Tater poses, both directions and flowers captured in actual ROM.";close $f;exit;return
 }
 set a [actor $::index]
 set x [word $a];set y [word [expr {$a+2}]]
 set ::hx [expr {$x>112*16?$x-80*16:32*16}];set ::hy [expr {$y>16*16?$y:16*16}]
 set frame [expr {$::index<4 || $::index==11?16+$::pose:124+$::pose}]
 if {$::index>=4 && $::index<11 && $::pose==12} {set frame 26}
 debug write memory [expr {$a+11}] $frame
 debug write memory [expr {$a+13}] [expr {$frame>=26 && $frame<=29?1:0}]
 after time 1.2 pose_ready
}
proc pose_ready {} {
 set name "actor-$::index-pose-$::pose"
 # Settle the renderer before recording both the state and the framebuffer.
 if {[byte $::render_commit]} {after time 0.001 pose_ready;return}
 set a [actor $::index];check {[byte [expr {$a+10}]]==1} "Original actor wakes at camera"
 set slot [expr {$::index==11?1:15+$::index}]
 set old [expr {$::actors_old+[byte $::front_page]*174+$slot*6}]
 if {[byte [expr {$old+4}]]!=[byte [expr {$a+11}]]} {after time 0.01 pose_ready;return}
 snap $name;lappend ::names $name
 incr ::pose
 set limit [expr {$::index<4 || $::index==11?14:13}]
 if {$::pose==$limit} {incr ::index;set ::pose 0}
 next_pose
}
set phase 0
# Leave diagnostics and title with normal keyboard input only.
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n' for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["WorldInput"]&65535} {{[byte $::g_CurrentSegment]==8}} control\n'
s+=f'\ndebug set_bp {syms["ReadInput"]&65535} {{[byte $::g_CurrentSegment]==31}} control\n'
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+='after time 300 {check {0} "Timeout phase=$::phase world=[byte $::world_active] x=[word $::world_x]"}\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=180)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
names=(out/'names.txt').read_text().splitlines()
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
(out/'VERIFIED.txt').write_text(f'PASS: independent full viewport pixel reconstruction for {len(names)} original actor/pose snapshots.\n')
print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
