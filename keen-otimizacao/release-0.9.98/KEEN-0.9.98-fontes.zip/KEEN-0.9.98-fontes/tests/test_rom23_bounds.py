"""Controlled regression and emulated-time A/B; not hardware gameplay evidence."""
from pathlib import Path
import os, subprocess, sys, re
root=Path(__file__).resolve().parents[1]
case=sys.argv[1] if len(sys.argv)>1 else 'candidate'
assert case in ('baseline','candidate','pixels','baselinepixels')
boot='''
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
'''
frequency=int(sys.argv[2]) if len(sys.argv)>2 else 3579545
out=root/'build'/('0923-'+case+('' if frequency==3579545 else '-'+str(frequency)));out.mkdir(exist_ok=True)
rom=root/'build/keen_msx.rom';mp=root/'build/keen_msx.map'
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_TEST_OUTPUT=str(out))
if case.endswith('pixels'):
 for name in ('game','world','keydoor','redraw'):
  subprocess.run([sys.executable,str(root/f'tests/make_{name}_test.py'),str(root)],check=True)
 script=(root/'build/redraw-test.tcl').read_text().replace('after time 10 {','after time 40 {',1).replace('after time 50 {','after time 80 {')+boot
 (out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
else:
 if case=='baseline':rom=root/'build/0923-baseline/keen_msx.rom';mp=root/'build/0923-baseline/keen_msx.map'
 subprocess.run([sys.executable,str(root/'tests/make_redraw_bench.py'),str(root),str(mp),str(out/'test.tcl')],check=True)
 script=(out/'test.tcl').read_text().replace('after time 10 {','after time 40 {',1).replace('after time 80 {','after time 110 {')+boot
 (out/'bench.txt').write_text('')
if case=='baselinepixels':
 rom=root/'build/0923-baseline/keen_msx.rom'
 symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/0923-baseline/keen_msx.map').read_text(),re.M)}
 current={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
 for n,a in current.items():
  if n in symbols:
   script=re.sub(r'(?m)^(set \w+ )'+str(a)+r'$',lambda m:m[1]+str(symbols[n]),script)
if case in ('baseline','candidate'):
 symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
 script=script.replace('set ::frames [word $::render_count];set ::started [machine_info time]', 'set ::profile_enabled 1;set ::profile_count 0;set ::profile_time 0;set ::frames [word $::render_count];set ::started [machine_info time]')
 script=script.replace('proc finish {mode} {','proc finish {mode} {\n set ::profile_enabled 0')
 script=script.replace('seconds=[expr {[machine_info time]-$::started}]"', 'seconds=[expr {[machine_info time]-$::started}] prepare_calls=$::profile_count prepare_seconds=$::profile_time"')
 script+=f"\nset prepare_addr {symbols['ActorsPrepare']&65535}\nset current_segment {symbols['g_CurrentSegment']}\n"
 script+=r'''
set profile_enabled 0
set profile_pending 0
proc prepare_leave {} {
 debug remove_bp $::profile_bp
 if {$::profile_enabled} {
  incr ::profile_count
  set ::profile_time [expr {$::profile_time+[machine_info time]-$::profile_start}]
 }
 set ::profile_pending 0
}
debug set_bp $prepare_addr {$profile_enabled && !$profile_pending && [debug read memory $current_segment]==14} {
 set ::profile_start [machine_info time]
 set ::profile_pending 1
 set ::profile_sp [expr {([reg SP]+2)&65535}]
 set ::profile_bp [debug set_bp [word [reg SP]] {[reg SP]==$profile_sp} {prepare_leave}]
}
'''
script=f'set z80_freq {frequency}\nset z80_freq_locked false\n'+script
(out/'test.tcl').write_text(script)
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=100,check=True)
if case.endswith('pixels'):
 assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
 assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
 env['KEEN_STAGE']='2'
 subprocess.run([sys.executable,str(root/'tests/verify_game_pixels.py'),str(out),'overlap','retained','separated','removed','scrolled','returned'],env=env,check=True)
 print((out/'PASS.txt').read_text())
else:
 result=(out/'bench.txt').read_text();assert len(result.splitlines())==4,result
 print(case,result,flush=True)
