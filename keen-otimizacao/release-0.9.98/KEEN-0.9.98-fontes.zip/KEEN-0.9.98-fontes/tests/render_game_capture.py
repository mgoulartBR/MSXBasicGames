"""Render the captured displayed VRAM (headless screenshots can be stale)."""
from pathlib import Path
from PIL import Image
import re,sys
r=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);name=sys.argv[2]
v=list(map(int,(out/f'{name}.txt').read_text().splitlines()[0].split()));cx,hw,cy=v[6:9]
raw=(out/f'{name}.vram').read_bytes();height=192 if hw else 176
p=re.search(r'scene_palette\[\]\s*=\s*\{([^}]+)',(r/'src/scene_data.h').read_text())[1]
nums=[int(n,0)for n in re.findall(r'0x[0-9A-Fa-f]+|\d+',p)]
palette=[(round((nums[i]>>4)*255/7),round(nums[i+1]*255/7),round((nums[i]&7)*255/7))for i in range(0,32,2)]
pixels=[]
for y in range(height):
 for x in range(256):
  xx=(cx+x)&255 if hw else x;yy=(cy+y)&255 if hw else y+16
  b=raw[yy*128+xx//2];pixels.append(palette[(b&15)if xx&1 else(b>>4)])
im=Image.new('RGB',(256,height));im.putdata(pixels)
im.resize((768,height*3),Image.Resampling.NEAREST).save(out/f'{name}-display.png')
