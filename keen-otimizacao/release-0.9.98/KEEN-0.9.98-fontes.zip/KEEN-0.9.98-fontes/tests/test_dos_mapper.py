"""Execute the COM on real emulated mapped RAM with DOS/EXTBIO protocol fixtures.
Not an MSX-DOS/SofaRun integration test and not a timing measurement.
"""
from pathlib import Path
import re,subprocess,os
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/dos/kmap14.map').read_text(),re.M)}
for name,status,alloc,free,calls in [('pass',0,1,1,32768),('no-api',3,0,0,0),('no-free',4,0,0,0),('alloc-fail',4,1,0,0),('bad-checksum',7,1,1,32768)]:
 out=r/'build'/('0914-dos-'+name);out.mkdir(exist_ok=True)
 script=f'''set throttle off
set save_settings_on_exit false
set started 0
set launch 0
set page2 1
set alloc_calls 0
set free_calls 0
set ram_calls 0
set screen ""
proc bytes {{a vals}} {{foreach v $vals {{debug write memory $a $v;incr a}}}}
proc ret {{}} {{set a [reg SP];reg PC [expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}];reg SP [expr {{$a+2}}]}}
proc finish {{}} {{
 set f [open {{{out/'result.txt'}}} w]
 puts $f "status [debug read memory {s['status']}] alloc $::alloc_calls free $::free_calls ram $::ram_calls page2 $::page2"
 close $f
 set f [open {{{out/'screen.txt'}}} w];puts $f $::screen;close $f
 exit
}}
after time 3 {{set launch 1}}
debug set_bp 0x38 {{$launch && !$started}} {{
 reg IFF 0
 debug write memory 0xffff 170
 debug write ioports 0xfc 3
 debug write ioports 0xfd 2
 debug write ioports 0xfe 1
 debug write ioports 0xa8 255
 set f [open {{{r/'build/dos/KMAP14.COM'}}} rb];debug write_block memory 256 [read $f];close $f
 bytes 0 {{195 128 241 0 0 195 128 241}}
 bytes 0xf000 {{243 195 0 1}}
 bytes 0xf100 {{139 32 {0 if name=='no-free' else 8} 6 18 0 0 0}}
 bytes 0xf120 {{195 0 242 195 16 242}}
 bytes 0xf144 {{195 32 242 195 48 242}}
 debug write memory 0xfb20 {0 if name=='no-api' else 1}
 reg SP 0xf380
 reg PC 0xf000
 set started 1
}}
debug set_bp 5 {{$started}} {{
 if {{[reg C]==9}} {{set p [reg DE];while {{[debug read memory $p]!=36}} {{append screen [format %c [debug read memory $p]];incr p}}}}
 if {{[reg C]==2}} {{append screen [format %c [reg E]]}}
 ret
}}
debug set_bp 0 {{$started}} {{finish}}
debug set_bp 0xffca {{$started}} {{
 if {{[reg DE]==0x0401}} {{reg A 139;reg HL 0xf100}}
 if {{[reg DE]==0x0402}} {{reg A 32;reg B 139;reg C {0 if name=='no-free' else 8};reg HL 0xf120}}
 ret
}}
debug set_bp 0xf200 {{$started}} {{
 incr alloc_calls
 reg A 7;reg B 0;reg F [expr {{([reg F]&254)|{1 if name=='alloc-fail' else 0}}}];ret
}}
debug set_bp 0xf210 {{$started}} {{incr free_calls;reg F [expr {{[reg F]&254}}];ret}}
debug set_bp 0xf220 {{$started}} {{set page2 [reg A];debug write ioports 0xfe $page2;ret}}
debug set_bp 0xf230 {{$started}} {{reg A $page2;ret}}
debug set_bp 0x8000 {{$started && $page2==7}} {{incr ram_calls}}
'''
 if name=='bad-checksum':script+=f'debug set_bp {s["kernel"]} {{$started}} {{debug write memory {s["tiledata"]} 255}}\n'
 script+='after time 100 {finish}\n'
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-script',str(out/'test.tcl')],env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=log,stderr=log,timeout=80,check=True)
 result=(out/'result.txt').read_text().strip();print(name,result,flush=True)
 assert result==f'status {status} alloc {alloc} free {free} ram {calls} page2 1'
 assert ('PASS: CODE EXECUTED' in (out/'screen.txt').read_text())==(name=='pass')
