from pathlib import Path
import re,sys,json
r=Path(sys.argv[1]);out=Path(sys.argv[2]);stage=int(sys.argv[3])
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
m=next(m for m in json.loads((r/'assets/generated/maps.json').read_text()) if m['id']==(14 if stage==10 else 12 if stage==9 else 10 if stage==8 else 9 if stage==7 else 7 if stage==6 else stage))
bonuses=[(i%m['width']*16,i//m['width']*16,v) for i,v in enumerate(m['planes'][2]) if 21<=v<=28]
first=next(b for b in bonuses if b[2]==21)
s='\n'.join(f'set {n} {v}' for n,v in syms.items())+f'\nset stage {stage}\nset bx {first[0]}\nset by {first[1]}\n'
s+=r'''
set throttle off
set save_settings_on_exit false
# Dismiss the startup title before the existing gameplay fixtures.
after time 3 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
set renderer SDL
set sound_driver null
set z80_freq 7159090
set z80_freq_locked false
set fixture_on 0
set fixture_calls 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc long {a} {expr {[word $a]+65536*[word [expr {$a+2}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc putlong {a n} {putword $a $n;putword [expr {$a+2}] [expr {$n>>16}]}
proc check {c msg} {
 if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}
}
proc fixture {} {
 if {$::fixture_on} {
  incr ::fixture_calls
  putword $::player_x [expr {($::bx-4)*16}];putword $::player_y [expr {($::by-3)*16}]
  putword $::player_vx 0;putword $::player_vy 0
 }
}
proc begin {} {
 if {$::stage==10 && ([word $::drawn_x]!=69*256 || [byte $::render_commit] || [byte [expr {$::world_collision+1120}]]!=74)} {after time 0.1 begin;return}
 if {$::stage==8 && ([byte $::scene_ready]!=165 || [byte $::active_level]!=8 || [byte $::world_active] || [byte [expr {$::world_collision+1120}]]!=139)} {after time 0.1 begin;return}
 check {[byte $::active_level]==$::stage && [byte $::scene_ready]==165} "Stage loaded"
 check {[long $::game_score]==0 && [byte $::game_lives]==3} "New game defaults"
 debug write memory $::enemy_mode 1
 set ::fixture_on 1
 after time 0.8 collected
}
proc collected {} {
 if {$::stage==10 && $::fixture_calls<2} {after time 0.1 collected;return}
 check {[long $::game_score]==100} "Original peppermint gives 100, once: actual=[long $::game_score]"
 check {[word $::flower_ammo]==0} "Candy does not grant ammo"
 set ::fixture_on 0
 # Death must restore objects and retain score/ammunition.
 putword $::flower_ammo 7
 debug write memory $::key_owned 1;debug write memory $::key_taken 1;debug write memory $::door_state 2
 if {$::stage!=2} {
  putword $::player_y [expr {([byte [expr {$::world_collision+1121}]]-2)*256}]
 } else {
  debug write memory $::enemy_mode 0
  putword $::enemy [word $::player_x];putword [expr {$::enemy+2}] [word $::player_y]
  debug write memory [expr {$::enemy+10}] 1;debug write memory [expr {$::enemy+13}] 0
 }
 after time 3 restarted
}
proc restarted {} {
 if {$::stage==10 && ([byte $::restart_pending] || [byte $::death_ticks] || [word $::drawn_x]!=69*256 || [byte $::render_commit])} {after time 0.1 restarted;return}
 if {$::stage==8 && ([word $::drawn_x]!=3*256 || [byte $::render_commit])} {after time 0.1 restarted;return}
 debug write memory $::enemy_mode 1
 check {[byte $::game_lives]==2 && ![byte $::death_ticks] && ![byte $::restart_pending]} "Death consumes exactly one reserve: life=[byte $::game_lives] restart=[byte $::restart_pending] death=[byte $::death_ticks]"
 check {[long $::game_score]==100 && [word $::flower_ammo]==7} "Score and ammo survive death"
 check {![long $::bonus_taken] && ![long $::pickup_taken]} "Collectibles restored"
 check {![byte $::key_owned] && ![byte $::key_taken] && ![byte $::door_state]} "Key and door reset"
 putlong $::game_score 19900
 set ::fixture_on 1
 after time 0.8 extra
}
proc extra {} {
 check {[long $::game_score]==20000 && [byte $::game_lives]==3 && [long $::next_extra]==40000} "20k grants one reserve and doubles threshold"
 set ::fixture_on 0
 set throttle on
 after time 0.3 {
  screenshot -raw $::env(KEEN_TEST_OUTPUT)/score-lives.png
  debug write memory $::game_lives 0
  debug write memory $::death_ticks 2
  after time 2 over
 }
}
proc over {} {
 check {[byte $::game_lives]==255 && [byte $::restart_pending]==2} "Zero reserves leads to Game Over"
 set f [open $::env(KEEN_TEST_OUTPUT)/game-over.vram wb];puts -nonewline $f [debug read_block VRAM 0 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/game-over.regs wb];puts -nonewline $f [debug read_block {VDP regs} 0 64];close $f
 screenshot -raw $::env(KEEN_TEST_OUTPUT)/game-over.png
 keymatrixdown 8 1
 after time 0.2 {keymatrixup 8 1}
 after time 3 fresh
}
proc fresh {} {
 check {[byte $::world_active]==1 && [long $::game_score]==0 && [byte $::game_lives]==3 && [word $::flower_ammo]==0 && [byte $::world_completed]==0} "New game resets campaign and returns to Tuberia"
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: collection, duplicate prevention, score, extra life, death/restart, key/door, retained ammo, Game Over, new campaign; stage $::stage";close $f;exit
}
after time 10 {
 if {$::stage==10} {debug write memory $::enemy_mode 1;putword $::world_x 1216;putword $::world_y 512} elseif {$::stage==9} {putword $::world_x 928;putword $::world_y 512} elseif {$::stage==8} {putword $::world_x 48;putword $::world_y 352} elseif {$::stage==7} {putword $::world_x 208;putword $::world_y 384} elseif {$::stage==6} {putword $::world_x 160;putword $::world_y 608} elseif {$::stage==5} {putword $::world_x 1264;putword $::world_y 704} elseif {$::stage==4} {putword $::world_x 256;putword $::world_y 880} elseif {$::stage==3} {putword $::world_x 848;putword $::world_y 848} elseif {$::stage==2} {putword $::world_x 608;putword $::world_y 448} else {putword $::world_x 688;putword $::world_y 624}
 keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 begin
}
after time 45 {check {0} "Timeout"}
'''
s+=f'\ndebug set_bp {syms["BonusTick"]&65535} {{[byte $::g_CurrentSegment]==29}} fixture\n'
out.write_text(s)
