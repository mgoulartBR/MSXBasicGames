"""Execute the COM on real emulated mapped RAM with DOS/EXTBIO protocol fixtures.
Not an MSX-DOS/SofaRun integration test and not a timing measurement.
"""
from pathlib import Path
import re,subprocess,os
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/dos/kcore17.map').read_text(),re.M)}
for name,status,alloc,free,calls in [('pass',0,1,1,2),('no-api',3,0,0,0),('no-free',4,0,0,0),('alloc-fail',4,1,0,0),('cpu-1',0,1,1,2),('cpu-2',0,1,1,2),('cpu-3',0,1,1,2),('tpa-d406',0,1,1,2),('tpa-min',0,1,1,2),('tpa-low',1,0,0,0),('bad-read-entry',0,0,0,0)]:
 out=r/'build'/('0917-dos-'+name);out.mkdir(exist_ok=True)
 com=r/'build/dos/KCORE17.COM'
 if name=='bad-read-entry':
  data=bytearray(com.read_bytes());needle=bytes.fromhex('3ac1fc212d00cd0c00')
  assert data.count(needle)==1
  pos=data.index(needle)+7;data[pos]=0x14
  com=out/'wrong-entry.com';com.write_bytes(data)
 script=f'''set throttle off
set save_settings_on_exit false
set started 0
set launch 0
set page2 1
set alloc_calls 0
set free_calls 0
set ram_calls 0
set screen ""
set cpu 0
set reads 0
proc bytes {{a vals}} {{foreach v $vals {{debug write memory $a $v;incr a}}}}
proc ret {{}} {{set a [reg SP];reg PC [expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}];reg SP [expr {{$a+2}}]}}
proc fail {{msg}} {{set f [open {{{out/'result.txt'}}} w];puts $f "FAIL $msg";close $f;exit}}
proc finish {{}} {{
 if {{$::reads!={0 if name=='tpa-low' else 1}}} {{fail "RDSLT count"}}
 if {{[debug read_block memory 0xc800 10240] ne $::protected}} {{error "Memory above private stack changed"}}
 set f [open {{{out/'result.txt'}}} w]
 puts $f "status [debug read memory {s['status']}] alloc $::alloc_calls free $::free_calls ram $::ram_calls page2 $::page2"
 if {{$::cpu!=0}} {{error "CPU not restored"}}
 close $f
 set f [open {{{out/"low.bin"}}} wb];puts -nonewline $f [debug read_block memory 256 {(r/'build/dos/KCORE17.COM').stat().st_size}];close $f
 set f [open {{{out/"core.bin"}}} wb];puts -nonewline $f [debug read_block memory 0xc100 30];close $f
 set f [open {{{out/'screen.txt'}}} w];puts $f $::screen;close $f
 exit
}}
after time 3 {{set launch 1}}
debug set_bp 0x38 {{$launch && !$started}} {{
 reg IFF 0
 set page3data [debug read_block memory 0xc000 16383]
 debug write ioports 0xff 0
 debug write_block memory 0xc000 $page3data
 debug write memory 0xffff 170
 debug write ioports 0xfc 3
 debug write ioports 0xfd 2
 debug write ioports 0xfe 1
 debug write ioports 0xa8 255
 set f [open {{{com}}} rb];debug write_block memory 256 [read $f];close $f
 bytes 0x80 {{{2 if name.startswith("cpu-") else 0} 32 {ord(name[-1]) if name.startswith("cpu-") else 0}}}
 bytes 0 {{195 128 241 0 0 195 6 {0xc7 if name=="tpa-low" else 0xc8 if name=="tpa-min" else 0xd4}}}
 bytes 0x38 {{245 219 153 241 251 237 77}}
 bytes 0xf000 {{243 195 0 1}}
 bytes 0xf100 {{139 32 {0 if name=='no-free' else 8} 6 18 0 0 0}}
 bytes 0xf120 {{195 0 242 195 16 242}}
 bytes 0xf144 {{195 32 242 195 48 242}}
 debug write memory 0xfcc0 0
 debug write memory 0xfcc1 128
 debug write memory 0xfb20 {0 if name=='no-api' else 1}
 reg SP {0xc7f0 if name=="tpa-low" else 0xc804 if name=="tpa-min" else 0xd404}
 reg PC 0xf000
 set protected [debug read_block memory 0xc800 10240]
 set started 1
}}
debug set_bp 0x14 {{$started}} {{fail "WRSLT called instead of DOS RDSLT"}}
debug set_bp 0x0c {{$started}} {{
 if {{[reg A]!=128 || [reg HL]!=0x2d}} {{fail "RDSLT slot/address"}}
 incr reads;reg A {3 if name.startswith('cpu-') else 2};ret
}}
debug set_bp 0x1c {{$started}} {{
 if {{([reg IY]>>8)!=128}} {{fail "CALSLT BIOS slot"}}
 if {{[reg IX]==0x183}} {{reg A $cpu}} elseif {{[reg IX]==0x180 && [reg A] in {{0 129 130}}}} {{set cpu [expr {{[reg A]&3}}]}} else {{fail "CALSLT CPU entry/argument"}}
 ret
}}

debug set_bp 5 {{$started}} {{
 if {{[reg C]==9}} {{set p [reg DE];while {{[debug read memory $p]!=36}} {{append screen [format %c [debug read memory $p]];incr p}}}}
 if {{[reg C]==2}} {{append screen [format %c [reg E]]}}
 ret
}}
debug set_bp 0 {{$started}} {{
 if {{[reg SP]!={0xc7f0 if name=="tpa-low" else 0xc804 if name=="tpa-min" else 0xd404}}} {{error "Entry SP not restored"}}
 finish
}}
debug set_bp 0xffca {{$started}} {{
 if {{[reg DE]==0x0401}} {{reg A 139;reg HL 0xf100}}
 if {{[reg DE]==0x0402}} {{reg A 32;reg B 139;reg C {0 if name=='no-free' else 8};reg HL 0xf120}}
 ret
}}
debug set_bp 0xf200 {{$started}} {{
 incr alloc_calls
 reg A 7;reg B 0;reg F [expr {{([reg F]&254)|{1 if name=='alloc-fail' else 0}}}];ret
}}
debug set_bp 0xf210 {{$started}} {{incr free_calls;reg F [expr {{[reg F]&254}}];ret}}
debug set_bp 0xf220 {{$started}} {{set page2 [reg A];debug write ioports 0xfe $page2;ret}}
debug set_bp 0xf230 {{$started}} {{reg A $page2;ret}}
debug set_bp 0x8000 {{$started && $page2==7}} {{incr ram_calls}}
'''

 script+='after time 100 {finish}\n'
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-script',str(out/'test.tcl')],env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=log,stderr=log,timeout=80,check=True)
 result=(out/'result.txt').read_text().strip();print(name,result,flush=True)
 if name=='bad-read-entry':
  assert result=='FAIL WRSLT called instead of DOS RDSLT'
  continue
 assert result==f'status {status} alloc {alloc} free {free} ram {calls} page2 1'
 assert (out/'low.bin').read_bytes()==(r/'build/dos/KCORE17.COM').read_bytes(), 'COM code corrupted'
 if name.startswith('cpu-'):
  assert f'CPU: 0{int(name[-1])-1}' in (out/'screen.txt').read_text()
 assert ('COMPLETE; COMPARE TRACE' in (out/'screen.txt').read_text())==(status==0)

 if status==0:assert 'TRACE: 9775 STEPS: 0AF0' in (out/'screen.txt').read_text()
