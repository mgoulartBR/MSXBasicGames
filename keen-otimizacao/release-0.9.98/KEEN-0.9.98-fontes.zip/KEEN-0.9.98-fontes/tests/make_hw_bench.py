from pathlib import Path
import sys,re
r=Path(sys.argv[1]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s=(r/'build/hw-test.tcl').read_text().split('set throttle on\nset fixture_frame')[0]
s+='\nset throttle off\nset z80_freq 7159090\nset z80_freq_locked false\nset enabled 0\nset hw_disabled 1\nset hw_count 0\nset hw_total 0\n'
s+=r'''
proc hold_bench {} {
 if {!$::enabled} {return}
 place 1240 192
 debug write memory $::enemy_mode 0
 debug write memory $::combat_dirty 1
 after time 0.03 hold_bench
}
proc bench_fixture {} {
 if {!$::enabled} {return}
 debug write memory $::cpu_mode 4
 set t [expr {$::world_collision+1026}]
 foreach {i x} {0 1130 1 1200 2 1320} {
  set a [expr {$t+$i*13}];putword $a [expr {$x*16}];putword [expr {$a+2}] 3520
  debug write memory [expr {$a+8}] 1
  if {[byte [expr {$a+9}]]<90} {debug write memory [expr {$a+9}] 90}
 }
 for {set i 3} {$i<6} {incr i} {debug write memory [expr {$t+$i*13+8}] 0}
 debug write memory [expr {$::enemy+10}] 0
 debug write memory [expr {$::world_collision+1128}] $::hw_disabled
}
proc measure_hw {run} {
 set ::hw_count 0;set ::hw_total 0;set ::hw_started [machine_info time]
 after time 10 [list finish_hw $run]
}
proc finish_hw {run} {
 set f [open $::env(KEEN_TEST_OUTPUT)/bench.txt a]
 puts $f "run=$run disabled=$::hw_disabled frames=$::hw_total hardware_frames=$::hw_count seconds=[expr {[machine_info time]-$::hw_started}]"
 close $f
 if {$run<3} {set ::hw_disabled [expr {1-$::hw_disabled}];after time 1 [list measure_hw [expr {$run+1}]]} else {exit}
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {set ::enabled 1;hold_bench;after time 1 {measure_hw 0}}
}
after time 70 {exit}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} bench_fixture\n'
s+=f'debug set_bp {syms["DiagCapture"]&65535} {{[byte {syms["g_CurrentSegment"]}]==14 && $::enabled}} '+r'{incr ::hw_total;if {[byte [expr {$::world_collision+1130}]]==0} {incr ::hw_count}}'+'\n'
(r/'build/hw-bench.tcl').write_text(s)
