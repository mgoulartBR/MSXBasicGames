"""Three identical high falls, injected only at a completed render boundary."""
from pathlib import Path
import re,sys
m=Path(sys.argv[1]);out=Path(sys.argv[2]);d={n:int(a,16)for a,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',m.read_text())}
s='\n'.join(f'set {n} {d[n]}' for n in ['render_count','render_commit','player_y','player_vy','grounded','enemy_mode','pickup_taken','drawn_camera_py','cost_edges','cost_restore','cost_actor','cost_game','full_redraws'])
s+=r'''
set throttle off
set save_settings_on_exit false
set launch 0
set records {}
set watch_id [debug set_watchpoint write_mem $render_count {} {
 if {$::launch} {
  set ::launch 0
  debug write memory $::player_y 0;debug write memory [expr {$::player_y+1}] 4
  debug write memory $::player_vy 0;debug write memory [expr {$::player_vy+1}] 0
  debug write memory $::grounded 0
  debug write memory $::enemy_mode 3
  debug write memory $::pickup_taken 255;debug write memory [expr {$::pickup_taken+1}] 3
 }
}]
proc word {a} {expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}}
proc start_drop {} {
 set ::launch 1;keymatrixdown 4 128
 after time 0.04 {keymatrixup 4 128}
}
proc sample {} {
 incr ::f
 set n [word $::render_count]
 if {$n!=$::last && ![debug read memory $::render_commit]} {
  set y [word $::drawn_camera_py]
  lappend ::records "[expr {$::f-$::prev}],$y,[expr {$y-$::oldy}],[debug read memory $::cost_edges],[debug read memory $::cost_restore],[debug read memory $::cost_actor],[debug read memory $::cost_game],[word $::full_redraws]"
  set ::prev $::f;set ::last $n;set ::oldy $y
 }
 if {$::f<600} {after frame sample} else {
  set o [open $::env(KEEN_BENCH_OUT) w]
  puts $o "interval,camera_y,delta_y,edges,restore,actors,game,full_redraws"
  puts $o [join $::records \n];close $o;exit
 }
}
after time 10 {
 set f 0;set prev 0;set last [word $render_count];set oldy [word $drawn_camera_py]
 start_drop;after time 3 start_drop;after time 6 start_drop
 after frame sample
}
'''
if __import__('os').environ.get('KEEN_DROP_PIXELS'):
 header=(m.parent/'game-test.tcl').read_text().split('after time 10 {')[0]
 header=header.replace(' screenshot -raw $::env(KEEN_TEST_OUTPUT)/$name.png','')
 s=header+s
 s=s.replace('  set ::prev $::f;', '  if {$y>$::oldy} {snap drop$::f}\n  set ::prev $::f;')
out.write_text(s)
