from pathlib import Path
import sys,re
r=Path(sys.argv[1]);s=(r/'build/world-test.tcl').read_text().split('after time 10 {')[0]
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s+=f'\nset raw_simulation_ticks {syms["simulation_ticks"]}\n'
s+=r'''
proc place_above_cart {n} {
 if {[byte $::render_commit]} {after time 0.001 [list place_above_cart $n];return}
 set a [expr {$::carts+$n*6}]
 putword $::raw_player_x [expr {[word $a]+320}]
 putword $::raw_player_y [expr {[word [expr {$a+2}]]-432}]
 putword $::raw_player_vx 0;putword $::raw_player_vy 0
 debug write memory $::cart_riding 255
 debug write memory $::climbing 0
 debug write memory $::combat_dirty 1
}
proc landed {n} {
 if {[word $::simulation_ticks]!=[word $::raw_simulation_ticks]} {after time 0.001 [list landed $n];return}
 if {[byte $::cart_riding]!=$n} {after time 0.02 [list landed $n];return}
 set ::offset [expr {[word $::player_x]-[word [expr {$::carts+$n*6}]]}]
 snap cart${n}_land
 after time 0.8 [list carried $n]
}
proc carried {n} {
 if {[word $::simulation_ticks]!=[word $::raw_simulation_ticks]} {after time 0.001 [list carried $n];return}
 check {[byte $::cart_riding]==$n} "Remain aboard cart $n"
 # Stable player publication may precede the live cart record by one tick.
 set delta [expr {[word $::player_x]-[word [expr {$::carts+$n*6}]]-$::offset}]
 check {abs($delta)<=32} "Cart carries rider without sliding"
 snap cart${n}_ride
 keymatrixdown 8 1
 set ::jump_started [machine_info time]
 after time 0.01 [list airborne $n]
}
proc airborne {n} {
 if {[byte $::cart_riding]!=255 || [byte $::grounded]} {
  check {[machine_info time]-$::jump_started<3} "Jump off cart $n"
  after time 0.01 [list airborne $n];return
 }
 keymatrixup 8 1
 snap cart${n}_jump
 if {$n<2} {after time 1 [list place_above_cart [expr {$n+1}]];after time 1.01 [list landed [expr {$n+1}]]} else {
  after time 0.5 {
   set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: all three carts support landing, carry and jumping off. Isolated fixtures reposition Keen above each cart.";close $f;exit
  }
 }
}
after time 40 {
 # Fixture selection only; keyboard-only completion has a separate test.
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2 && [byte $::scene_ready]==165} "Melon loaded"
  place_above_cart 0
  after time 0.02 {landed 0}
 }
}
after time 100 {check {0} "Cart fixture timeout"}
'''
s+='\nafter time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}\nafter time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}\n'
(r/'build/cart-test.tcl').write_text(s)
