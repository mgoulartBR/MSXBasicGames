from pathlib import Path
import re,sys
r=Path(sys.argv[1]);out=Path(sys.argv[2]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {v}' for n,v in syms.items())+r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc mode {} {expr {[debug read {VDP regs} 0]&14}}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc waitfor {c cb} {if {[expr $c]} {eval $cb} else {after time 0.05 [list waitfor $c $cb]}}
proc capture {name} {
 screenshot $::env(KEEN_TEST_OUTPUT)/$name.png
 foreach {suffix device size} {vram VRAM 131072 regs {VDP regs} 64 palette {VDP palette} 32} {
  set f [open $::env(KEEN_TEST_OUTPUT)/$name.$suffix wb];puts -nonewline $f [debug read_block $device 0 $size];close $f
 }
}
proc world {} {
 check {[mode]==6} "SCREEN 5 restored"
 check {[byte $::scene_ready]==0} "Space did not auto-enter stage"
 after time 0.3 world_ready
}
proc world_ready {} {
 capture tuberia
 putword $::world_x 848;putword $::world_y 848
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
 waitfor {[byte $::scene_ready]==165 && [byte $::active_level]==3} stage
}
proc stage {} {
 check {[mode]==6} "Bridge runs in SCREEN 5"
 check {[byte [expr {$::world_collision+1127}]]==23} "Collectibles loaded"
 after time 0.3 finished
}
proc finished {} {
 capture bridge
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
 puts $f "PASS: static SCREEN 7 title, press-and-release gate, SCREEN 5/palette transition to Tuberia, no accidental level entry, Bridge loaded with collectibles."
 close $f;exit
}
after time 10 {
 check {[mode]==10 && [byte $::scene_ready]==0} "Title waits in SCREEN 7"
 capture title
 keymatrixdown 8 1
 after time 1 {
  check {[mode]==10 && [byte $::scene_ready]==0} "Held space waits for release"
  keymatrixup 8 1;waitfor {[byte $::world_active]==1} world
 }
}
after time 40 {check {0} "Timeout"}
'''
out.write_text(s)
