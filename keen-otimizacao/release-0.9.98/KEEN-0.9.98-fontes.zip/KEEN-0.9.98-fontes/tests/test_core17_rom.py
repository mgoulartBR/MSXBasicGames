from pathlib import Path
import subprocess,os,struct
r=Path(__file__).resolve().parents[1];out=r/'build/0917-core-rom';out.mkdir(exist_ok=True)
script=f'''set throttle off
set save_settings_on_exit false
after time 17 {{keymatrixdown 4 32;after time 0.4 {{keymatrixup 4 32}}}}
after time 20 {{keymatrixdown 8 1;after time 0.4 {{keymatrixup 8 1}}}}
after time 90 {{
 screenshot {{{out/'result.png'}}}
 set f [open {{{out/'core.bin'}}} wb];puts -nonewline $f [debug read_block memory 0xc100 30];close $f
 exit
}}
'''
(out/'test.tcl').write_text(script)
with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=log,stderr=log,timeout=80,check=True)
a=list(struct.unpack('<15H',(out/'core.bin').read_bytes()));print(a,flush=True)
assert a[0]==0x1515 and a[1]==1 and a[3]==2800 and a[2]>0
b=list(struct.unpack('<15H',(r/'build/0917-dos-pass/core.bin').read_bytes()));a[2]=b[2]=0
assert a==b,(a,b)
(out/'result.txt').write_text('PASS: ROM and allocated DOS RAM have identical complete result except elapsed ticks\n'+repr(a))
