"""Native boundary checks and exact centered completion pixels (positioning fixture)."""
from pathlib import Path
import os,re,subprocess,sys
from PIL import Image
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+'
out=r/'build'/('0942-exit-'+machine);out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}'for n,a in sym.items())+'\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set phase 0
set draws 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
proc fail {msg} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {fail $msg}}
proc start {} {
 if {[byte $::world_active]!=1} {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 1 start};return}
 if {[byte $::world_draw_busy]} {after time 0.1 start;return}
 putword $::world_x 688;putword $::world_y 608
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 0.5 entered}
}
proc entered {} {
 if {[byte $::active_level]!=1 || [byte $::world_active] || [byte $::scene_ready]!=165} {after time 0.1 entered;return}
 debug write memory $::enemy_mode 1;set ::phase 1
}
proc fixture {} {
 if {$::phase<1 || $::phase>3} {return}
 check {![byte $::level_done]} "Unexpected completion at wrong edge or height"
 putword $::player_x [expr {$::phase==1?1024*256-1:0}]
 # Hill width from original runtime data. Force just outside right boundary.
 if {$::phase==1} {putword $::player_x [expr {([byte [expr {$::world_collision+1120}]]-2)*256}]}
 putword $::player_y [expr {$::phase==2?5*256:31*256}]
 putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 0
 incr ::draws
 if {$::draws>=5 && $::phase<3} {incr ::phase;set ::draws 0}
}
proc complete {} {after time 0.1 snapshot}
proc snapshot {} {
 if {[byte $::level_done]!=2} {after time 0.1 snapshot;return}
 check {$::phase==3} "Completion occurred without reaching signed left exit"
 set f [open $::env(KEEN_TEST_OUTPUT)/complete.vram wb];puts -nonewline $f [debug read_block VRAM 0 27136];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/ammo.txt w];puts $f [word $::flower_ammo];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: opposite edge blocked, signed edge at wrong height blocked, signed edge at correct height completes";close $f;exit
}
after time 3 start
after time 100 {fail "timeout phase=$::phase"}
'''
s+=f'\ndebug set_bp {sym["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {sym["LevelComplete"]&65535} {{}} complete\n'
(out/'test.tcl').write_text(s);(out/'FAIL.txt').unlink(missing_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with(out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=180,check=True)
assert not(out/'FAIL.txt').exists(),(out/'FAIL.txt').read_text()
font=Path(sys.argv[2]).read_text(encoding='latin1');font=re.sub(r'//[^\n]*','',font)
b=bytes(int(v,16)for v in re.findall(r'0x([0-9A-Fa-f]{2})',font[font.index('{'):]))
expected=bytearray(256*212)
ammo=int((out/'ammo.txt').read_text())
for y,text in [(56,'LEVEL COMPLETE'),(80,'HORSERADISH HILL'),(104,f'FLOWER POWER: {ammo:05d}'),(144,'SPACE / FIRE TO TUBERIA')]:
 x=((256-len(text)*6)//2)&~1
 for c in text:
  for row,v in enumerate(b[4+ord(c)*8:4+(ord(c)+1)*8]):
   for col in range(8):
    if v&(128>>col):expected[(y+row)*256+x+col]=15
  x+=6
actual=bytearray(v for n in (out/'complete.vram').read_bytes()for v in(n>>4,n&15))
assert actual==expected, sum(a!=b for a,b in zip(actual,expected))
Image.frombytes('L',(256,212),bytes(v*17 for v in actual)).convert('RGB').save(out/'complete.png')
(out/'PIXELS-PASS.txt').write_text('PASS: every pixel matches four centered lines\n')
print(machine,(out/'PASS.txt').read_text().strip(),'centered pixels PASS')
