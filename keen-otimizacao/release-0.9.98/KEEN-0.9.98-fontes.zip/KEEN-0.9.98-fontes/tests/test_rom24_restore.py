"""Controlled regression and emulated-time A/B; not hardware gameplay evidence."""
from pathlib import Path
import os, subprocess, sys, re
root=Path(__file__).resolve().parents[1]
case=sys.argv[1] if len(sys.argv)>1 else 'candidate'
assert case in ('baseline','candidate','pixels','baselinepixels')
boot='''
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
'''
frequency=int(sys.argv[2]) if len(sys.argv)>2 else 3579545
route=len(sys.argv)>3 and sys.argv[3]=='route'
out=root/'build'/('0924-'+case+('' if frequency==3579545 else '-'+str(frequency))+('-route' if route else ''));out.mkdir(exist_ok=True)
rom=root/'build/keen_msx.rom';mp=root/'build/keen_msx.map'
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_TEST_OUTPUT=str(out))
if case.endswith('pixels'):
 for name in ('game','world','keydoor','redraw'):
  subprocess.run([sys.executable,str(root/f'tests/make_{name}_test.py'),str(root)],check=True)
 script=(root/'build/redraw-test.tcl').read_text().replace('after time 10 {','after time 40 {',1).replace('after time 50 {','after time 80 {')+boot
 (out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
else:
 if case=='baseline':rom=root/'build/0924-baseline/keen_msx.rom';mp=root/'build/0924-baseline/keen_msx.map'
 subprocess.run([sys.executable,str(root/'tests/make_redraw_bench.py'),str(root),str(mp),str(out/'test.tcl')],check=True)
 script=(out/'test.tcl').read_text().replace('after time 10 {','after time 40 {',1).replace('after time 80 {','after time 110 {')+boot
 (out/'bench.txt').write_text('')
if case=='baselinepixels':
 rom=root/'build/0924-baseline/keen_msx.rom'
 symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/0924-baseline/keen_msx.map').read_text(),re.M)}
 current={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
 for n,a in current.items():
  if n in symbols:
   script=re.sub(r'(?m)^(set \w+ )'+str(a)+r'$',lambda m:m[1]+str(symbols[n]),script)
if case in ('baseline','candidate'):
 symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
 listing=(root/('build/0924-baseline/keen_msx_s7_b1.lst' if case=='baseline' else 'src/out/keen_msx_s7_b1.lst')).read_text()
 rect=int(re.search(r'([0-9A-F]{8})\s+\d+ _Rect:',listing)[1],16)+0x8000
 rows=int(re.search(r'([0-9A-F]{8})\s+\d+ _Rows:',listing)[1],16)+0x8000
 script=script.replace('set ::frames [word $::render_count];set ::started [machine_info time]', 'set ::profiling 1;set ::restore_commands 0;set ::restore_pixels 0;set ::duplicate_pixels 0;set ::bg_seconds 0;set ::bg_calls 0;set ::frames [word $::render_count];set ::started [machine_info time]')
 script=script.replace('proc finish {mode} {','proc finish {mode} {\n set ::profiling 0')
 script=script.replace('seconds=[expr {[machine_info time]-$::started}]"','seconds=[expr {[machine_info time]-$::started}] restore_commands=$::restore_commands restore_pixels=$::restore_pixels duplicate_pixels=$::duplicate_pixels bg_calls=$::bg_calls bg_seconds=$::bg_seconds"')
 script+=f"\nset current_segment {symbols['g_CurrentSegment']}\nset command {symbols['g_VDP_Command']}\n"
 script+=f"\ndebug set_bp {symbols['RingScene']&65535} {{$profiling && [byte $current_segment]==7}} {{set ::coverage [dict create];set ::bg_start [machine_info time]}}\n"
 script+=f"\ndebug set_bp {symbols['ActorsDraw']&65535} {{$profiling && [info exists bg_start] && [byte $current_segment]==14}} {{incr ::bg_calls;set ::bg_seconds [expr {{$::bg_seconds+[machine_info time]-$::bg_start}}];unset ::bg_start}}\n"
 script+=f"\ndebug set_bp {symbols['VDP_CommandSetupR32']} {{$profiling && [byte $current_segment]==7 && [word [reg SP]]>={rect} && [word [reg SP]]<{rows}}} {{profile_restore}}\n"
 script+=r'''
set profiling 0
set coverage [dict create]
proc profile_restore {} {
 incr ::restore_commands
 set x [word [expr {$::command+4}]];set y [word [expr {$::command+6}]]
 set w [word [expr {$::command+8}]];set h [word [expr {$::command+10}]]
 incr ::restore_pixels [expr {$w*$h}]
 for {set yy $y} {$yy<$y+$h} {incr yy} {
  for {set xx $x} {$xx<$x+$w} {incr xx} {
   set key [expr {$yy*256+$xx}]
   if {[dict exists $::coverage $key]} {incr ::duplicate_pixels}
   dict set ::coverage $key 1
  }
 }
}
'''
if case in ('baseline','candidate'):
 script=script.replace('set ::profiling 1;', 'array unset ::routine_calls;array unset ::routine_time;set ::profiling 1;')
 script=script.replace(' close $f\n if {$mode<3}', ' foreach name [array names ::routine_calls] {puts $f "routine=$name calls=$::routine_calls($name) seconds=$::routine_time($name)"}\n close $f\n if {$mode<3}')
 script+=r'''
array set routine_calls {}
array set routine_time {}
array set routine_pending {}
proc routine_enter {name} {
 if {[info exists ::routine_pending($name)]} {return}
 set ::routine_start($name) [machine_info time]
 set sp [expr {([reg SP]+2)&65535}]
 set ::routine_pending($name) [debug set_bp [word [reg SP]] "\[reg SP\]==$sp" [list routine_leave $name]]
}
proc routine_leave {name} {
 debug remove_bp $::routine_pending($name);unset ::routine_pending($name)
 if {!$::profiling} {return}
 if {![info exists ::routine_calls($name)]} {set ::routine_calls($name) 0;set ::routine_time($name) 0}
 incr ::routine_calls($name)
 set ::routine_time($name) [expr {$::routine_time($name)+[machine_info time]-$::routine_start($name)}]
}
'''
 for name in ('ActorsDraw','CombatTick','TomatoTick','ActorsPrepare','ActorDraw','HudDraw','CartDraw','BonusCollect','HeroBitmap','ForegroundHero'):
  address=symbols[name]
  script+=f'\ndebug set_bp {address&65535} {{$profiling && [byte $current_segment]=={address>>16}}} {{routine_enter {name}}}\n'
if route:
 assert case in ('baseline','candidate')
 script=script.replace('after time 0.03 fixture','')
 script=script.replace('proc fixture {} {','proc fixture {} {\n if {[byte $::render_commit]} {after time 0.001 fixture;return}')
 script=script.replace('if {$mode<3} {start_mode [expr {$mode+1}]} else {exit}', 'exit')
 script=script.replace('after time 10 [list finish $mode]', '''keymatrixdown 8 128
 after time 1.5 {keymatrixdown 8 1}
 after time 2.0 {keymatrixup 8 1}
 after time 3.0 {keymatrixup 8 128;keymatrixdown 8 16}
 after time 4.5 {keymatrixup 8 16}
 after time 5.5 {keymatrixdown 8 128}
 after time 7.0 {keymatrixup 8 128}
 after time 10 [list finish $mode]''')
 script=script.replace(' foreach name [array names ::routine_calls]', ' puts $f "final_x=[word $::player_x] final_y=[word $::player_y]"\n foreach name [array names ::routine_calls]')
script=f'set z80_freq {frequency}\nset z80_freq_locked false\n'+script
(out/'test.tcl').write_text(script)
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=100,check=True)
if case.endswith('pixels'):
 assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
 assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
 env['KEEN_STAGE']='2'
 subprocess.run([sys.executable,str(root/'tests/verify_game_pixels.py'),str(out),'overlap','retained','separated','removed','scrolled','returned'],env=env,check=True)
 (out/'VERIFIED.txt').write_text('PASS: independent full-viewport pixel reconstruction, six states, including campaign HUD.\n')
 print((out/'PASS.txt').read_text())
else:
 result=(out/'bench.txt').read_text();assert sum(l.startswith('mode=') for l in result.splitlines())==(1 if route else 4),result
 print(case,result,flush=True)
