#!/usr/bin/env python3
"""Boot and timing regression; C-BIOS plus optional Matsushita hardware."""
import os,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
out=root/'build/auto-cpu';out.mkdir(exist_ok=True)
data=Path(os.environ['OPENMSX_SYSTEM_DATA']);xml=(data/'machines/C-BIOS_MSX2+.xml').read_text()
for name,turbo in [('Keen_Test_Panasonic','true'),('Keen_Test_NoTurbo','false')]:
 device=f'<Matsushita id="Matsushita"><sramname>{name}.sram</sramname><device idref="VDP"/><hasturbo>{turbo}</hasturbo></Matsushita>'
 (data/f'machines/{name}.xml').write_text(xml.replace('</devices>',device+'</devices>'))
cases=[('C-BIOS_MSX2',0,3579545,''),('C-BIOS_MSX2+',0,3579545,''),('Keen_Test_Panasonic',3,5369318,''),('Keen_Test_NoTurbo',0,3579545,''),('C-BIOS_MSX2+',0,7159090,'set z80_freq 7159090\nset z80_freq_locked true')]
for i,(machine,status,freq,setup) in enumerate(cases):
 result=out/f'{i}-{machine}.txt'
 script=out/f'{i}.tcl'
 measured='$z80_freq' if setup else '[machine_info z80_freq]'
 script.write_text(f'''set throttle off
{setup}
proc word {{a}} {{expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}}}
proc check {{ok msg}} {{if {{!$ok}} {{set f [open {{{result}}} w];puts $f "FAIL $msg";close $f;exit}}}}
proc enter_first_level {{}} {{
 if {{[debug read memory {syms['world_active']}]!=1}} {{after time 0.1 enter_first_level;return}}
 keymatrixdown 8 16
 after time 0.6 {{keymatrixup 8 16;keymatrixdown 8 1}}
 after time 0.9 {{keymatrixup 8 1}}
}}
after time 0.1 enter_first_level
after time 10 {{
 check [expr {{[debug read memory {syms['scene_ready']}]==165}}] boot
 check [expr {{[debug read memory {syms['cpu_mode']}]=={status}}}] selection
 check [expr {{{measured}=={freq}}}] frequency
 set ticks0 [word {syms['simulation_ticks']}]
 after time 2 {{
  set dt [expr {{([word {syms['simulation_ticks']}]-$ticks0)&65535}}]
  check [expr {{$dt>=135 && $dt<=145}}] "70Hz physics: $dt"
  set f [open {{{result}}} w];puts $f "PASS {machine}: cpu_mode={status}, Z80={measured} Hz, simulation=$dt ticks/2s";close $f;exit
 }}
}}
''')
 with (out/f'{i}.log').open('w') as log:
  subprocess.run(['openmsx','-machine',machine,'-cart',str(root/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(script)],stdout=log,stderr=log,timeout=30,check=True)
 text=result.read_text();print(text.strip());assert text.startswith('PASS'),text
