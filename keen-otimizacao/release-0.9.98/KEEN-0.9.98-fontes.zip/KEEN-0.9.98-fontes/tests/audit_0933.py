"""Check source-map identity, fixed cache bounds, and baseline resources."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,hashlib,re
r=Path(__file__).resolve().parents[1]
original=json.loads((r/'assets/generated/maps.json').read_text())
rows=[]
for level in (1,2,3,4,5,7,9):
 m=next(x for x in original if x['id']==level)
 bonuses=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-2<=bx-x<=2 and -2<=by-y<=3 for bx,by in bonuses)for x in range(m['width'])for y in range(m['height']))
 assert peak<=8;rows.append((level,len(bonuses),peak))
m=next(x for x in original if x['id']==9);keys=sorted(set(zip(*m['planes'][:2])))
raw=(r/'assets/apple/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<5922H',raw)]==list(zip(*m['planes'][:2]))
spawns=re.findall(r'\{(\d+),(\d+),(\d+)\}',(r/'src/apple_spawns.h').read_text())
assert sorted((int(y)*126+int(x),int(v))for x,y,v in spawns)==sorted((i,v)for i,v in enumerate(m['planes'][2])if v in (47,58,59,48,31))
with ZipFile(r.parent/'deliverables/v0.9.32/keen-dreams-msx-0.9.32-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass','city'):
  for p in (r/'assets'/level).glob('*.bin'):
   if p.name=='ram_tables.bin':continue
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'deliverables/v0.9.32/KEEN0932.ROM').read_bytes()).hexdigest()=='d7d6b6072fdcebdd9cdec4137f45606233b7e2ec8a5354ab2ab1e007a8e8f97b'
print('PASS: all 5922 original background/foreground cells and 12 object positions; baseline 0.9.32 preserved; %d unchanged previous-stage binaries; bonus cache census %s.'%(count,rows))
