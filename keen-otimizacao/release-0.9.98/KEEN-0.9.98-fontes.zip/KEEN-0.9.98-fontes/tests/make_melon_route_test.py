from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/world-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
set route_log [open $::env(KEEN_TEST_OUTPUT)/route.log w]
set phase 0
set cart_min {9999 9999 9999}
set cart_max {0 0 0}
set queue {}
proc keys {input} {
 foreach {flag mask} {1 16 2 128 4 32 8 64 16 1} {
  if {$input & $flag} {keymatrixdown 8 $mask} else {keymatrixup 8 $mask}
 }
}
proc route_add {input condition} {lappend ::queue [list $input $condition]}
proc route_next {} {
 if {![llength $::queue]} {keys 0;route_finish;return}
 set item [lindex $::queue 0];set ::queue [lrange $::queue 1 end]
 set ::condition [lindex $item 1];keys [lindex $item 0]
 set ::step_start [machine_info time];incr ::phase
 puts $::route_log "step=$::phase input=[lindex $item 0] x=[word $::player_x] y=[word $::player_y] wx=[word $::world_x] wy=[word $::world_y]";flush $::route_log
 route_poll
}
proc route_poll {} {
 if {$::phase>12 && ![byte $::world_active]} {
  foreach i {0 1 2} {
   set x [expr {[word [expr {$::carts+$i*6}]]/16}]
   if {$x<[lindex $::cart_min $i]} {lset ::cart_min $i $x}
   if {$x>[lindex $::cart_max $i]} {lset ::cart_max $i $x}
  }
 }
 if {[expr [set ::condition]]} {route_next;return}
 check {[machine_info time]-$::step_start<35} "Route timed out at step $::phase"
 if {$::phase>12} {check {![byte $::death_ticks] && ![word $::respawns]} "No death or respawn during traversal"}
 after time 0.005 route_poll
}
proc route_finish {} {
 check {[byte $::level_done]==2} "Melon exit reached"
 foreach i {0 1 2} lo {528 304 560} hi {912 432 1408} {
  check {[lindex $::cart_min $i]>=$lo && [lindex $::cart_min $i]<=$lo+4 && [lindex $::cart_max $i]<=$hi && [lindex $::cart_max $i]>=$hi-4} "Cart $i reverses at both original track ends"
 }
 puts $::route_log "cart_min=$::cart_min cart_max=$::cart_max"
 keys 16
 after time 0.3 {keys 0}
 after time 4 {
  check {[byte $::world_active] && [byte $::world_completed]==2} "Melon completion persisted in Tuberia"
  world_snap melon_done
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
  puts $f "PASS: keyboard-only traversal from Tuberia spawn through Melon Mines to exit and back; no position/memory writes, deaths or resets."
  close $f;close $::route_log;exit
 }
}
after time 10 {
 check {[byte $world_active]==1} "Start in Tuberia"
 route_add 1 {[word $::world_x]<=720}
 route_add 4 {[word $::world_y]<=592}
 route_add 2 {[word $::world_x]>=752}
 route_add 4 {[word $::world_y]<=588}
 route_add 1 {[word $::world_x]<=736}
 route_add 4 {[word $::world_y]<=560}
 route_add 1 {[word $::world_x]<=664}
 route_add 4 {[word $::world_y]<=540}
 route_add 1 {[word $::world_x]<=624}
 route_add 4 {[word $::world_y]<=448}
 route_add 16 {![byte $::world_active]}
 route_add 0 {[byte $::scene_ready]==165 && [byte $::active_level]==2 && [word $::player_y]<2000}
 route_add 1 {[word $::player_x]<=474*16}
 route_add 17 {[word $::player_x]<=426*16}
 route_add 1 {[word $::player_x]<=378*16}
 route_add 2 {[word $::player_x]>=553*16}
 route_add 18 {[word $::player_x]>=600*16}
 route_add 2 {[word $::player_x]>=636*16}
 route_add 0 {[byte $::grounded] && [word $::player_y]>400*16}
 route_add 1 {[word $::player_x]<=540*16}
 route_add 17 {[word $::player_x]<=492*16}
 route_add 1 {[word $::player_x]<=444*16}
 route_add 2 {[word $::player_x]>=1375*16}
 route_add 5 {[byte $::climbing]}
 route_add 4 {[word $::player_y]<=471*16}
 route_add 18 {![byte $::climbing]}
 route_add 2 {[byte $::level_done]==2}
 route_next
}
after time 250 {check {0} "Overall timeout"}
'''
(r/'build/melon-route-test.tcl').write_text(s)
