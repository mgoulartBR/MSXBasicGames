"""Real ROM carrot draws: all poses, odd/even X, viewport clips and VRAM wrap.
Uses the existing independent full-frame reconstruction, not the new crop data.
"""
from pathlib import Path
import os,re,subprocess,sys,json
r=Path(__file__).resolve().parents[1]
case=sys.argv[1] if len(sys.argv)>1 else 'candidate'
assert case in ('baseline','candidate')
tight=len(sys.argv)>2 and sys.argv[2]=='tight'
frames=([x['frame'] for x in json.loads((r/'build/tight-sprites.json').read_text()) if x['level']=='melon'] if tight else list(range(16,26)))
total=len(frames)*6
out=r/'build'/f'0925-poses-{case}{"-tight" if tight else ""}';out.mkdir(exist_ok=True)
mp=r/('build/0925-baseline/keen_msx.map' if case=='baseline' else 'build/keen_msx.map')
rom=mp.with_suffix('.rom')
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='2',KEEN_TEST_OUTPUT=str(out))
for name in ('game','world','keydoor'):
 subprocess.run([sys.executable,str(r/f'tests/make_{name}_test.py'),str(r)],check=True)
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
current={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
if case=='baseline':
 for n,a in current.items():
  if n in syms:s=re.sub(r'(?m)^(set \w+ )'+str(a)+r'$',lambda m:m[1]+str(syms[n]),s)
s=s.replace('set throttle on','set throttle off')
s+='\nset pose_frames {'+' '.join(map(str,frames))+'}\n'
s+=f"\nset actor_draw {syms['ActorDraw']&65535}\nset current_segment {syms['g_CurrentSegment']}\nset vdp_setup {syms['VDP_CommandSetupR32']}\nset command {syms['g_VDP_Command']}\n"
s+=r'''
set profiling 0
set draw_calls 0
set draw_seconds 0
set draw_commands 0
set draw_pixels 0
proc draw_enter {} {
 set frame [byte [expr {[word [expr {[reg SP]+6}]]+4}]]
 if {$frame<16 || $frame>=26} {return}
 set ::draw_start [machine_info time]
 set sp [expr {([reg SP]+2)&65535}]
 set ::draw_pending [debug set_bp [word [reg SP]] "\[reg SP\]==$sp" {draw_leave}]
}
proc draw_leave {} {
 debug remove_bp $::draw_pending;unset ::draw_pending
 incr ::draw_calls
 set ::draw_seconds [expr {$::draw_seconds+[machine_info time]-$::draw_start}]
}
debug set_bp $actor_draw {$profiling && [byte $current_segment]==14} {draw_enter}
debug set_bp $vdp_setup {[info exists draw_pending]} {
 incr ::draw_commands
 incr ::draw_pixels [expr {[word [expr {$::command+8}]]*[word [expr {$::command+10}]]}]
}
'''
s+=r'''
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
proc hold {} {place 1240 192;after time 0.03 hold}
proc pose {index} {
 if {[byte $::render_commit]} {after time 0.001 [list pose $index];return}
 if {$index==6*[llength $::pose_frames]} {
  set ::profiling 0
  set f [open $::env(KEEN_TEST_OUTPUT)/metrics.txt w]
  puts $f "calls=$::draw_calls seconds=$::draw_seconds commands=$::draw_commands pixels=$::draw_pixels";close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: original-asset pose/clip/wrap captures";close $f;exit
 }
 set frame [lindex $::pose_frames [expr {$index%[llength $::pose_frames]}]]
 set group [expr {$index/[llength $::pose_frames]}]
 set cx [word $::drawn_camera_px];set cy [word $::drawn_camera_py]
 switch $group {
  0 {set x 1279;set y 246}
  1 {set x 1280;set y 247}
  2 {set x [expr {$cx-15}];set y [expr {$cy+65}]}
  3 {set x [expr {$cx+245}];set y [expr {$cy+65}]}
  4 {set x [expr {$cx+160}];set y [expr {$cy-15}]}
  5 {set x [expr {$cx+160}];set y [expr {$cy+181}]}
 }
 putword $::enemy [expr {$x*16}];putword [expr {$::enemy+2}] [expr {$y*16}]
 debug write memory [expr {$::enemy+10}] 1
 debug write memory [expr {$::enemy+11}] $frame
 debug write memory $::combat_dirty 1
 after time 0.6 [list capture_pose $index]
}
proc capture_pose {index} {
 if {[byte $::render_commit]} {after time 0.001 [list capture_pose $index];return}
 set a [expr {$::actors_old+[byte $::front_page]*174+6}]
 if {[byte [expr {$a+4}]]!=[lindex $::pose_frames [expr {$index%[llength $::pose_frames]}]] || [word $a]!=[word $::enemy]/16 || [word [expr {$a+2}]]!=[word [expr {$::enemy+2}]]/16} {after time 0.05 [list capture_pose $index];return}
 snap [format "pose%02d" $index]
 pose [expr {$index+1}]
}
after time 40 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2} "Melon loaded"
  debug write memory $::enemy_mode 1
  hold
  after time 2 {set ::profiling 1;pose 0}
 }
}
after time 220 {check {0} "Timeout"}
'''
if tight:s=s.replace('$cx-15','$cx-5').replace('$cy-15','$cy-3')
(out/'test.tcl').write_text(s);(out/'FAIL.txt').write_text('');(out/'PASS.txt').write_text('PENDING')
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=120,check=True)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
assert (out/'PASS.txt').read_text().startswith('PASS')
names=[f'pose{i:02}' for i in range(total)]
# Verify that the intended ROM frames were actually displayed, not merely requested.
for i,name in enumerate(names):
 actor=list(map(int,(out/f'{name}.txt').read_text().splitlines()[2].split()))
 assert actor[2]==frames[i%len(frames)] and actor[3],(name,actor)
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
(out/'VERIFIED.txt').write_text('PASS: all captured complete viewports match independent original-asset reconstruction.\n')
