"""Same controlled three-enemy scene for baseline/candidate; emulated time."""
from pathlib import Path
import re,sys
r=Path(sys.argv[1]);mp=Path(sys.argv[2]);out=Path(sys.argv[3])
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
names=['world_x','world_y','player_x','player_y','player_vx','player_vy','grounded','climbing','cart_riding','combat_dirty','enemy_mode','hud_debug','render_count','world_collision','render_commit','active_level']
s='\n'.join(f'set {n} {syms[n]}' for n in names)+r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc fixture {} {
 if {![byte $::render_commit]} {
  putword $::player_x 19840;putword $::player_y 3072
  putword $::player_vx 0;putword $::player_vy 0
  debug write memory $::grounded 0;debug write memory $::climbing 0
  debug write memory $::cart_riding 255;debug write memory $::combat_dirty 1
 }
 after time 0.03 fixture
}
proc start_mode {mode} {
 debug write memory $::enemy_mode $mode
 foreach {i x y} {0 1180 244 1 1270 244 2 1340 244} {
  set t [expr {$::world_collision+1026+$i*13}]
  putword $t [expr {$x*16}];putword [expr {$t+2}] [expr {$y*16}]
 }
 after time 2 [list measure $mode]
}
proc measure {mode} {
 set ::frames [word $::render_count];set ::started [machine_info time]
 after time 10 [list finish $mode]
}
proc finish {mode} {
 set f [open $::env(KEEN_TEST_OUTPUT)/bench.txt a]
 puts $f "mode=[expr {$mode+1}] frames=[expr {[word $::render_count]-$::frames}] seconds=[expr {[machine_info time]-$::started}]"
 close $f
 if {$mode<3} {start_mode [expr {$mode+1}]} else {exit}
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  if {[byte $::active_level]!=2} {error "Melon not loaded"}
  fixture;start_mode 0
 }
}
after time 80 {exit}
'''
out.write_text(s)
