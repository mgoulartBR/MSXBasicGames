# Test double for the documented OCM-PLD I/O protocol, not an FPGA core.
# Only documented clock fields change. Unrelated settings are sentinels.
namespace eval keen_ocm {
 variable selected 8
 variable commands {}
 variable acknowledge 1
 variable apply_clock 1
 variable ports
 array set ports {65 255 66 214 67 165 71 188 72 163 79 12}
 proc read_port {} {
  variable selected; variable ports
  set p [expr {$::wp_last_address & 255}]
  if {$p==64} {
   if {$selected==212} {after time 0 {reg A 43}}
   if {$selected==8} {after time 0 {reg A 247}}
  } elseif {$selected==212 && [info exists ports($p)]} {
   after time 0 [list reg A $ports($p)]
  }
 }
 proc write_port {} {
  variable selected;variable ports;variable commands
  variable acknowledge;variable apply_clock
  set p [expr {$::wp_last_address & 255}]
  if {$p==64} {set selected $::wp_last_value;return}
  if {$p!=65} {error "Unexpected config write at $p"}
  lappend commands [list $selected $::wp_last_value]
  if {$selected==212 && $::wp_last_value==10} {
   if {$acknowledge} {set ports(65) 245}
   if {$apply_clock} {
    set ports(66) [expr {$ports(66)|1}]
    set ports(71) [expr {($ports(71)&248)|7}]
    set ports(72) [expr {$ports(72)&254}]
    set ::z80_freq 8060000
    set ::z80_freq_locked true
   }
  }
 }
 debug set_watchpoint read_io {0x40 0x4f} {} {keen_ocm::read_port}
 debug set_watchpoint write_io {0x40 0x4f} {} {keen_ocm::write_port}
}
