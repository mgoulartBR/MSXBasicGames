"""Same 8-second walk/jump input on any ROM/map, including 0.3.1."""
from pathlib import Path
import re,sys
m=Path(sys.argv[1]);out=Path(sys.argv[2])
d={n:int(a,16)for a,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',m.read_text())}
header='\n'.join(f'set {n} {d[n]}' for n in ['render_count','drawn_cy','drawn_camera_px','full_redraws','scroll_copies'])
header+='\nset fine_y '+str(d.get('drawn_camera_py',0))
body=r'''
set renderer SDL
set sound_driver null
set throttle off
set save_settings_on_exit false
proc word {a} {return [expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}]}
proc camy {} {if {$::fine_y} {return [word $::fine_y]};return [expr {16*[debug read memory $::drawn_cy]}]}
proc jump {} {keymatrixdown 8 1;after time 0.6 {keymatrixup 8 1};after time 1.6 jump}
proc sample {} {
 global f last prev oldy records
 incr f
 set n [word $::render_count]
 if {$n!=$last} {
  set y [camy]
  lappend records "[expr {$f-$prev}],$y,[expr {$y-$oldy}],[word $::drawn_camera_px]"
  set oldy $y;set prev $f;set last $n
 }
 if {$f<480} {after frame sample} else {
  set o [open $::env(KEEN_BENCH_OUT) w]
  puts $o "interval,camera_y,delta_y,camera_x"
  puts $o [join $records \n]
  puts $o "full_redraws=[word $::full_redraws] scroll_copies=[word $::scroll_copies]"
  close $o;exit
 }
}
after time 10 {set f 0;set prev 0;set last [word $render_count];set oldy [camy];set records {};keymatrixdown 8 16;jump;after frame sample}
'''
out.write_text(header+'\n'+body)
