"""External presentation count in the two foreground-heavy regression fixtures."""
from pathlib import Path
import subprocess,sys
r=Path(sys.argv[1]);tag=sys.argv[2];mp=sys.argv[3];scene=sys.argv[4]
subprocess.run([sys.executable,str(r/'tests/make_hero_bench.py'),str(r),tag,mp],check=True)
s=(r/f'build/hero-bench-{tag}.tcl').read_text()
if scene=='pole':
 s=s.replace('putword $::raw_player_x 32000;putword $::raw_player_y 6400','putword $::raw_player_x 26688;putword $::raw_player_y 6912').replace('place 2000 400','place 1668 432').replace('int([machine_info time]*8)%8 : 0','43+int([machine_info time]*8)%3 : 43')
else:
 s=s.replace('putword $::raw_player_x 32000;putword $::raw_player_y 6400','putword $::raw_player_x 19712;putword $::raw_player_y 2560').replace('place 2000 400','place 1232 160').replace('after time 10 {\n check','after time 15 {\n check').replace('==1} {First stage loaded}','==2} {Melon loaded}').replace('after time 60 {exit}','after time 70 {exit}')
 s+='\nafter time 10 {putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}\n'
(r/f'build/platform-{scene}-{tag}.tcl').write_text(s)
