from pathlib import Path
import re,sys,subprocess
r=Path(sys.argv[1]).resolve()
for t in ['game','world','keydoor']:subprocess.run([sys.executable,str(r/f'tests/make_{t}_test.py'),str(r)],check=True)
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+='\nset enabled 0\nset case 0\nset pending -1\nset hero_ids {0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 30 31 36 37 38 39 40 41 42 43 44 45}\n'
s+=r'''
proc fixture {} {
 if {!$::enabled} {return}
 putword $::raw_player_x 32000
 putword $::raw_player_y [expr {(400+$::case%2)*16}]
 debug write memory $::hero_frame [lindex $::hero_ids [expr {$::case/2}]]
 debug write memory $::hero_visible 1
}
proc hold {} {
 if {!$::enabled} {return}
 place 2000 400
 debug write memory $::enemy_mode 2
 debug write memory $::combat_dirty 1
 after time 0.03 hold
}
proc capture {n} {
 if {[byte $::render_commit]} {after time 0.001 [list capture $n];return}
 check {[byte [expr {$::world_collision+1131+[byte $::front_page]}]]==1} {Hero hardware enabled}
 snap hero$n
 foreach {suffix device start size} [list allvram VRAM 0 131072 regs {VDP regs} 0 64 state memory [expr {$::world_collision+1128}] 12] {
  set f [open $::env(KEEN_TEST_OUTPUT)/hero$n.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f
 }
 if {$n<55} {incr ::case;after time 0.9 [list set ::pending [expr {$n+1}]]} else {exit}
}
after time 10 {
 check {[byte $::active_level]==1} {First stage loaded}
 set ::enabled 1;hold;after time 1 {set ::pending 0}
}
after time 70 {exit}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} fixture\n'
s+=f'\ndebug set_bp {syms["HWFlip"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21 && $::pending>=0}} '+r'{set n $::pending;set ::pending -1;after time 0.001 [list capture $n]}'+'\n'
(r/'build/hero-test.tcl').write_text(s)
