"""Actual Z80 ROM checks; controlled poses are separate from native movement/cadence."""
from pathlib import Path
import os,re,subprocess,sys
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0930-rapids-rom' if machine=='C-BIOS_MSX2+' else '0930-rapids-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='4',KEEN_TEST_OUTPUT=str(out))
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}' for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set names {}
set phase 0
set walk_samples {}
set cadence_calls 0
set previous_tick -1
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc actor {i} {expr {$i==10?$::world_collision+1026:$::world_map+9000+16*$i}}
proc hold {x y} {set ::held 1;set ::hx [expr {$x*16}];set ::hy [expr {$y*16}]}
proc fixture {} {if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc entry {} {
 if {[byte $::world_active]!=1} {after time 0.2 entry;return}
 putword $::world_x 256;putword $::world_y 880;keys 1;set ::phase 1
 after time 0.3 {keys 0;after time 3 begin}
}
proc begin {} {
 if {[byte $::scene_ready]!=165 || [byte $::active_level]!=4 || [byte $::world_active]} {after time 0.2 begin;return}
 check {[byte [expr {$::world_collision+1120}]]==74 && [byte [expr {$::world_collision+1121}]]==46} "Original map dimensions"
 set ::startx [word $::player_x];keys 16
 after time 0.6 {keys 0;after time 0.3 natural}
}
proc natural {} {
 check {[word $::player_x]<$::startx && ![byte $::death_ticks]} "Native leftward movement from original spawn survives"
 hold 672 64;set ::phase 2;set ::sample_count 0;after time 0.8 sample_walk
}
proc sample_walk {} {
 lappend ::walk_samples [word [actor 0]];incr ::sample_count
 if {$::sample_count<15} {after time 0.15 sample_walk;return}
 check {[llength [lsort -unique $::walk_samples]]>3 && [byte [expr {[actor 0]+10}]]} "Native Tater walking on real terrain"
 set a [actor 0];putword $::shots [expr {[word $a]+128}];putword [expr {$::shots+2}] [expr {[word [expr {$a+2}]]+128}]
 putword [expr {$::shots+4}] 0;putword [expr {$::shots+6}] 0;putword [expr {$::shots+8}] 140;debug write memory [expr {$::shots+10}] 1;debug write memory [expr {$::shots+13}] 0
 after time 0.02 flower
}
proc cadence {} {
 set a [actor 0];set tick [word $::simulation_ticks];set timer [word [expr {$a+8}]]
 if {$::phase==3 && [byte [expr {$a+13}]]==1} {
  if {$::previous_tick>=0} {check {[expr {($tick-$::previous_tick)&65535}]==1 && $timer==$::previous_timer-1} "One enemy update per native simulation tick";incr ::cadence_calls}
  set ::previous_tick $tick;set ::previous_timer $timer
 }
}
proc flower {} {
 if {[byte [expr {[actor 0]+13}]]!=1} {after time 0.01 flower;return}
 check {[word $::flower_hits]>0 && ![byte [expr {$::shots+10}]]} "Native shot transforms Tater"
 set ::phase 3;after time 0.1 recovery
}
proc recovery {} {
 if {[byte [expr {[actor 0]+13}]]==1} {after time 0.1 recovery;return}
 check {$::cadence_calls>300 && [word $::flower_returns]>0} "350-tick flower and recovery"
 set ::phase 4;debug write memory $::enemy_mode 1;hold 284 413;after time 0.8 key_one
}
proc key_one {} {check {[byte $::key_owned]==1 && [byte [expr {$::world_map+9200}]]==1} "First key";hold 636 573;after time 0.8 key_two}
proc key_two {} {check {[byte $::key_owned]==2} "Second key";hold 552 464;after time 1 door_one}
proc door_one {} {check {[byte $::key_owned]==1 && [byte [expr {$::world_map+9203}]]==2} "First door consumes one key and rises";hold 152 624;after time 1 door_two}
proc door_two {} {check {![byte $::key_owned] && [byte [expr {$::world_map+9204}]]==2} "Second door";hold 636 525;after time 0.7 bomb_one}
proc bomb_one {} {hold 636 557;after time 0.7 bombs}
proc bombs {} {
 check {[word $::boobus_bombs]==3 && [byte [expr {$::world_map+9207}]]==7} "All three original bombs, once each"
 set ::held 0;set ::oldlife [byte $::game_lives];keymatrixdown 4 128;after time 0.3 {keymatrixup 4 128};after time 1 restarted
}
proc restarted {} {
 if {[byte $::game_lives]==$::oldlife || [byte $::restart_pending] || [byte $::death_ticks] || [word $::player_x]!=1088*16 || [byte [expr {$::world_map+9207}]] || [byte [expr {$::world_map+9203}]] || [byte [expr {$::world_map+9204}]]} {after time 0.1 restarted;return}
 check {[byte $::game_lives]==$::oldlife-1 && ![word $::boobus_bombs] && ![byte $::key_owned]} "Death resets keys/doors and rolls back stage bombs"
 debug write memory $::enemy_mode 1;set ::index 0;set ::pose 0;set ::phase 5;next_pose
}
proc next_pose {} {
 if {$::index==11} {set ::object_index 0;next_object;return}
 set a [actor $::index];set x [expr {[word $a]/16}];set y [expr {[word [expr {$a+2}]]/16}];hold [expr {$x>112?$x-80:32}] [expr {$y>32?$y:32}]
 if {$::index<7} {set frame [expr {$::pose==12?26:124+$::pose}]} elseif {$::index==7} {set frame [expr {$::pose==8?26:108+$::pose}]} elseif {$::index<10} {set frame [expr {$::pose==8?26:116+$::pose}]} else {set frame [expr {$::pose==4?26:90+$::pose}]}
 set ::frame $frame;set fo [expr {$::index==10?9:11}];set so [expr {$::index==10?11:13}]
 debug write memory [expr {$a+$fo}] $frame;debug write memory [expr {$a+$so}] [expr {$frame==26?1:0}];after time 0.7 pose_ready
}
proc pose_ready {} {
 if {[byte $::render_commit]} {after time 0.001 pose_ready;return}
 set a [actor $::index];check {[byte [expr {$a+($::index==10?8:10)}]]} "Original actor wakes"
 set ex [expr {[word $a]/16-($::index==10 || $::frame==26?0:24)}];set ey [expr {[word [expr {$a+2}]]/16-($::index==10 || $::frame==26?0:4)}];set found 0
 for {set i 15} {$i<29} {incr i} {set d [expr {$::actors_old+[byte $::front_page]*174+6*$i}];if {[byte [expr {$d+5}]] && [byte [expr {$d+4}]]==$::frame && [word $d]==$ex && [word [expr {$d+2}]]==$ey} {set found 1}}
 if {!$found} {after time 0.01 pose_ready;return}
 set name "enemy-$::index-pose-$::pose";snap $name;lappend ::names $name;incr ::pose
 set limit [expr {$::index<7?13:$::index<10?9:5}];if {$::pose==$limit} {incr ::index;set ::pose 0};next_pose
}
proc next_object {} {
 set coords {{284 413} {636 573} {480 464} {80 624} {560 528} {560 560}}
 if {$::object_index==6} {set ::clip_index 0;hold 480 192;after time 0.8 next_clip;return}
 lassign [lindex $coords $::object_index] x y;hold $x $y;after time 0.8 object_ready
}
proc object_ready {} {if {[byte $::render_commit]} {after time 0.001 object_ready;return};set name "object-$::object_index";snap $name;lappend ::names $name;incr ::object_index;next_object}
proc next_clip {} {
 if {$::clip_index==4} {set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f;set ::held 0;putword $::player_x 432;putword $::player_y [expr {40*256}];debug write memory $::climbing 0;keys 16;after time 0.5 {keys 0;after time 0.2 finishing};return}
 lassign [lindex {{-16 48} {244 48} {64 -16} {64 170}} $::clip_index] x y;set a [actor 8];putword $a [expr {([word $::camera_px]+$x)*16}];putword [expr {$a+2}] [expr {([word $::camera_py]+$y)*16}];debug write memory [expr {$a+11}] 119;debug write memory [expr {$a+13}] 3;after time 0.6 clip_ready
}
proc clip_ready {} {if {[byte $::render_commit]} {after time 0.001 clip_ready;return};set name "clip-$::clip_index";snap $name;lappend ::names $name;incr ::clip_index;next_clip}
proc finishing {} {
 if {![byte $::level_done] && ![byte $::world_active]} {after time 0.2 finishing;return}
 keys 1;after time 0.2 {keys 0};after time 1 {keys 1;after time 0.2 {keys 0}};after time 2 world_done
}
proc world_snap {name} {
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.vram wb];puts -nonewline $f [debug read_block VRAM [expr {[byte $::wpage]*32768}] 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.map wb];puts -nonewline $f [debug read_block memory $::world_map 6312];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w];puts $f "[word $::world_x] [word $::world_y] [byte $::wframe] [word $::wcx] [word $::wcy] [byte $::world_completed] [byte $::hardware_scroll] [byte $::world_notice]";close $f
}
proc world_done {} {
 if {![byte $::world_active] || !([byte $::world_completed]&8) || [byte $::world_draw_busy]} {after time 0.1 world_done;return}
 world_snap world-complete;keys 160;after time 0.3 {keys 0;after time 0.6 northeast}
}
proc northeast {} {
 if {[byte $::world_draw_busy]} {after time 0.01 northeast;return}
 check {[byte $::wframe]==23} "Northeast world pose uses extra patterns";world_snap world-northeast
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: fourth-stage Tuberia entry, native movement/Tater walking, 350-tick flower recovery ($::cadence_calls calls), two keys and doors, three bombs and death rollback; [llength $::names] controlled complete-frame render captures; real exit and Tuberia completion, northeast world graphics.";close $f;exit
}
after time 40 entry
after time 260 {check {0} "Timeout phase=$::phase index=[expr {[info exists ::index]?$::index:-1}] pose=[expr {[info exists ::pose]?$::pose:-1}] world=[byte $::world_active] level=[byte $::level_done]"}
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n' for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {syms["RapidTick"]&65535} {{[byte $::g_CurrentSegment]==53}} cadence\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with (out/'emulator.log').open('w') as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=230)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text();assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
names=(out/'names.txt').read_text().splitlines();subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
subprocess.run([sys.executable,str(r/'tests/verify_world_pixels.py'),str(out),'world-complete','world-northeast'],env=env,check=True)
(out/'VERIFIED.txt').write_text(f'PASS: independent pixel reconstruction for all {len(names)} fourth-stage complete frames and two world views.\n');print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
