from pathlib import Path
import sys,re,subprocess
r=Path(sys.argv[1]).resolve()
for t in ['game','world','keydoor']:subprocess.run([sys.executable,str(r/f'tests/make_{t}_test.py'),str(r)],check=True)
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+='\nset throttle off\nset enabled 0\nset case 0\n'
s+=r'''
proc fixture {} {
 if {!$::enabled} {return}
 set y [expr {64+($::case%2)}]
 set x [expr {$::case<28 ? 32 : [lindex {-31 -16 -1 240 255 256 -32 32} [expr {$::case-28}]]}]
 putword $::enemy [expr {([word $::camera_px]+$x)*16}]
 putword [expr {$::enemy+2}] [expr {([word $::camera_py]+$y)*16}]
 debug write memory [expr {$::enemy+10}] 1
 debug write memory [expr {$::enemy+11}] [expr {16+($::case<28 ? $::case/2 : 0)}]
}
proc hold {} {
 if {!$::enabled} {return}
 place 2000 448
 debug write memory $::enemy_mode 1
 debug write memory $::combat_dirty 1
 after time 0.03 hold
}
proc capture {n} {
 if {[byte $::render_commit]} {after time 0.001 [list capture $n];return}
 snap carrot$n
 foreach {suffix device start size} [list allvram VRAM 0 131072 regs {VDP regs} 0 64 state memory [expr {$::world_collision+1128}] 12] {
  set f [open $::env(KEEN_TEST_OUTPUT)/carrot$n.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f
 }
 if {$n<35} {incr ::case;after time 0.9 [list capture [expr {$n+1}]]} else {exit}
}
after time 10 {
 check {[byte $::active_level]==1} {First stage loaded}
 set ::enabled 1;hold;after time 1 {capture 0}
}
after time 60 {exit}
'''
s+=f'\ndebug set_bp {syms["HWPrepare"]&65535} {{[byte {syms["g_CurrentSegment"]}]==21}} fixture\n'
(r/'build/carrot-test.tcl').write_text(s)
