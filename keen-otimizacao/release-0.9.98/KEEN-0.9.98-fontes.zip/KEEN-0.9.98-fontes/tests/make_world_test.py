from pathlib import Path
import sys,re
r=Path(sys.argv[1]);s=(r/'build/game-test.tcl').read_text().split('after time 10 {')[0].replace('set throttle on','set throttle off')
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
for n in ['player_x','player_y','player_vx','player_vy']:s+=f'\nset raw_{n} {syms[n]}\n'
s+=r'''
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc world_snap {name} {
 if {[byte $::world_draw_busy]} {after time 0.001 [list world_snap $name];return}
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.vram wb];puts -nonewline $f [debug read_block VRAM [expr {[byte $::wpage]*32768}] 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.map wb];puts -nonewline $f [debug read_block memory $::world_map 6312];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w]
 puts $f "[word $::world_x] [word $::world_y] [byte $::wframe] [word $::wcx] [word $::wcy] [byte $::world_completed] [byte $::hardware_scroll] [byte $::world_notice]";close $f
}
after time 10 {
 check {[byte $world_active]==1 && ![byte $world_completed]} "Boot into Tuberia"
 check {[word $world_x]==768 && [word $world_y]==624} "Original world spawn"
 world_snap world_spawn
 keymatrixdown 8 16
 after time 0.6 {keymatrixup 8 16}
 after time 1 {
  check {[word $world_x]<768} "Walk in world"
  set return_x [word $world_x];set return_y [word $world_y]
  world_snap entrance;keymatrixdown 8 1
 }
 after time 1.3 {keymatrixup 8 1}
 after time 4 {
  check {![byte $world_active] && [byte $scene_ready]==165} "Enter Horseradish Hill"
  check {[word $player_x]>32000} "Level spawn restored"
  snap level_spawn
  putword $flower_ammo 6;debug write memory $combat_dirty 1
  # Exit via the normal right-edge condition.
  putword $raw_player_x [expr {134*256-320}];putword $raw_player_y [expr {480*16}]
  putword $raw_player_vx 0;putword $raw_player_vy 0
  keymatrixdown 8 128
 }
 after time 5.5 {
  keymatrixup 8 128;check {[byte $level_done]==2} "Level completion"
  keymatrixdown 8 1
 }
 after time 5.8 {keymatrixup 8 1}
 after time 8 {
  check {[byte $world_active]==1 && [byte $world_completed]} "Return to completed world"
  check {[word $world_x]==$return_x && [word $world_y]==$return_y} "Return to entrance position"
  check {[word $flower_ammo]==6} "Keep remaining Flower Power on return"
  world_snap completed
  keymatrixdown 8 1
 }
 after time 8.3 {keymatrixup 8 1}
 after time 9 {check {[byte $world_active]==1} "Completed stage cannot be entered again";keymatrixdown 4 8}
 after time 9.3 {keymatrixup 4 8}
 after time 10 {
  check {![byte $world_completed] && [word $flower_ammo]==0} "N starts new game"
  check {[word $world_x]==768 && [word $world_y]==624} "New-game spawn"
  world_snap new_game
  keymatrixdown 8 16
 }
 after time 10.6 {keymatrixup 8 16;keymatrixdown 8 1}
 after time 10.9 {keymatrixup 8 1}
 after time 13 {
  check {![byte $world_active] && ![byte $level_done]} "Re-enter after new game"
  snap second_entry
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS original world spawn, walking, entry, completion, return position, retained ammo, completion lock, new game and second entry.";close $f;exit
 }
}
'''
(r/'build/world-test.tcl').write_text(s)
