#!/usr/bin/env python3
"""Test BIOS dispatch/ABI with explicit stubs; does NOT emulate R800 execution."""
import os,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
out=root/'build/auto-cpu';out.mkdir(exist_ok=True)
data=Path(os.environ['OPENMSX_SYSTEM_DATA'])
bios=bytearray((data/'systemroms/cbios_main_msx2+.rom').read_bytes())
bios[0x2d]=3;bios[0x180]=0xc9;bios[0x183:0x186]=bytes([0x3e,2,0xc9])
rom=out/'cbios_dispatch_stubs.rom';rom.write_bytes(bios)
xml=(data/'machines/C-BIOS_MSX2+.xml').read_text()
xml=re.sub(r'<sha1>.*?</sha1>', '', xml, count=1)
xml=xml.replace('cbios_main_msx2+.rom',str(rom))
(data/'machines/Keen_Test_BIOS_Dispatch.xml').write_text(xml)
script=out/'r800-dispatch.tcl';result=out/'r800-dispatch.txt'
script.write_text(f'''set throttle off
set keen_chg_calls 0
set keen_get_calls 0
set keen_chg_arg -1
debug set_bp 0x180 {{}} {{incr keen_chg_calls;set keen_chg_arg [reg A]}}
debug set_bp 0x183 {{}} {{incr keen_get_calls}}
proc enter_first_level {{}} {{
 if {{[debug read memory {syms['world_active']}]!=1}} {{after time 0.1 enter_first_level;return}}
 keymatrixdown 8 16
 after time 0.6 {{keymatrixup 8 16;keymatrixdown 8 1}}
 after time 0.9 {{keymatrixup 8 1}}
}}
after time 0.1 enter_first_level
after time 12 {{
 set f [open {{{result}}} w]
 if {{$keen_chg_calls==1 && $keen_get_calls==1 && $keen_chg_arg==130 && [debug read memory {syms['cpu_mode']}]==2 && [debug read memory {syms['scene_ready']}]==165}} {{
  puts $f "PASS: CHGCPU A=0x82 once, GETCPU once, boot completed. BIOS STUBS ONLY; actual R800/DRAM BIOS not tested."
 }} else {{puts $f "FAIL calls=$keen_chg_calls/$keen_get_calls arg=$keen_chg_arg status=[debug read memory {syms['cpu_mode']} ]"}}
 close $f;exit
}}
''')
with (out/'r800-dispatch.log').open('w') as log:
 subprocess.run(['openmsx','-machine','Keen_Test_BIOS_Dispatch','-cart',str(root/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(script)],stdout=log,stderr=log,timeout=30,check=True)
text=result.read_text();print(text.strip());assert text.startswith('PASS'),text
