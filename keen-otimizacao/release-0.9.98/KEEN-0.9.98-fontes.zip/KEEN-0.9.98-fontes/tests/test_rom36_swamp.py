"""Actual Z80 ROM checks; controlled poses are separate from native movement/cadence."""
from pathlib import Path
import os,re,subprocess,sys,hashlib
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0936-swamp-rom' if machine=='C-BIOS_MSX2+' else '0936-swamp-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='10',KEEN_TEST_OUTPUT=str(out))
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}' for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set names {}
set phase 0
set walk_samples {}
set cadence_calls 0
set previous_tick -1
set deferred {}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc actor {i} {expr {$::world_map+7200+16*$i}}
proc hold {x y} {set ::held 1;set ::hx [expr {$x*16}];set ::hy [expr {$y*16}]}
proc fixture {} {if {$::phase==2 || $::phase==3} {for {set j 1} {$j<6} {incr j} {debug write memory [expr {[actor $j]+10}] 0}};if {$::phase==8} {for {set j 0} {$j<6} {incr j} {if {$j!=3} {debug write memory [expr {[actor $j]+10}] 0}};set a [actor 3];set ::hx [expr {[word $a]+900}];set ::hy [word [expr {$a+2}]]};if {$::deferred ne {}} {set cmd $::deferred;set ::deferred {};uplevel #0 $cmd};if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc entry {} {
 if {[byte $::world_active]!=1} {after time 0.2 entry;return}
 putword $::world_x 1216;putword $::world_y 512;keys 1;set ::phase 1
 after time 0.3 {keys 0;after time 0.1 begin}
}
proc begin {} {
 if {[byte $::scene_ready]!=165 || [byte $::active_level]!=10 || [byte $::world_active]} {after time 0.2 begin;return}
 check {[byte [expr {$::world_collision+1120}]] ==74 && [byte [expr {$::world_collision+1121}]] ==29} "Original map dimensions"
 set ::phase 11
}
proc movement {} {
 if {$::phase!=11 || ![byte $::grounded]} {return}
 set ::phase 12;set ::startx [word $::player_x];keys 16
 after time 0.3 {keys 0;after time 0.1 natural}
}

proc natural {} {
 check {[word $::player_x]<$::startx && ![byte $::death_ticks] && ![byte $::level_done] && ![byte $::world_active]} "Native leftward movement from original spawn survives: start=$::startx x=[word $::player_x] y=[word $::player_y] death=[byte $::death_ticks] life=[byte $::game_lives]"
 set ::baseline_bombs [word $::boobus_bombs];set ::bomb_index 0;bomb_collect
}
proc bomb_collect {} {
 if {$::bomb_index==3} {check {[byte [expr {$::world_map+7297}]]==7 && [word $::boobus_bombs]==$::baseline_bombs+3} "All three original bombs collected: flags=[byte [expr {$::world_map+7297}]] count=[word $::boobus_bombs] baseline=$::baseline_bombs";hold 896 90;set ::phase 2;set ::sample_count 0;after time 0.8 sample_walk;return}
 hold [expr {1052+16*$::bomb_index}] 45;after time 0.2 bomb_ready
}
proc bomb_ready {} {
 if {!([byte [expr {$::world_map+7297}]]&(1<<$::bomb_index))} {after time 0.1 bomb_ready;return}
 incr ::bomb_index;bomb_collect
}
proc sample_walk {} {
 lappend ::walk_samples [word [actor 0]];incr ::sample_count;hold [expr {[word [actor 0]]/16-80}] 90
 if {$::sample_count<15} {after time 0.15 sample_walk;return}
 check {[llength [lsort -unique $::walk_samples]]>3 && [byte [expr {[actor 0]+10}]]} "Native Asparagusto walking on real terrain: samples=$::walk_samples active=[byte [expr {[actor 0]+10}]] death=[byte $::death_ticks] cam=[word $::camera_px],[word $::camera_py]"
 set a [actor 0];putword $::shots [expr {[word $a]+128}];putword [expr {$::shots+2}] [expr {[word [expr {$a+2}]]+128}]
 putword [expr {$::shots+4}] 0;putword [expr {$::shots+6}] 0;putword [expr {$::shots+8}] 140;debug write memory [expr {$::shots+10}] 1;debug write memory [expr {$::shots+13}] 0
 after time 0.02 flower
}
proc cadence {} {
 if {$::phase==8} {lappend ::squash_states [byte [expr {[actor 3]+13}]]}
 if {$::phase==4} {set b [actor 2];set state [byte [expr {$b+13}]];if {$state==2} {set ::sawattack 1};if {$state==3} {set ::sawrecovery 1;incr ::recoverycalls}}
 set a [actor 0];set tick [word $::simulation_ticks];set timer [word [expr {$a+8}]]
 if {$::phase==3 && [byte [expr {$a+13}]]==1} {
  if {$::previous_tick>=0} {check {[expr {($tick-$::previous_tick)&65535}]==1 && $timer==$::previous_timer-1} "One enemy update per native simulation tick";incr ::cadence_calls}
  set ::previous_tick $tick;set ::previous_timer $timer
 }
}
proc flower {} {
 if {[byte [expr {[actor 0]+13}]]!=1} {after time 0.01 flower;return}
 check {[word $::flower_hits]>0 && ![byte [expr {$::shots+10}]]} "Native shot transforms Asparagusto"
 set ::phase 3;after time 0.1 recovery
}
proc recovery {} {
 if {[byte [expr {[actor 0]+13}]]==1} {after time 0.1 recovery;return}
 check {$::cadence_calls>300 && [word $::flower_returns]>0} "350-tick flower and recovery calls=$::cadence_calls returns=[word $::flower_returns] timer=[word [expr {[actor 0]+8}]] life=[byte $::game_lives] death=[byte $::death_ticks]"
 set ::phase 4;set ::sawattack 0;set ::sawrecovery 0;set ::recoverycalls 0;set ::deferred start_brocco
}
proc start_brocco {} {
 set a [actor 2];putword $a [expr {32*256}];putword [expr {$a+2}] [expr {13*256}];debug write memory [expr {$a+10}] 1;debug write memory [expr {$a+11}] 144;debug write memory [expr {$a+12}] 1;debug write memory [expr {$a+13}] 0;debug write memory [expr {$a+14}] 1;debug write memory [expr {$a+15}] 6;hold 572 208;after time 0.1 brocco_cycle
}
proc brocco_cycle {} {
 if {!$::sawrecovery || [byte [expr {[actor 2]+13}]]!=0} {after time 0.01 brocco_cycle;return}
 check {$::sawattack && $::recoverycalls==6 && ![byte $::death_ticks]} "Native Brocco smash and six-tick recovery"
 set ::deferred approach_brocco
}
proc approach_brocco {} {
 set a [actor 2];hold [expr {[word $a]/16+([byte [expr {$a+14}]]?32:-32)}] [expr {[word [expr {$a+2}]]/16-8}];set ::oldlife [byte $::game_lives];set ::oldammo [word $::flower_ammo];putword $::player_x [expr {[word $a]+([byte [expr {$a+14}]]?512:-512)}];putword $::player_y [word [expr {$a+2}]];putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;after time 0.02 brocco_damage
}
proc brocco_damage {} {
 if {![byte $::death_ticks] && ![byte $::restart_pending]} {after time 0.02 brocco_damage;return}
 set ::held 0;check {[byte $::death_ticks] || [byte $::restart_pending]} "Native Brocco smash kills Keen";after time 1 restarted
}
proc restarted {} {
 if {[byte $::game_lives]==$::oldlife || [byte $::restart_pending] || [byte $::death_ticks] || [word $::player_x]!=69*256 || [word $::drawn_x]!=69*256 || [byte $::render_commit]} {after time 0.1 restarted;return}
 check {[word $::flower_ammo]==$::oldammo && ![word $::pickup_taken] && [word $::boobus_bombs]==$::baseline_bombs && ![byte [expr {$::world_map+7297}]]} "Death restores objects and preserves ammunition"
 set ::phase 8;set ::squash_states {};hold [expr {[word [actor 3]]/16+56}] [expr {[word [expr {[actor 3]+2}]]/16}];after time 4 squash_ready
}
proc squash_ready {} {
 check {[lsearch -exact $::squash_states 2]>=0 && [lsearch -exact $::squash_states 3]>=0 && [lsearch -exact $::squash_states 4]>=0 && ![byte $::death_ticks]} "Native Squasher jump, descending phase and landing on original terrain"
 debug write memory $::enemy_mode 1;set ::index 0;set ::pose 0;set ::phase 5;next_pose
}
proc next_pose {} {set ::deferred apply_pose}
proc apply_pose {} {
 if {$::index==6} {set ::object_index 0;next_object;return}
 set a [actor $::index]
 set x [expr {[word $a]/16}];set y [expr {[word [expr {$a+2}]]/16}];hold [expr {$x>112?$x-80:32}] [expr {$y>64?$y-32:32}]
 if {$::index<2} {set frame [expr {$::pose==8?26:108+$::pose}]} elseif {$::index==2} {set frame [expr {$::pose==16?26:136+$::pose}]} else {set frame [expr {$::pose==8?26:116+$::pose}]}
 set ::frame $frame;debug write memory [expr {$a+11}] $frame;debug write memory [expr {$a+13}] [expr {$frame==26?1:0}];after time 1.3 pose_ready
}
proc pose_ready {} {
 if {[byte $::render_commit]} {after time 0.001 pose_ready;return}
 set a [actor $::index];check {[byte [expr {$a+10}]]} "Original actor wakes"
 set ex [expr {[word $a]/16-($::frame==26?0:24)}];set ey [expr {[word [expr {$a+2}]]/16-($::frame==26?0:4)}];set found 0
 for {set i 15} {$i<28} {incr i} {set d [expr {$::actors_old+[byte $::front_page]*174+6*$i}];if {[byte [expr {$d+5}]] && [byte [expr {$d+4}]]==$::frame && [word $d]==$ex && [word [expr {$d+2}]]==$ey} {set found 1}}
 if {!$found} {after time 0.01 pose_ready;return}
 set name "enemy-$::index-pose-$::pose";snap $name;lappend ::names $name;incr ::pose
 set limit [expr {$::index==2?17:9}];if {$::pose==$limit} {incr ::index;set ::pose 0};next_pose
}
proc next_object {} {
 set coords {{1040 48} {600 96} {96 320} {850 100} {500 220}}
 if {$::object_index==5} {set f [open $::env(KEEN_TEST_OUTPUT)/retained-map.bin wb];puts -nonewline $f [debug read_block memory $::world_map 6830];close $f;set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f;set ::held 0;putword $::player_x [expr {2*256+64}];putword $::player_y [expr {6*256}];debug write memory $::climbing 0;keys 16;after time 2 {keys 0;after time 0.2 finishing};return}
 lassign [lindex $coords $::object_index] x y;hold $x $y;after time 1 object_ready
}
proc object_ready {} {if {[byte $::render_commit]} {after time 0.001 object_ready;return};set name "object-$::object_index";snap $name;lappend ::names $name;incr ::object_index;next_object}
proc finishing {} {
 if {![byte $::level_done] && ![byte $::world_active]} {after time 0.2 finishing;return}
 keys 1;after time 0.2 {keys 0};after time 1 {keys 1;after time 0.2 {keys 0}};after time 2 world_done
}
proc world_snap {name} {
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.vram wb];puts -nonewline $f [debug read_block VRAM [expr {[byte $::wpage]*32768}] 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.map wb];puts -nonewline $f [debug read_block memory $::world_map 6312];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w];puts $f "[word $::world_x] [word $::world_y] [byte $::wframe] [word $::wcx] [word $::wcy] [word $::world_completed] [byte $::hardware_scroll] [byte $::world_notice]";close $f
}
proc world_done {} {
 if {![byte $::world_active] || !([word $::world_completed]&512) || [byte $::world_draw_busy]} {after time 0.1 world_done;return}
 world_snap world-complete;keys 160;after time 0.3 {keys 0;after time 0.6 northeast}
}
proc northeast {} {
 if {[byte $::world_draw_busy]} {after time 0.01 northeast;return}
 check {[byte $::wframe]==23} "Northeast world pose uses extra patterns";world_snap world-northeast
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: tenth-stage Tuberia entry, native movement/Asparagusto walking, 350-tick flower recovery ($::cadence_calls calls), native Brocco smash, six-tick recovery and lethal attack, native Squasher jump/descent/landing, three original bombs collected and rolled back on death/restart with retained ammunition; [llength $::names] controlled complete-frame render captures; real exit and Tuberia completion, northeast world graphics.";close $f;exit
}
after time 40 entry
after time 650 {check {0} "Timeout phase=$::phase index=[expr {[info exists ::index]?$::index:-1}] pose=[expr {[info exists ::pose]?$::pose:-1}] x=[word $::player_x] y=[word $::player_y] world=[byte $::world_active] level=[byte $::level_done] brocco=[word [actor 2]],[word [expr {[actor 2]+2}]],[byte [expr {[actor 2]+13}]],[byte [expr {[actor 2]+15}]],[byte [expr {[actor 2]+12}]] active=[byte [expr {[actor 2]+10}]] ground=[byte [expr {[actor 2]+14}]] cam=[word $::camera_px],[word $::camera_py] mode=[byte $::enemy_mode] life=[byte $::game_lives] phase4=$::sawattack,$::sawrecovery,$::recoverycalls"}
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n' for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {syms["ReadInput"]&65535} {{[byte $::g_CurrentSegment]==31}} movement\n'
s+=f'\ndebug set_bp {syms["SwampTick"]&65535} {{[byte $::g_CurrentSegment]==75}} cadence\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with (out/'emulator.log').open('w') as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=700)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text();assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
actual=(out/'retained-map.bin').read_bytes();expected=(r/'assets/swamp/load_data.bin').read_bytes()
assert actual[:2415]==expected[:2415] and actual[5000:]==expected[5000:], 'Map/metadata integrity after Brocco poses'
names=(out/'names.txt').read_text().splitlines();subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
subprocess.run([sys.executable,str(r/'tests/verify_world_pixels.py'),str(out),'world-complete','world-northeast'],env=env,check=True)
(out/'ROM-SHA256.txt').write_text(hashlib.sha256((r/'build/keen_msx.rom').read_bytes()).hexdigest()+'\n')
(out/'VERIFIED.txt').write_text(f'PASS: independent pixel reconstruction for all {len(names)} tenth-stage complete frames and two world views.\n');print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
