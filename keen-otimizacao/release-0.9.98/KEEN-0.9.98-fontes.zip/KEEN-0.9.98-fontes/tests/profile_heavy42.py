"""Repeatable renderer benchmark with explicit actor positioning/animation fixtures.
Not a prediction of whole-game FPS. Both ROMs receive identical emulated ticks.
"""
from pathlib import Path
import sys,re,subprocess,os,json
r=Path(sys.argv[1]).resolve();kind=sys.argv[2]
stage=11 if kind=='boobus' else 5
out=r/'build'/('heavy42-'+kind);out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
x,y=(21,15) if stage==11 else (16,65) if kind=='brocco' else (8,38)
index=7 if kind=='brocco' else 5
actor=sym['world_map']+(7200 if stage==11 else 9000+index*16)
worldpos=979 if stage==11 else 3819
s='\n'.join(f'set {n} {a}'for n,a in sym.items())+f'\nset long_jump {int(kind=="squasher")}\nset target_stage {stage}\nset actor {actor}\nset ax {x*256}\nset ay {y*256}\nset px {(x-2)*256}\nset py {(y+2 if stage==11 else y)*256}\nset wx {worldpos%85*16}\nset wy {worldpos//85*16}\nset baseframe {108 if stage==11 else 136 if kind=="brocco" else 116}\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set testing 0
set measuring 0
set uploads 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc start {} {
 if {[byte $::world_active]!=1} {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 1 start};return}
 if {[byte $::world_draw_busy]} {after time 0.1 start;return}
 putword $::world_x $::wx;putword $::world_y $::wy;putword $::boobus_bombs 50
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1;after time 0.5 entered}
}
proc entered {} {
 if {[byte $::active_level]!=$::target_stage || [byte $::world_active] || [byte $::scene_ready]!=165} {after time 0.1 entered;return}
 debug write memory $::enemy_mode 1;set ::testing 1
 after time 4 measure
}
proc fixture {} {
 if {!$::testing} {return}
 set tick [word $::simulation_ticks]
 putword $::player_x $::px;putword $::player_y $::py;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1
 if {$::target_stage==5} {
  for {set i 0} {$i<10} {incr i} {set a [expr {$::world_map+9000+$i*16}];putword $a 50000;debug write memory [expr {$a+10}] 0}
 }
 putword $::actor [expr {$::ax+($::long_jump?(($tick/8)%3)*768:($tick%16)*32)}];putword [expr {$::actor+2}] $::ay
 debug write memory [expr {$::actor+10}] 1;debug write memory [expr {$::actor+11}] [expr {$::baseframe+($tick/20)%4}]
 debug write memory $::combat_dirty 1
}
proc upload {} {if {$::measuring} {incr ::uploads}}
proc measure {} {set ::first [word $::render_count];set ::start_time [machine_info time];set ::measuring 1;after time 10 done}
proc done {} {
 set frames [expr {([word $::render_count]-$::first)&65535}];set duration [expr {[machine_info time]-$::start_time}]
 set f [open $::env(KEEN_TEST_OUTPUT)/result.json w];puts $f "{\"frames\":$frames,\"seconds\":$duration,\"fps\":[expr {$frames/$duration}],\"upload_calls\":$::uploads}";close $f;exit
}
after time 3 start
after time 120 {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f "timeout";close $f;exit}
'''
s+=f'\ndebug set_bp {sym["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
name='BoobusTexture' if kind=='boobus' and 'BoobusTexture'in sym else 'BoobusRows' if kind=='boobus' else 'BroccoDecode'
bank=0 if name.startswith('Boobus') else 69
s+=f'\ndebug set_bp {sym[name]&65535} {{[byte $::g_CurrentSegment]=={bank}}} upload\n' if bank else f'\ndebug set_bp {sym[name]&65535} {{}} upload\n'
(out/'test.tcl').write_text(s);(out/'FAIL.txt').unlink(missing_ok=True);(out/'result.json').unlink(missing_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with(out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=180,check=True)
assert (out/'result.json').exists(),(out/'emulator.log').read_text()
print(kind,(out/'result.json').read_text())
