from pathlib import Path
import re,subprocess
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
for name,freq in [('z80',3579545),('fast',10000000)]:
 out=r/'build'/('0912-p3-'+name);out.mkdir(exist_ok=True)
 fields=['p3done','p3ok','p3cpu','p3slot','p3hz','p3size']
 report='\n'.join(f'puts $f "{n} [{'word' if n=='p3size' else 'debug read memory'} {s[n]}]"' for n in fields)
 script=f'''set throttle off
set save_settings_on_exit false
set z80_freq {freq}
set z80_freq_locked false
set writes 0
set rom_calls 0
set ram_calls 0
proc word {{a}} {{expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}}}
debug set_watchpoint write_io {{0x98 0x9b}} {{}} {{if {{[debug read memory {s['p3stage']}]>=1 && [debug read memory {s['p3stage']}]<=4}} {{incr writes}}}}
debug set_bp {s['Phase3Kernel']&65535} {{[debug read memory {s['g_CurrentSegment']}] == 45}} {{incr rom_calls}}
debug set_bp {s['world_map']+6000} {{}} {{incr ram_calls}}
after time 10 {{keymatrixdown 4 4;after time 0.3 {{keymatrixup 4 4}}}}
after time 13 {{keymatrixdown 8 1;after time 0.3 {{keymatrixup 8 1}}}}
after time 90 {{
 set f [open {{{out/'result.txt'}}} w]
 puts $f "clock [machine_info z80_freq]"
 puts $f "writes $writes";puts $f "rom_calls $rom_calls";puts $f "ram_calls $ram_calls"
 {report}
 foreach {{name addr count}} {{rom {s['p3rom']} 2 ram {s['p3ram']} 2 checksum {s['p3checks']} 4}} {{for {{set i 0}} {{$i<$count}} {{incr i}} {{puts $f "$name$i [word [expr {{$addr+2*$i}}]]"}}}}
 close $f
 screenshot {{{out/'result.png'}}};exit
}}
'''
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],stdout=log,stderr=log,timeout=60,check=True)
 v=dict(line.split() for line in (out/'result.txt').read_text().splitlines());print(name,v,flush=True)
 assert v['p3done']=='1' and v['p3ok']=='1' and v['writes']=='0'
 assert v['rom_calls']=='2' and v['ram_calls']=='2'
 assert all(v['checksum'+str(i)]=='14446' for i in range(4))
 assert all(int(v[k])>0 for k in ['rom0','rom1','ram0','ram1'])
