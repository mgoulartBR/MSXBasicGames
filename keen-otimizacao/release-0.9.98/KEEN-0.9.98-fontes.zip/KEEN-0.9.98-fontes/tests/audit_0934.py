"""Original map/object identity, eight-stage caches, baseline resources, LZ atlas."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,re,hashlib
r=Path(__file__).resolve().parents[1];maps=json.loads((r/'assets/generated/maps.json').read_text());rows=[]
for level in (1,2,3,4,5,7,9,10):
 m=next(x for x in maps if x['id']==level);bs=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-1<=bx-x<=2 and -2<=by-y<=3 for bx,by in bs)for x in range(m['width'])for y in range(m['height']));assert peak<=8;rows.append((level,len(bs),peak))
m=next(x for x in maps if x['id']==10);keys=sorted(set(zip(*m['planes'][:2])));raw=(r/'assets/grove/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<5421H',raw)]==list(zip(*m['planes'][:2]))
spawns=re.findall(r'\{(\d+),(\d+),(\d+)\}',(r/'src/grove_spawns.h').read_text())
assert sorted((int(y)*139+int(x),int(v))for x,y,v in spawns)==sorted((i,v)for i,v in enumerate(m['planes'][2])if v in (47,45,41,57,46,31))
atlas=bytearray()
for bank,offset,y,rows_,k,size in json.loads((r/'assets/grove/atlas_parts.json').read_text()):
 data=(r/'assets/grove'/f'atlas_part{k}.bin').read_bytes();assert len(data)==size and len(atlas)==y*128;pos=0
 while len(atlas)<(y+rows_)*128:
  flags=data[pos];pos+=1
  for bit in range(8):
   if flags>>bit&1:atlas.append(data[pos]);pos+=1
   else:
    lo,hi=data[pos:pos+2];pos+=2;dist=(((hi&240)<<4)|lo)+1;n=(hi&15)+3
    for _ in range(n):atlas.append(atlas[-dist])
   if len(atlas)==(y+rows_)*128:break
 assert pos==len(data)
assert atlas==(r/'assets/grove/atlas.bin').read_bytes()
# The retained cache band covers every possible contact at all sub-tile offsets.
for width in (8,16,24):
 for ox in range(16):
  for tile_delta in range(-4,5):
   contact=ox+4-tile_delta*16<width and tile_delta*16-ox-4<16
   assert not contact or -1<=tile_delta<=2
with ZipFile(r.parent/'deliverables/v0.9.33/keen-dreams-msx-0.9.33-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass','city','apple'):
  for p in (r/'assets'/level).glob('*.bin'):
   if p.name in ('ram_tables.bin','ram_sprites.bin'):continue
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'deliverables/v0.9.33/KEEN0933.ROM').read_bytes()).hexdigest()=='835b6fce4a9c35c4c7c91884884d32bb188d153cd33329fca250e62f19636fad'
print('PASS: 5421 original background/foreground cells, 42 object positions; atlas LZSS decodes byte-identically; baseline 0.9.33 preserved; %d unchanged previous-stage binaries; eight-stage bonus cache census %s.'%(count,rows))
