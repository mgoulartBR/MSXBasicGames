"""Eight keyboard-driven loads: enemy, visible pickups, repeated jumping."""
from pathlib import Path
import re,sys
m=Path(sys.argv[1]);out=Path(sys.argv[2]);d={n:int(a,16)for a,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',m.read_text())}
s='\n'.join(f'set {n} {d[n]}'for n in ['render_count','drawn_camera_py','pickup_taken','enemy','defeats','actors_old','front_page','player_x','player_y'])
s+=r'''
set renderer SDL
set sound_driver null
set throttle off
set save_settings_on_exit false
proc word {a} {return [expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}]}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc fixtures {} {
 if {!($::case&1)} {debug write memory $::enemy 0;debug write memory [expr {$::enemy+1}] 2;debug write memory [expr {$::enemy+10}] 0} else {
  # Visual/logic load fixture: keep the enemy visible, 80 px from Keen,
  # so deaths cannot make a heavier case look artificially faster.
  putword $::enemy [expr {[word $::player_x]-1280}]
  putword [expr {$::enemy+2}] [word $::player_y]
  debug write memory [expr {$::enemy+10}] 1
 }
 if {!($::case&2)} {debug write memory $::pickup_taken 255;debug write memory [expr {$::pickup_taken+1}] 3}
}
proc jump {} {keymatrixdown 8 1;after time 0.6 {keymatrixup 8 1};after time 1.6 jump}
proc sample {} {
 global f last prev oldy records
 fixtures;incr f
 set n [word $::render_count]
 if {$n!=$last} {
  set y [word $::drawn_camera_py];set page [debug read memory $::front_page]
  set en [debug read memory [expr {$::actors_old+$page*90+11}]];set pk 0
  for {set i 4} {$i<14} {incr i} {incr pk [debug read memory [expr {$::actors_old+$page*90+$i*6+5}]]}
  lappend records "[expr {$f-$prev}],$y,[expr {$y-$oldy}],$en,$pk"
  set oldy $y;set prev $f;set last $n
 }
 if {$f<240} {after frame sample} else {
  set o [open $::env(KEEN_BENCH_OUT) w]
  puts $o "interval,camera_y,delta_y,enemy_visible,pickups_visible"
  puts $o [join $records \n];puts $o "defeats=[word $::defeats]";close $o;exit
 }
}
after time 10 {
 set case $::env(KEEN_LOAD_CASE);fixtures
 set f 0;set prev 0;set last [word $render_count];set oldy [word $drawn_camera_py];set records {}
 keymatrixdown 8 16
 if {$case&4} {jump}
 after frame sample
}
'''
out.write_text(s)
