"""Native boss battle and original pixel reconstruction; positioning fixtures are explicit."""
from pathlib import Path
import os,re,subprocess,sys,hashlib
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0942-boss-pixels-rom' if machine=='C-BIOS_MSX2+' else '0942-boss-pixels-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='11',KEEN_TEST_OUTPUT=str(out))
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}'for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set protected_checks 0
set phase 0
set names {}
set phase_ticks 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc boss {} {expr {$::world_map+7200}}
proc hp {} {byte [expr {$::world_map+7216}]}
proc hold {x y} {set ::held 1;set ::hx $x;set ::hy $y}
proc fixture {} {
 if {$::phase==7 && [hp]} {set a [boss];putword $a [expr {21*256}];putword [expr {$a+2}] [expr {15*256}];debug write memory [expr {$a+12}] 1;debug write memory [expr {$a+13}] 0;hold [expr {21*256-512}] [expr {15*256+512}]}
 if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}
}
# Check actual VRAM BEFORE HWUpload can rewrite attributes/patterns.
# The earlier frame verifier checked bitmap pixels only, missing this overlap.
proc protect_begin {} {
 set ::protected_before [debug read_block VRAM 65536 12288]
}
proc protect_end {} {
 if {[info exists ::protected_before]} {
  check {[debug read_block VRAM 65536 12288] eq $::protected_before} "Boss drawing corrupted Keen hardware sprite VRAM"
  incr ::protected_checks
  unset ::protected_before
 }
}
proc gate {} {
 if {[byte $::world_active]!=1} {after time 0.1 gate;return}
 putword $::world_x 704;putword $::world_y 176;keys 1;set ::phase 1;after time 0.3 {keys 0;after time 0.5 blocked}
}
proc blocked {} {
 check {[byte $::world_active] && [byte $::active_level]==1 && [word $::boobus_bombs]==0} "Original less-than-12-bombs gate blocks entry: world=[byte $::world_active] stage=[byte $::active_level] bombs=[word $::boobus_bombs] coords=[word $::world_x],[word $::world_y]"
 putword $::boobus_bombs 12;putword $::flower_ammo 17;keys 1;after time 0.3 {keys 0;after time 0.1 entered}
}
proc entered {} {
 if {[byte $::active_level]!=11 || [byte $::world_active] || [byte $::scene_ready]!=165} {after time 0.1 entered;return}
 check {[byte [expr {$::world_collision+1120}]]==35 && [byte [expr {$::world_collision+1121}]]==30 && [hp]==12} "Original boss arena and HP"
 debug write memory $::enemy_mode 1;set ::phase 6;set ::pose 0;pose
}
proc sample {} {
 lappend ::positions [word [boss]]
 if {[llength $::positions]<15} {after time 0.15 sample;return}
 check {[llength [lsort -unique $::positions]]>3 && ![byte $::death_ticks]} "Boss chases on original terrain without player collision"
 set ::phase 3;set ::phase_ticks 0
 set a [boss];hold [expr {[word $a]+256}] [expr {[word [expr {$a+2}]]-512}];after time 0.01 jumped
}
proc observe {} {if {$::phase==3} {incr ::phase_ticks;if {[byte [expr {[boss]+13}]]==1 && [byte [expr {[boss]+11}]]==116} {set ::jump_seen 1}}}
proc jumped {} {
 if {![info exists ::jump_seen]} {after time 0.01 jumped;return}
 set ::phase 4;set a [boss];hold [expr {[word $a]-512}] [expr {[word [expr {$a+2}]]+512}]
 set ::bombs_before [word $::boobus_bombs];set ::shots_before [word $::shots_fired];keymatrixdown 3 1;after time 0.01 thrown
}
proc thrown {} {
 if {[word $::shots_fired]==$::shots_before} {after time 0.02 thrown;return}
 keymatrixup 3 1
 check {[word $::shots_fired]==$::shots_before+1 && [word $::boobus_bombs]==$::bombs_before-1 && [word $::flower_ammo]==17} "C throws one bomb, retains Flower Power: fired=[word $::shots_fired]/$::shots_before bombs=[word $::boobus_bombs]/$::bombs_before FP=[word $::flower_ammo] life=[byte $::game_lives]"
 set ::oldlife [byte $::game_lives];set a [boss];hold [expr {[word $a]+256}] [expr {[word [expr {$a+2}]]+128}];after time 0.01 killed
}
proc killed {} {
 if {![byte $::death_ticks] && ![byte $::restart_pending]} {after time 0.01 killed;return}
 set ::held 0;set ::phase 5;after time 0.1 restarted
}
proc restarted {} {
 if {[byte $::game_lives]==$::oldlife || [byte $::death_ticks] || [byte $::restart_pending] || [word $::drawn_x]!=3*256 || [byte $::render_commit]} {after time 0.1 restarted;return}
 check {[word $::boobus_bombs]==12 && [word $::flower_ammo]==17 && [hp]==12} "Native lethal contact restores attempt bombs and boss HP"
 debug write memory $::enemy_mode 1;set ::phase 6;set ::pose 0;pose
}
proc pose {} {
 set a [boss];putword $a [expr {21*256}];putword [expr {$a+2}] [expr {15*256}];set ::poseframe [expr {$::pose<9?108+$::pose:116}];debug write memory [expr {$a+11}] $::poseframe
 if {$::pose==9} {putword $a [expr {224*16}];putword [expr {$a+2}] [expr {232*16}];hold [expr {112*16}] [expr {320*16}]} elseif {$::pose==10} {putword $a [expr {224*16}];putword [expr {$a+2}] [expr {160*16}];hold [expr {352*16}] [expr {224*16}]} else {hold [expr {18*256}] [expr {19*256+16*($::pose&1)}]};after time 1 pose_snap
}
proc pose_snap {} {
 if {[byte $::render_commit]} {after time 0.001 pose_snap;return}
 set found 0
 for {set i 15} {$i<28} {incr i} {set d [expr {$::actors_old+[byte $::front_page]*174+6*$i}];if {[byte [expr {$d+5}]] && [byte [expr {$d+4}]]==$::poseframe} {set found 1}}
 if {!$found} {after time 0.01 pose_snap;return}
 set name "boss-$::pose";snap $name;lappend ::names $name;incr ::pose
 if {$::pose<11} {pose;return}
 set ::effect 0;effect
}
proc effect {} {
 set f [expr {$::world_map+7248}];putword $f [expr {19*256}];putword [expr {$f+2}] [expr {18*256}];debug write memory [expr {$f+10}] 1;debug write memory [expr {$f+11}] [expr {117+$::effect}];after time 1 effect_snap
}
proc effect_snap {} {
 if {[byte $::render_commit]} {after time 0.001 effect_snap;return}
 set name "effect-$::effect";snap $name;lappend ::names $name;incr ::effect
 if {$::effect<6} {effect;return}
 set f [open $::env(KEEN_TEST_OUTPUT)/retained-map.bin wb];puts -nonewline $f [debug read_block memory $::world_map 6830];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
 check {$::protected_checks>30} "Insufficient protected boss draws"
 set f [open $::env(KEEN_TEST_OUTPUT)/SPRITE-VRAM.txt w];puts $f "PASS: $::protected_checks boss draws preserved hero VRAM before hero upload";close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: boss walking/jump/clipped/effect poses and original entry gate; explicit positions and frames";close $f;exit
}
proc fire {} {set ::before_hp [hp];keymatrixdown 3 1;after time 0.01 hit}
proc hit {} {
 if {[hp]==$::before_hp} {after time 0.01 hit;return}
 keymatrixup 3 1;set ::released_render [word $::render_count];incr ::hits;check {[hp]==12-$::hits && [word $::boobus_bombs]==12-$::hits && [word $::flower_ammo]==17 && ![byte $::death_ticks]} "One C bomb gives one boss hit and one ammunition decrement"
 if {$::hits<12} {after time 0.1 rearmed;return}
 check {[word $::game_score]+65536*[word [expr {$::game_score+2}]]==100000+$::baseline_score} "Original 100000-point boss award"
 set ::phase 8;after time 0.3 dying
}
proc rearmed {} {if {[expr {([word $::render_count]-$::released_render)&65535}]<2} {after time 0.1 rearmed;return};fire}
proc dying {} {
 if {[word [expr {$::world_map+7220}]]<90} {after time 0.1 dying;return}
 check {![byte $::death_ticks]} "Defeated boss contact harmless"
 snap death;lappend ::names death;set f [open $::env(KEEN_TEST_OUTPUT)/retained-map.bin wb];puts -nonewline $f [debug read_block memory $::world_map 6830];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
 check {$::protected_checks>100} "Insufficient live boss VRAM checks"
 set f [open $::env(KEEN_TEST_OUTPUT)/SPRITE-VRAM.txt w];puts $f "PASS: $::protected_checks protected boss draws";close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: boss poses/effects, native chase/jump/death/restart, twelve C bomb hits and award";close $f;exit
}

after time 40 gate
after time 450 {check {0} "Timeout phase=$::phase hp=[hp] bombs=[word $::boobus_bombs] life=[byte $::game_lives] death=[byte $::death_ticks] level=[byte $::level_done]"}
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n'for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["BoobusBitmap"]&65535} {{[byte $::g_CurrentSegment]==81}} protect_begin\n'
s+=f'\ndebug set_bp {syms["HWUpload"]&65535} {{[byte $::g_CurrentSegment]==21}} protect_end\n'
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+=f'\ndebug set_bp {syms["BoobusTick"]&65535} {{[byte $::g_CurrentSegment]==81}} observe\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with(out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=500)
assert not(out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text();assert(out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
a=(out/'retained-map.bin').read_bytes();b=(r/'assets/boobus/load_data.bin').read_bytes();assert a[:1182]==b[:1182]and a[5000:]==b[5000:]
names=(out/'names.txt').read_text().splitlines();subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)

(out/'ROM-SHA256.txt').write_text(hashlib.sha256((r/'build/keen_msx.rom').read_bytes()).hexdigest()+'\n');(out/'VERIFIED.txt').write_text(f'PASS: independent original pixels for {len(names)} boss/jump/clipping/effect complete frames and protected hero VRAM.\n');print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
