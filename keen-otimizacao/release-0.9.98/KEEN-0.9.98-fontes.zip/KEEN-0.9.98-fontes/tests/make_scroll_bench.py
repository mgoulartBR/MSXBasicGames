from pathlib import Path
import re,sys
root=Path(sys.argv[1]);d={n:int(v,16) for v,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',(root/'build/keen_msx.map').read_text())}
s='\n'.join(f'set {n} {v}' for n,v in d.items())+r'''
set renderer SDL
set sound_driver null
set throttle off
set save_settings_on_exit false
proc word {a} {return [expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}]}
proc sample {} {
 global last f prev intervals records
 incr f
 set n [word $::render_count]
 if {$n!=$last} {
  lappend intervals [expr {$f-$prev}]
  lappend records "[expr {$f-$prev}],[word $::drawn_camera_px],[debug read memory $::drawn_cy],[debug read memory $::cost_bg],[debug read memory $::cost_actor],[debug read memory $::cost_game]"
  set prev $f;set last $n
 }
 if {$f<240} {after frame sample} else {
  keymatrixup 8 16
  set o [open $::env(KEEN_BENCH_OUT) w];puts $o $intervals
  foreach n {full_redraws scroll_copies max_backlog stable_ticks stable_x} {puts $o "$n=[word [set ::$n]]"}
  puts $o "interval,camera_x,camera_y,background,actor,physics"
  puts $o [join $records \n];close $o;exit
 }
}
after time 10 {set f 0;set prev 0;set intervals {};set records {};set last [word $render_count];keymatrixdown 8 16;after frame sample}
'''
(root/'build/scroll-bench-current.tcl').write_text(s)
