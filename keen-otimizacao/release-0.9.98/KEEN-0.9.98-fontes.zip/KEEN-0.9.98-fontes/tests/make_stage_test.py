from pathlib import Path
import re,sys
r=Path(sys.argv[1]);s=(r/'build/game-test.tcl').read_text().split('after time 10 {')[0].replace('set throttle on','set throttle off')
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
for n in ['player_x','player_y','player_vx','player_vy','grounded']:s+=f'\nset raw_{n} {syms[n]}\n'
s+=r'''
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc place {x y} {
 putword $::raw_player_x $x;putword $::raw_player_y $y
 putword $::raw_player_vx 0;putword $::raw_player_vy 0
 debug write memory $::raw_grounded 0
 debug write memory $::combat_dirty 1
}
after time 10 {
 check {[byte $scene_ready]==165 && ![byte $hud_debug]} "Boot with inventory HUD"
 snap spawn
 putword $flower_ammo 18;debug write memory $combat_dirty 1
 after time 0.4 {snap ammo;keymatrixdown 3 8}
 after time 0.7 {keymatrixup 3 8}
 after time 1.0 {check {[byte $hud_debug]==1} "F enables FPS";snap debug;keymatrixdown 3 8}
 after time 1.3 {keymatrixup 3 8}
 after time 1.6 {check {![byte $hud_debug] && [word $flower_ammo]==18} "F restores inventory";snap inventory}
 after time 2.0 {
  debug write memory $enemy_mode 3
  place [expr {105*256-184}] [expr {28*256}]
  set pole_start_y [word $raw_player_y];keymatrixdown 8 32
 }
 after time 2.8 {
  check {[byte $climbing] && [word $raw_player_y]<$pole_start_y} "Climb original pole"
  check {[byte $player_frame]>=36} "Original climbing sprite"
  snap climb;keymatrixup 8 32
 }
 after time 3.2 {set stopped_y [word $raw_player_y]}
 after time 3.5 {check {[byte $climbing] && [word $raw_player_y]==$stopped_y} "Hold position";snap hold;keymatrixdown 8 64}
 after time 4.0 {check {[word $raw_player_y]>$stopped_y} "Slide downward";snap slide;keymatrixup 8 64;keymatrixdown 8 129}
 after time 4.15 {check {![byte $climbing]} "Jump off pole";keymatrixup 8 129}
 after time 4.5 {snap jump_off}
 # +1 pickup on the original map: overlap its hitbox and let normal collection run.
 after time 5 {
  putword $flower_ammo 0;putword $pickup_taken 0
  place [expr {[word [expr {$pickups+30}]]*16-64}] [expr {[word [expr {$pickups+32}]]*16-160}]
 }
 after time 5.4 {check {[word $flower_ammo]>=1} "Collect after climbing";snap collected;set before_shots [word $shots_fired];keymatrixdown 3 1}
 after time 5.7 {keymatrixup 3 1;check {[word $shots_fired]>$before_shots} "Throw collected ammo"}
 # Enter the actual right edge by walking; no direct write to level_done.
 after time 6 {
  place [expr {134*256-320}] [expr {480*16}]
  keymatrixdown 8 128
 }
 after time 7.5 {
  keymatrixup 8 128
  check {[byte $level_done]==2} "Right edge completes level"
  set finish_ticks [word $simulation_ticks]
  set f [open $::env(KEEN_TEST_OUTPUT)/complete.vram wb];puts -nonewline $f [debug read_block VRAM 0 32768];close $f
 }
 after time 8 {
  check {[word $simulation_ticks]==$finish_ticks} "Completion pauses simulation"
  keymatrixdown 8 1
 }
 after time 8.3 {keymatrixup 8 1}
 after time 12 {
  check {[byte $world_active]==1 && [byte $world_completed]} "Completion returns to world"
  keymatrixdown 4 8
 }
 after time 12.3 {keymatrixup 4 8;enter_first_level}
 after time 16 {
  check {![byte $world_active] && ![byte $level_done] && ![byte $climbing] && [word $flower_ammo]==0} "New game resets stage and inventory"
  check {[word $player_x]>32000} "New game returns to spawn";snap replay
  place 460 [expr {480*16}];keymatrixdown 8 16
 }
 after time 17 {
  keymatrixup 8 16;check {[byte $level_done]==2} "Left edge completes level"
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS HUD toggle, pole climb/hold/slide/jump, pickup, both exits, completion to world and new game.";close $f;exit
 }
}
'''
(r/'build/stage-test.tcl').write_text(s)
