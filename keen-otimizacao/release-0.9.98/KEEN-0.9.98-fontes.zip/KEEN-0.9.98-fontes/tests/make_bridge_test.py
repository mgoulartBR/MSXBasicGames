from pathlib import Path
import re,sys
r=Path(sys.argv[1]);out=Path(sys.argv[2]);syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {v}' for n,v in syms.items())+r'''
set throttle off
set save_settings_on_exit false
# Dismiss the startup title before the existing gameplay fixtures.
after time 3 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
set renderer SDL
set sound_driver null
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;puts $f "world=[word $::world_x],[word $::world_y] stage=[byte $::active_level] player=[word $::player_x],[word $::player_y]";close $f;exit;error $msg}}
proc waitfor {c cb} {if {[expr $c]} {eval $cb} else {after time 0.02 [list waitfor $c $cb]}}
proc dump {name} {
 if {[byte $::render_commit]} {after time 0.001 [list dump $name];return}
 foreach {suffix device start size} [list vram VRAM 0 131072 regs {VDP regs} 0 64] {
  set f [open $::env(KEEN_TEST_OUTPUT)/$name.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f
 }
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w]
 puts $f "[word $::drawn_camera_px] [word $::drawn_camera_py] [word $::drawn_x] [word $::drawn_y] [byte $::drawn_frame] [byte $::front_page] [byte $::hardware_scroll]"
 close $f
}
proc loaded {} {
 check {[byte $::active_level]==3} "Bridge selected through Tuberia"
 check {[byte [expr {$::world_collision+1120}]]==65 && [byte [expr {$::world_collision+1121}]]==62} "Original dimensions"
 check {[word $::player_x]==528*16 && [word $::player_y]<240*16} "Original spawn"
 check {[byte [expr {$::world_collision+1127}]]==23 && [byte [expr {$::enemy+10}]]==0 && [byte $::tomato_count]==0} "Collectibles enabled, enemies deferred"
 set f [open $::env(KEEN_TEST_OUTPUT)/bridge-map.bin wb];puts -nonewline $f [debug read_block memory $::world_map 4534];close $f
 dump spawn
 # Test held restart key consumes one life, then return to the original spawn.
 keymatrixdown 4 128
 after time 3 {keymatrixup 4 128;after time 0.4 start_route}
}
proc start_route {} {
 check {[byte $::game_lives]==2 && ![byte $::death_ticks]} "Restart key consumes exactly one reserve while held"
 check {[word $::player_x]==528*16} "Restart returns to spawn"
 set ::initial_ticks [word $::simulation_ticks]
 keymatrixdown 8 128
 set ::midshot 0
 poll_route
}
proc poll_route {} {
 check {![byte $::death_ticks] && [byte $::game_lives]==2} "No death on right-hand route"
 if {!$::midshot && [word $::player_y]>500*16 && ![byte $::render_commit]} {set ::midshot 1;dump descent}
 if {[byte $::level_done]==2} {
  keymatrixup 8 128
  check {[word $::player_x]>980*16 && [word $::player_y]>700*16} "Reached actual lower right exit"
  keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
  waitfor {[byte $::world_active]==1} returned
 } else {after time 0.01 poll_route}
}
proc returned {} {
 check {[byte $::world_completed]==4 && [byte $::game_lives]==2} "Third completion flag and lives retained"
 set f [open $::env(KEEN_TEST_OUTPUT)/world-map.bin wb];puts -nonewline $f [debug read_block memory $::world_map 6312];close $f
 # Completing Bridge must prevent reentry, leaving the other stages available.
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
 after time 0.6 {
  check {[byte $::world_active]==1} "Completed Bridge cannot be reentered"
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: Tuberia entry, exact map, spawn, restart, keyboard-only stage traversal, right exit, return, completion and reentry lock.";close $f;exit
 }
}
set world_route {{1 754 624} {8 752 640} {2 800 640} {8 800 760} {2 840 760} {8 840 840}}
proc world_step {} {
 foreach mask {16 128 32 64} {keymatrixup 8 $mask}
 if {![llength $::world_route]} {
  keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
  after time 4 loaded;return
 }
 lassign [lindex $::world_route 0] b x y
 set ::world_route [lrange $::world_route 1 end]
 switch $b {
  1 {keymatrixdown 8 16;set c "\[word $::world_x\]<=$x"}
  2 {keymatrixdown 8 128;set c "\[word $::world_x\]>=$x"}
  4 {keymatrixdown 8 32;set c "\[word $::world_y\]<=$y"}
  8 {keymatrixdown 8 64;set c "\[word $::world_y\]>=$y"}
 }
 if {[byte $::hardware_scroll]} {waitfor $c world_step} else {
  foreach mask {16 128 32 64} {keymatrixup 8 $mask}
  world_pulse $b $c
 }
}
proc world_pulse {b c} {
 if {[expr $c]} {world_step;return}
 set mask [dict get {1 16 2 128 4 32 8 64} $b]
 keymatrixdown 8 $mask
 after time 0.025 [list keymatrixup 8 $mask]
 after time 0.3 [list world_pulse $b $c]
}
after time 10 {
 check {[byte $::world_active]==1} "Tuberia ready"
 world_step
}
after time 240 {check {0} "Overall timeout"}
'''
out.write_text(s)
