from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc shoot_probe {name next} {
 controls 0
 set ::before_fire [word $::shots_fired];set ::before_ammo [word $::flower_ammo]
 check {$::before_ammo>0} "Fixture has ammunition"
 keymatrixdown 3 1
 waitfor {[word $::shots_fired]>$::before_fire} [list fired_probe $name $next]
}
proc fired_probe {name next} {
 keymatrixup 3 1
 after time 0.05 [list verify_probe $name $next]
}
proc verify_probe {name next} {
 check {[byte [expr {$::shots+10}]] || [byte [expr {$::shots+26}]]} "Projectile survives in deep Melon: $name"
 check {[word $::flower_ammo]==$::before_ammo-1} "Only one seed spent: $name"
 waitfor {[byte [expr {$::actors_old+[byte $::front_page]*174+2*6+5}]] || [byte [expr {$::actors_old+[byte $::front_page]*174+3*6+5}]]} [list shown_probe $name $next]
}
proc shown_probe {name next} {
 snap $name
 after time 3 $next
}
proc get_key_probe {} {
 check {![byte $::key_owned]} "Deep shot already worked without key"
 controls 2
 waitfor {[byte $::key_owned]} {controls 0;after time 1 {shoot_probe after_key open_probe}}
}
proc open_probe {} {
 check {[byte $::key_owned]} "Shooting preserves key"
 place 1184 1328
 after time 1 {controls 2;waitfor {[byte $::door_state]==2} {controls 0;after time 1 {place 1208 928;after time 1 {shoot_probe after_door done_probe}}}}
}
proc done_probe {} {
 check {![byte $::key_owned] && [byte $::door_state]==2} "Shooting after consuming key"
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
 puts $f "PASS: visible projectiles with ammunition before collecting key, while holding key and after opening deep door; each shot spends one seed and preserves key/door state. Isolated positioning fixtures, normal fire key."
 close $f;exit
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2 && [byte $::scene_ready]==165} "Melon loaded"
  putword $::flower_ammo 10
  place 1208 928
  after time 1 {shoot_probe before_key get_key_probe}
 }
}
after time 90 {check {0} "Overall timeout"}
'''
(r/'build/deep-shot-test.tcl').write_text(s)
