"""ROM render/interaction fixtures at original spawns, plus keyboard-only entry.
State-controlled render fixtures are separate from natural-input checks.
"""
from pathlib import Path
import os,re,subprocess,sys,json
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0929-bridge-rom' if machine=='C-BIOS_MSX2+' else '0929-bridge-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_TEST_OUTPUT=str(out),KEEN_STAGE='3')
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
syms['WorldInput']=int(re.search(r'([0-9A-F]{8})\s+\d+ _WorldInput:',(r/'src/out/keen_msx_s8_b1.lst').read_text())[1],16)+0x8000
s='\n'.join(f'set {n} {a}' for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set row8 0
set names {}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc actor {i} {expr {$i==7?$::enemy:$::world_map+9600+16*($i<7?$i:$i-1)}}
set spawnx {19 11 45 12 41 26 29 33 26 26 29 29}
set spawny {20 26 37 58 58 55 55 48 55 55 55 55}
proc fixture {} {if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc control {} {
 if {$::phase==0 && [byte $::world_active]==1} {
  putword $::world_x 848;putword $::world_y 848;keys 0;set ::phase 1;after time 1 {keys 1;after time 0.3 {keys 0}}
 } elseif {$::phase==1 && [byte $::world_active]==0 && [byte $::active_level]==3 && [byte $::scene_ready]==165} {
  keys 0;set ::phase 3;debug write memory $::enemy_mode 1;set ::held 1;set ::index 0;set ::pose 0
  next_pose
 }
}
proc next_pose {} {
 if {$::index==12} {
  set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: original eight Bridge enemy spawns; complete Tater/Brocco/Carrot pose sets and flowers, both mouth directions/idle/spit, four hostile seed poses captured in actual ROM.";close $f;exit;return
 }
 set i $::index;set a [actor $i]
 set x [expr {256*[lindex $::spawnx $i]}];set y [expr {256*[lindex $::spawny $i]-($i<5 || $i==7?512:0)+($i<3?15:0)}]
 set ::hx [expr {$x>112*16?$x-80*16:32*16}];set ::hy $y
 set ::frame [expr {$i<3?124+$::pose:($i<5?108+$::pose:($i<7?($i==5?138:136)+$::pose:($i==7?16+$::pose:140+$i-8)))}]
 if {($i<3 && $::pose==12) || ($i>=3 && $i<5 && $::pose==16)} {set ::frame 26}
 putword $a $x;putword [expr {$a+2}] $y;debug write memory [expr {$a+10}] 1
 debug write memory [expr {$a+11}] $::frame;debug write memory [expr {$a+13}] [expr {$::frame==26?1:0}]
 after time 1.2 pose_ready
}
proc pose_ready {} {
 if {[byte $::render_commit]} {after time 0.001 pose_ready;return}
 set slot [expr {$::index==7?1:15+($::index<7?$::index:$::index-1)}]
 set old [expr {$::actors_old+[byte $::front_page]*174+$slot*6}]
 if {![byte [expr {$old+5}]] || [byte [expr {$old+4}]]!=$::frame} {after time 0.01 pose_ready;return}
 set name "actor-$::index-pose-$::pose";snap $name;lappend ::names $name
 incr ::pose;set i $::index
 set limit [expr {$i<3?13:($i<5?17:($i<7?2:($i==7?14:1)))}]
 if {$::pose==$limit} {incr ::index;set ::pose 0}
 next_pose
}
set phase 0
# Leave diagnostics and title with normal keyboard input only.
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n' for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["WorldInput"]&65535} {{[byte $::g_CurrentSegment]==8}} control\n'
s+=f'\ndebug set_bp {syms["ReadInput"]&65535} {{[byte $::g_CurrentSegment]==31}} control\n'
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+='after time 300 {check {0} "Timeout phase=$::phase world=[byte $::world_active] x=[word $::world_x]"}\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=180)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
names=(out/'names.txt').read_text().splitlines()
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
(out/'VERIFIED.txt').write_text(f'PASS: independent full viewport pixel reconstruction for {len(names)} original actor/pose snapshots.\n')
print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
