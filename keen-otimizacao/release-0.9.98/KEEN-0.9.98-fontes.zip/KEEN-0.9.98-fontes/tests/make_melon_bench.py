from pathlib import Path
import sys,re
r=Path(sys.argv[1]);mapping=Path(sys.argv[2]);out=Path(sys.argv[3])
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
d={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mapping.read_text(),re.M)}
for dst,src in [('player_x','stable_x'),('player_y','stable_y'),('grounded','stable_grounded'),('player_frame','stable_frame'),('simulation_ticks','stable_ticks')]:d[dst]=d[src]
for n in ['player_x','player_y','player_vx','player_vy','grounded']:d['raw_'+n]=next(int(a,16)for a,nm in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mapping.read_text(),re.M) if nm==n)
s+='\n'+'\n'.join(f'set {n} {v}'for n,v in d.items())+'\n'
s+=f'set bench_tomato_count {d.get("tomato_count",0)}\n'
s+=r'''
set phase -1
proc motion {} {
 if {$::phase<0 || $::phase>=2} {return}
 set offset [expr {int(([machine_info time]-$::start)*40)%16}]
 if {$offset>8} {set offset [expr {16-$offset}]}
 place $::bx [expr {$::by+$offset}]
 # Isolate render/logic cost from deaths during this synthetic scroll workload.
 debug write memory $::death_ticks 0
 debug write memory $::combat_dirty 1
 after time 0.02 motion
}
proc sample {} {
 if {$::phase>=2} {return}
 set now [machine_info time];set n [word $::render_count]
 if {$n!=$::last_frame} {
  if {$now-$::start>=1} {lappend ::intervals [expr {$now-$::last_time}]}
  set cnt 0;if {$::bench_tomato_count} {set cnt [byte $::bench_tomato_count]}
  set f [open $::env(KEEN_TEST_OUTPUT)/costs.txt a];puts $f "$::phase $cnt [byte $::cost_game] [byte $::cost_actor] [byte $::cost_restore] [byte $::cost_edges]";close $f
  set ::last_frame $n;set ::last_time $now
 }
 after time 0.002 sample
}
proc next_case {} {
 if {$::phase>=0} {
  check {[word $::defeats]==$::start_defeats} "Benchmark must not include deaths"
  set f [open $::env(KEEN_TEST_OUTPUT)/bench.txt a]
  puts $f "$::phase $::intervals";close $f
 }
 incr ::phase
 if {$::phase>=2} {exit;return}
 foreach {::bx ::by} [lindex {{784 64} {1240 192} {1120 1296} {560 1360}} $::phase] {}
 set ::start [machine_info time];set ::last_time $::start;set ::last_frame [word $::render_count];set ::intervals {};set ::start_defeats [word $::defeats]
 if {$::phase==0} {motion;sample}
 after time 6 next_case
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  set f [open $::env(KEEN_TEST_OUTPUT)/bench.txt w];close $f
  next_case
 }
}
'''
out.write_text(s)
