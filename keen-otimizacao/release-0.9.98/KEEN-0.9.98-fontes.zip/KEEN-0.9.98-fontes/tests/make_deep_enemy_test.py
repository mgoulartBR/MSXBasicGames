from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r''' 
proc observe_enemy {} {
 lappend ::positions [word $::enemy]
 if {[llength $::positions]<50} {after time 0.1 observe_enemy;return}
 check {[llength [lsort -unique $::positions]]>4} "Carrot moves through multiple positions in deep mine"
 check {[word [expr {$::enemy+2}]]>8960} "Enemy remains in deep mine"
 check {![byte $::death_ticks]} "Player fixture survives observation"
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
 puts $f "PASS: deep Carrot moves; sampled X positions: $::positions";close $f;exit
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2} "Melon loaded"
  place 680 1392
  set ::positions {}
  after time 1 observe_enemy
 }
}
after time 40 {check {0} "Overall timeout"}
'''
(r/'build/deep-enemy-test.tcl').write_text(s)
