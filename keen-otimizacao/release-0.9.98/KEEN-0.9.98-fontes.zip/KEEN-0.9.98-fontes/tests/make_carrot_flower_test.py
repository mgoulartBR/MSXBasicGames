from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc flowered {} {
 check {[byte [expr {$::enemy+13}]]==1} {Carrot becomes flower}
 after time 0.8 {
  check {[byte [expr {$::world_collision+1131+[byte $::front_page]}]]==1} {Flower rendered in hardware}
  snap flower
 }
 waitfor {[word $::flower_returns]>$::old_returns} recovered
}
proc recovered {} {
 check {[byte [expr {$::enemy+13}]]==0} {Carrot recovers}
 after time 0.4 {
  snap recovered
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
  puts $f {PASS: projectile contact triggers flower, flower remains hardware, timer restores Carrot; controlled projectile and player positions.}
  close $f;exit
 }
}
after time 10 {
 check {[byte $::active_level]==1} {First stage loaded}
 place 1824 448
 putword $::enemy 27648;putword [expr {$::enemy+2}] 7424
 debug write memory [expr {$::enemy+10}] 1
 debug write memory [expr {$::enemy+13}] 0
 set a $::shots
 putword $a 27776;putword [expr {$a+2}] 7552
 putword [expr {$a+4}] 0;putword [expr {$a+6}] 0
 debug write memory [expr {$a+10}] 1;debug write memory [expr {$a+13}] 0
 set ::old_hits [word $::flower_hits];set ::old_returns [word $::flower_returns]
 waitfor {[word $::flower_hits]>$::old_hits} flowered
}
after time 40 {check {0} {Overall timeout}}
'''
(r/'build/carrot-flower-test.tcl').write_text(s)
