from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc keytap {row mask} {
 if {$row==0} {set target [dict get {2 0 4 1 8 2 16 3} $mask];set address $::enemy_mode} else {set target [expr {([byte $::hud_debug]+1)&3}];set address $::hud_debug}
 keymatrixdown $row $mask
 waitfor [format {[byte %d]==%d} $address $target] [list keymatrixup $row $mask]
}
proc hold_player {} {
 if {!$::hold} {return}
 place 1240 192
 after time 0.03 hold_player
}
proc enemy_coords {} {
 set list {}
 for {set i 0} {$i<6} {incr i} {
  set t [expr {$::world_collision+1026+$i*13}]
  lappend list [word $t] [word [expr {$t+2}]] [byte [expr {$t+9}]]
 }
 return $list
}
proc visible_enemies {} {
 set n 0
 for {set i 20} {$i<29} {incr i} {incr n [byte [expr {$::actors_old+[byte $::front_page]*174+$i*6+5}]]}
 return $n
}
proc freeze_test {} {
 check {[byte $::tomato_count]>=2} "Near enemies selected"
 snap mode1
 keytap 0 4
 after time 1.2 {
  check {[byte $::enemy_mode]==1} "Key 2 freezes enemy logic"
  # Freeze a reproducible visible group, independent of earlier pursuit speed.
  foreach {i x} {0 1200 1 1280 2 1320} {
   set t [expr {$::world_collision+1026+$i*13}]
   putword $t [expr {$x*16}];putword [expr {$t+2}] 3520
  }
  set ::frozen [enemy_coords];set ::frames [word $::render_count]
  after time 1 {
   check {[enemy_coords] eq $::frozen} "Enemy position and animation frozen"
   check {[word $::render_count]>$::frames+1} "Frozen scene continues presenting frames"
   check {[visible_enemies]>0} "Frozen enemies still drawn"
   snap mode2
   set f [open $::env(KEEN_TEST_OUTPUT)/frozen-frames.txt w];puts $f [expr {[word $::render_count]-$::frames}];close $f
   keytap 0 8
   after time 1.2 {
    set ::moving [enemy_coords]
    after time 1 {
     check {[byte $::enemy_mode]==2 && [enemy_coords] ne $::moving} "Key 3 keeps logic moving"
     check {[visible_enemies]==0} "Key 3 hides enemies"
     snap mode3
     keytap 0 16
     after time 1.2 {
      set ::frozen [enemy_coords];set ::frames [word $::render_count]
      after time 1 {
       check {[byte $::enemy_mode]==3 && [enemy_coords] eq $::frozen} "Key 4 disables both"
       check {[visible_enemies]==0 && [word $::render_count]>$::frames+1} "Mode 4 is comparable"
       snap mode4
       keytap 3 8
       after time 2 timing_test
      }
     }
    }
   }
  }
 }
}
proc timing_test {} {
 check {[byte $::hud_debug]==2} "F opens L/R/D timing panel"
 check {[word $::diag_ms]+[word [expr {$::diag_ms+2}]]+[word [expr {$::diag_ms+4}]]>0} "Measured phase averages are nonzero"
 snap timings
 set f [open $::env(KEEN_TEST_OUTPUT)/measurements.txt w]
 puts $f "L=[word $::diag_ms] R=[word [expr {$::diag_ms+2}]] D=[word [expr {$::diag_ms+4}]] cpu=[byte $::cpu_mode]"
 close $f
 keytap 3 8
 after time 1.2 {
  check {[byte $::hud_debug]==3} "CPU/active/visible panel"
  snap counters
  keytap 3 8
  after time 1.2 {
   check {[byte $::hud_debug]==0} "Inventory page retained"
   snap inventory
   keytap 3 8;keytap 0 2
   after time 1.2 {
    check {[byte $::hud_debug]==1 && [byte $::enemy_mode]==0} "Return to normal mode and FPS"
    set ::moving [enemy_coords]
    after time 1.2 {
     check {[enemy_coords] ne $::moving} "Normal enemy movement restored"
     set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
     puts $f "PASS: four comparison modes, continuous frozen presentations, timing averages, CPU/count and inventory panels, restoration of normal mode. Player position fixture only."
     close $f;exit
    }
   }
  }
 }
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2 && [byte $::hud_debug]==1} "Melon with diagnostic FPS panel"
  set ::hold 1;hold_player
  after time 2 freeze_test
 }
}
after time 60 {check {0} "Overall timeout"}
'''
(r/'build/diag-test.tcl').write_text(s)
