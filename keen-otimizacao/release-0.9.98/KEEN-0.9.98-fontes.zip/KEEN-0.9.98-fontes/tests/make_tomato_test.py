from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc hold_player {} {
 if {!$::hold} {return}
 place 1200 160
 after time 0.03 hold_player
}
proc moving {} {
 set t [expr {$::world_collision+1026}]
 lappend ::xs [word $t];lappend ::ys [word [expr {$t+2}]]
 if {[llength $::xs]<30} {after time 0.1 moving;return}
 check {[llength [lsort -unique $::xs]]>4 && [llength [lsort -unique $::ys]]>4} "Tomatooth pursues and bounces"
 check {[byte $::tomato_count]>0} "Near list wakes enemies"
 snap moving
 # Controlled projectile fixture on the enemy; collision and flower lifecycle run in ROM.
 putword $::shots [word $t];putword [expr {$::shots+2}] [word [expr {$t+2}]]
 putword [expr {$::shots+4}] 0;putword [expr {$::shots+6}] 0
 putword [expr {$::shots+8}] 140
 debug write memory [expr {$::shots+10}] 1;debug write memory [expr {$::shots+13}] 0
 set ::old_hits [word $::flower_hits];set ::old_returns [word $::flower_returns]
 waitfor {[word $::flower_hits]>$::old_hits} flowering
}
proc flowering {} {
 check {[byte [expr {$::world_collision+1026+11}]]==1} "Tomatooth is a flower"
 after time 0.5 {snap flower}
 waitfor {[word $::flower_returns]>$::old_returns} restored
}
proc restored {} {
 check {[byte [expr {$::world_collision+1026+11}]]==0} "Tomatooth recovers"
 set ::hold 0
 set t [expr {$::world_collision+1026}]
 place [expr {[word $t]/16}] [expr {[word [expr {$t+2}]]/16}]
 waitfor {[byte $::death_ticks]>0} collided
}
proc collided {} {
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
 puts $f "PASS: original six spawns, distant sleep, nearby movement/bounce, Flower Power contact, timed recovery and player collision. Player/projectile positioning fixtures."
 close $f;exit
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2} "Melon loaded"
  check {[byte $::tomato_count]==0} "No distant enemy physics at entrance"
  set i 0
  foreach {x y} {68 18 75 21 80 21 35 85 58 89 74 89} {
   set t [expr {$::world_collision+1026+$i*13}]
   check {[word $t]==$x*256 && [word [expr {$t+2}]]==($y-1)*256} "Original spawn $i"
   incr i
  }
  set ::hold 1;hold_player;set ::xs {};set ::ys {}
  after time 1 moving
 }
}
after time 60 {check {0} "Overall timeout"}
'''
(r/'build/tomato-test.tcl').write_text(s)
