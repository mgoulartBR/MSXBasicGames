from pathlib import Path
import sys,re,json
r=Path(sys.argv[1]);s=(r/'build/world-test.tcl').read_text().split('after time 10 {')[0]
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
s+=f'\nset raw_grounded {syms["grounded"]}\n'
meta=json.loads((r/'assets/tuberia/manifest.json').read_text());node=next(i for i,level in meta['nodes'] if level==2);x=node%85*16;y=node//85*16
s+=f'\nset melon_entry_x {x}\nset melon_entry_y {y}\n'
s+=r'''
proc exit_stage {width} {
 putword $::raw_player_x [expr {($width-2)*256-320}];putword $::raw_player_y [expr {480*16}]
 putword $::raw_player_vx 24;putword $::raw_player_vy 0;debug write memory $::raw_grounded 1
 keymatrixdown 8 128
}
proc enter_melon {} {
 if {[byte $::world_draw_busy]} {after time 0.001 enter_melon;return}
 putword $::world_x $::melon_entry_x;putword $::world_y $::melon_entry_y
 keymatrixdown 8 1
}
proc collect_last_melon_pickup {} {
 set address [expr {$::world_collision+876+24*6}]
 putword $::raw_player_x [expr {[word $address]*16-64}]
 putword $::raw_player_y [expr {[word [expr {$address+2}]]*16-160}]
 putword $::raw_player_vx 0;putword $::raw_player_vy 0
 debug write memory $::raw_grounded 0;debug write memory $::combat_dirty 1
}
proc place_melon_deep {} {
 # Wait for a completed frame, then let the regular jump input trigger a redraw.
 if {[byte $::render_commit]} {after time 0.001 place_melon_deep;return}
 putword $::raw_player_x [expr {27*256}];putword $::raw_player_y [expr {84*256}]
 putword $::raw_player_vx 0;putword $::raw_player_vy 0
 debug write memory $::raw_grounded 1;debug write memory $::combat_dirty 1
 keymatrixdown 8 1
}
after time 10 {
 check {[byte $world_active]==1} "Start in Tuberia"
 keymatrixdown 8 16
 after time 0.6 {keymatrixup 8 16;keymatrixdown 8 1}
 after time 0.9 {keymatrixup 8 1}
 after time 4 {
  check {![byte $world_active] && [byte $active_level]==1} "First level selected"
  snap hh_spawn;putword $flower_ammo 6;exit_stage 136
 }
 after time 6 {keymatrixup 8 128;check {[byte $level_done]==2} "HH complete";keymatrixdown 8 1}
 after time 6.3 {keymatrixup 8 1}
 after time 10 {
  check {[byte $world_active]==1 && [byte $world_completed]==1} "Only HH flag set"
  check {[word $flower_ammo]==6} "Stock retained after HH"
  world_snap hh_done
  after time 0.2 enter_melon
 }
 after time 10.7 {keymatrixup 8 1}
 after time 14 {
  check {![byte $world_active] && [byte $active_level]==2} "Melon selected from its own node"
  check {[byte [expr {$world_collision+1120}]]==94 && [byte [expr {$world_collision+1121}]]==93} "Full Melon dimensions"
  check {[word $flower_ammo]==6} "Stock carried into second level"
  snap melon_spawn
  set f [open $::env(KEEN_TEST_OUTPUT)/melon-map.bin wb];puts -nonewline $f [debug read_block memory $world_map 9835];close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/melon-data.bin wb];puts -nonewline $f [debug read_block memory $world_collision 1168];close $f
  after time 0.2 collect_last_melon_pickup
 }
 after time 14.9 {
  check {([byte [expr {$pickup_taken+3}]]&1)!=0 && [word $flower_ammo]>6} "Collect original pickup 25 with a 32-bit flag"
  snap melon_pickup
  after time 0.1 place_melon_deep
 }
 after time 15.4 {keymatrixup 8 1}
 after time 17 {
  check {[word $player_y]>37*256} "Explore below HH height limit"
  check {[byte [expr {$enemy+10}]]==1} "Original Carrot Courier activated in deep mine"
  snap melon_deep
  set carried_stock [word $flower_ammo]
  putword $raw_player_x [expr {23*256}]
  putword $raw_player_y [expr {78*256-510}]
  putword $raw_player_vx 0;putword $raw_player_vy 0
  debug write memory $raw_grounded 0;debug write memory $combat_dirty 1
 }
 after time 17.4 {check {[byte $death_ticks]>0} "Original deadly floor kills Keen"}
 after time 18.7 {
  check {![byte $death_ticks] && [word $player_y]<20*256} "Respawn stays in Melon"
  exit_stage 94
 }
 after time 21 {keymatrixup 8 128;check {[byte $level_done]==2} "Melon exit uses its width";keymatrixdown 8 1}
 after time 21.3 {keymatrixup 8 1}
 after time 25 {
  check {[byte $world_active]==1 && [byte $world_completed]==3} "Both completion flags retained"
  check {[word $flower_ammo]==$carried_stock} "Remaining stock retained after Melon"
  check {[word $world_x]==$melon_entry_x && [word $world_y]==$melon_entry_y} "Return at Melon entrance"
  world_snap both_done
  keymatrixdown 8 1
 }
 after time 25.3 {keymatrixup 8 1}
 after time 26 {check {[byte $world_active]==1} "Completed Melon locked";keymatrixdown 4 8}
 after time 26.3 {keymatrixup 4 8}
 after time 29 {
  check {[byte $world_completed]==0 && [word $flower_ammo]==0} "New game clears both flags and stock"
  world_snap reset_world
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS HH to Melon via Tuberia; full 94x93 map, deep camera, Carrot Courier, pickup 25, deadly floor and respawn, per-stage completion, stock carry, return position, reentry lock, new game.";close $f;exit
 }
}
'''
(r/'build/two-stage-test.tcl').write_text(s)
