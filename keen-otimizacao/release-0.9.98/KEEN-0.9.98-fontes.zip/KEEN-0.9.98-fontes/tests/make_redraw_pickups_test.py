from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc hold_player {} {place $::hx $::hy;after time 0.03 hold_player}
after time 0.1 enter_first_level
after time 10 {
 check {[byte $::active_level]==1} "First stage loaded"
 set ::px [word [expr {$::pickups+30}]];set ::py [word [expr {$::pickups+32}]]
 set ::hx [expr {$::px-48}];set ::hy [expr {$::py-8}];hold_player
 after time 2 {
  snap nearby
  after time 2 {
   snap retained
   set ::before [word $::pickups_collected]
   set ::hx [expr {$::px-4}]
   waitfor {[word $::pickups_collected]>$::before} {
    after time 2 {
     snap collected
     set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
     puts $f "PASS: nearby stationary pickups, repeated pages and collection removal with normal enemy mode. Player position fixture."
     close $f;exit
    }
   }
  }
 }
}
after time 40 {check {0} "Timeout"}
'''
(r/'build/redraw-pickups-test.tcl').write_text(s)
