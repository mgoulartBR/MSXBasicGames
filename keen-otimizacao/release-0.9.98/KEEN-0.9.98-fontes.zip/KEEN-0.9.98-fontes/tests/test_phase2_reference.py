"""Repeatable HH-A scene; C-BIOS validation, not a Turbo-R timing surrogate."""
from pathlib import Path
import os,re,subprocess,json
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
for name,freq in [('z80',3579545),('fast',10000000)]:
 out=r/'build'/('0911-p1-'+name);out.mkdir(exist_ok=True)
 fields=['bench_status','bench_hz','bench_cpu','bench_frames','bench_elapsed','bench_shortest','bench_longest','bench_avg10','bench_min10','bench_max10','bench_scroll_x','bench_scroll_y','simulation_ticks','shots_fired','flower_hits','player_x','player_y']
 report='\n'.join(f'puts $f "{n} [{'debug read memory' if n in fields[:3] else 'word'} {s[n]}]"' for n in fields)
 t=f'''set throttle off
set save_settings_on_exit false
set z80_freq {freq}
set z80_freq_locked false
proc word {{a}} {{expr {{[debug read memory $a]+256*[debug read memory [expr {{$a+1}}]]}}}}
after time 10 {{keymatrixdown 2 128;after time 0.3 {{keymatrixup 2 128}}}}
after time 13 {{keymatrixdown 8 1;after time 0.3 {{keymatrixup 8 1}}}}
after time 18 {{
 screenshot {{{out/'scene.png'}}}
 set f [open {{{out/'scene.vram'}}} wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f
 set f [open {{{out/'scene.regs'}}} wb];puts -nonewline $f [debug read_block {{VDP regs}} 0 64];close $f
}}
after time 35 {{
 set f [open {{{out/'result.txt'}}} w]
 puts $f "actual_clock [machine_info z80_freq]"
 puts $f "done [debug read memory {s['bench_done']}]"
 {report}
 close $f
 screenshot {{{out/'result.png'}}}
 set f [open {{{out/'result.vram'}}} wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f
 exit
}}
'''
 (out/'test.tcl').write_text(t)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],stdout=log,stderr=log,timeout=60,check=True)
 result=dict(line.split() for line in (out/'result.txt').read_text().splitlines());print(name,result,flush=True)
 assert abs(int(result['actual_clock'])-freq)<freq/100
 assert result['done']=='1'
 assert result['bench_status']=='0'
 assert result['simulation_ticks']=='700'
