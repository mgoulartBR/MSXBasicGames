"""Original tenth map, full object roster, previous binary identity and cache bounds."""
from pathlib import Path
from zipfile import ZipFile
import json,struct,re,hashlib
r=Path(__file__).resolve().parents[1];maps=json.loads((r/'assets/generated/maps.json').read_text());rows=[]
for level in (1,2,3,4,5,7,9,10,12,14):
 m=next(x for x in maps if x['id']==level);bs=[(i%m['width'],i//m['width'])for i,v in enumerate(m['planes'][2])if 21<=v<=28]
 peak=max(sum(-1<=bx-x<=2 and -2<=by-y<=3 for bx,by in bs)for x in range(m['width'])for y in range(m['height']));assert peak<=8;rows.append((level,len(bs),peak))
m=next(x for x in maps if x['id']==14);keys=sorted(set(zip(*m['planes'][:2])));raw=(r/'assets/swamp/map.bin').read_bytes()
assert [keys[i]for i in struct.unpack('<2146H',raw)]==list(zip(*m['planes'][:2]))
spawns=re.findall(r'\{(\d+),(\d+),(\d+)\}',(r/'src/swamp_spawns.h').read_text())
assert sorted((int(y)*74+int(x),int(v))for x,y,v in spawns)==sorted((i,v)for i,v in enumerate(m['planes'][2])if v in (31,41,45,57))
with ZipFile(r.parent/'deliverables/v0.9.35/keen-dreams-msx-0.9.35-rom-source.zip')as z:
 count=0
 for level in ('scene','melon','bridge','rapids','pass','city','apple','grove','bay'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p;count+=1
assert hashlib.sha256((r.parent/'deliverables/v0.9.35/KEEN0935.ROM').read_bytes()).hexdigest()=='4a1fdeca1d0e6d4d7b59b0f7cb039af3f8b3eee6942a0dd73a94e325720144bc'
world=json.loads((r/'assets/tuberia/manifest.json').read_text());assert any(n[1]==10 for n in world['nodes']);assert any(p[3]==512 for p in world['patches']);assert world['unique_bitmaps']<=544
assert "opaque_sprites[10][166]" in (r/"src/opaque_sprites.h").read_text(), "Ten renderer mask tables"
print('PASS: 2146 original background/foreground cells; six original actors and three bombs; baseline 0.9.35 preserved; %d unchanged previous-stage binaries; tenth Tuberia portal and completion flag 512; bonus cache census %s.'%(count,rows))
