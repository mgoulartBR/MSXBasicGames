from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];out=r/'build/0911-bankzero';out.mkdir(exist_ok=True)
b=bytearray((r/'build/keen_msx.rom').read_bytes());expected=b[0x200];b[0x200]^=1
(out/'fault.rom').write_bytes(b)
(out/'expected.txt').write_text(f'Injected offset 0200: expected {expected:02X}, mapped/fixed {b[0x200]:02X}; expected FAIL 00 COUNT 01.\n')
t=f'''set throttle off
set save_settings_on_exit false
after time 15 {{screenshot {{{out/'boot.png'}}};exit}}
''';(out/'test.tcl').write_text(t)
with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(out/'fault.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],stdout=log,stderr=log,timeout=30,check=True)
print((out/'expected.txt').read_text())
