"""Compile actual old/new camera routines and compare their output exhaustively per axis."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
baseline=root/'build/optimization-05-baseline/src/main.c'
def routine(path):
 s=path.read_text();return s[s.index('static void FollowCamera'):s.index('static u8 ReadInput')]
old=routine(baseline).replace('FollowCamera','Reference')
new=routine(root/'src/main.c')
source='''#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef uint8_t u8;typedef uint16_t u16;typedef int16_t i16;
#define MAP_WIDTH 136
#define MAP_HEIGHT 37
u8 hardware_scroll,camera_x,camera_y;
u16 player_x,player_y,camera_px,camera_py;
'''+old+new+r'''
void check(unsigned x,unsigned y,unsigned cx,unsigned cy){
 unsigned a,b,c,d;
 player_x=x*16;player_y=y*16;camera_px=cx;camera_py=cy;camera_y=cy/16;
 Reference();a=camera_px;b=camera_py;c=camera_x;d=camera_y;
 camera_px=cx;camera_py=cy;camera_y=cy/16;FollowCamera();
 if(a!=camera_px||b!=camera_py||c!=camera_x||d!=camera_y){
  printf("FAIL hw=%u player=%u,%u cam=%u,%u old=%u,%u new=%u,%u\n",hardware_scroll,x,y,cx,cy,a,b,camera_px,camera_py);exit(1);
 }
}
int main(void){unsigned x,y,c;
 for(hardware_scroll=0;hardware_scroll<2;++hardware_scroll){
  for(c=32;c<=1888;c+=hardware_scroll?2:8)for(x=0;x<2176;++x)check(x,400,c,320);
  for(c=32;c<=(hardware_scroll?368:384);c+=hardware_scroll?1:16)for(y=0;y<592;++y)check(500,y,400,c);
 }
 puts("PASS: actual C camera routines equivalent across all map pixel positions and legal camera positions, each axis, MSX2/MSX2+.");
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'camera.c').write_text(source)
 subprocess.run(['cc','-O2',str(p/'camera.c'),'-o',str(p/'camera')],check=True)
 subprocess.run([str(p/'camera')],check=True)
