from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/world-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
set scroll_count 0
set capture_paused 0
set scroll_times {}
set guard_checks 0
proc guard_start {} {
 set ::guard_page [expr {([debug read {VDP regs} 2]>>5)&1}]
 set ::guard_image [debug read_block VRAM [expr {$::guard_page*32768}] 32768]
 after time 0.001 guard_check
}
proc guard_check {} {
 if {![byte $::world_draw_busy]} {return}
 set page [expr {([debug read {VDP regs} 2]>>5)&1}]
 if {$page!=$::guard_page} {return}
 check {[debug read_block VRAM [expr {$page*32768}] 32768] eq $::guard_image} "Visible page changed while drawing the next frame"
 incr ::guard_checks
 after time 0.001 guard_check
}
proc scroll_capture {} {
 if {$::capture_paused || [byte $::world_draw_busy] || ![byte $::world_active]} {return}
 check {([debug read {VDP status regs} 2]&64)!=0} "Frame committed outside vertical blank"
 incr ::scroll_count
 world_snap scroll$::scroll_count
 lappend ::scroll_times [machine_info time]
}
proc scroll_place {x y keys} {
 if {[byte $::world_draw_busy]} {after time 0.001 [list scroll_place $x $y $keys];return}
 set ::capture_paused 1
 putword $::world_x $x;putword $::world_y $y;keymatrixdown 8 $keys
}
after time 10 {
 debug set_watchpoint write_mem $world_draw_busy {} {if {$::wp_last_value==0} {after time 0.0001 scroll_capture} else {set ::capture_paused 0;after time 0.00001 guard_start}}
 keymatrixdown 8 16
 after time 0.8 {keymatrixup 8 16;keymatrixdown 8 128}
 after time 1.6 {keymatrixup 8 128;keymatrixdown 8 32}
 after time 2.4 {keymatrixup 8 32;keymatrixdown 8 64}
 after time 3.2 {keymatrixup 8 64;keymatrixdown 8 48}
 after time 4.0 {keymatrixup 8 48;keymatrixdown 8 192}
 after time 4.8 {keymatrixup 8 192}
 after time 5.1 {scroll_place 767 767 128}
 after time 5.6 {keymatrixup 8 128;scroll_place 1023 511 64}
 after time 6.1 {keymatrixup 8 64}
 after time 6.6 {
  check {$guard_checks>=100} "Visible-page guard exercised"
  check {$scroll_count>=20} "Scroll rendered enough frames"
  set f [open $::env(KEEN_TEST_OUTPUT)/timing.txt w];puts $f $scroll_times;close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS $scroll_count presented world frames, horizontal/vertical/diagonal input; $guard_checks checks with displayed VRAM unchanged during rendering.";close $f;exit
 }
}
'''
(r/'build/world-scroll-test.tcl').write_text(s)
