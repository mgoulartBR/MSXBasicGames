from pathlib import Path
import re,sys
r=Path(sys.argv[1]);out=Path(sys.argv[2]);mp=(r/'build/keen_msx.map').read_text();syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp,re.M)}
s=(r/'build/campaign3.tcl').read_text().split('after time 10 {')[0]
s=s.replace('  putword $::player_vx 0;putword $::player_vy 0','  putword $::player_vx 0;putword $::player_vy 0\n  debug write memory $::climbing 1')
s+=r'''
proc target {x y} {set ::bx $x;set ::by $y;set ::fixture_on 1}
proc ammo_one {} {
 check {[word $::flower_ammo]==1 && [long $::game_score]==0} "+1 seed collected once, no points"
 target 928 56
 after time 1 ammo_five
}
proc ammo_five {} {
 check {[word $::flower_ammo]==6 && [byte $::game_lives]==3} "+5 bundle collected once"
 target 464 896
 after time 1 life
}
proc life {} {
 puts stderr "life=[byte $::game_lives] ammo=[word $::flower_ammo] score=[long $::game_score] bonus=[long $::bonus_taken] pickups=[long $::pickup_taken]"
 check {[byte $::game_lives]==4 && [word $::flower_ammo]==6 && [long $::game_score]==0} "Original 1UP collected once"
 set ::fixture_on 0;debug write memory $::climbing 0
 # Fresh fire press after collecting all item types must still work.
 keymatrixdown 3 1
 after time 0.3 {keymatrixup 3 1}
 after time 0.5 fired
}
proc fired {} {
 check {[word $::shots_fired]>0 && [word $::flower_ammo]==5} "Throw after collecting seed, bundle and 1UP"
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: original +1, +5 and 1UP positions; no duplicate awards; firing after collection";close $f;exit
}
after time 10 {
 putword $::world_x 848;putword $::world_y 848
 keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==3 && [byte $::scene_ready]==165} "Bridge loaded"
  target 480 176
  after time 1 ammo_one
 }
}
after time 30 {check {0} "Timeout"}
'''
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
out.write_text(s)
