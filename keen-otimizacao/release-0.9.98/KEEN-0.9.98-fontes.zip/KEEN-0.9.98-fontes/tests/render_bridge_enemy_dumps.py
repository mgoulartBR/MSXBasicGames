"""Decode bitmap VRAM evidence (hardware Keen is a separate sprite layer)."""
from pathlib import Path
from PIL import Image
import sys
p=Path(sys.argv[1])
pal=[(0,0,0),(0,0,182),(0,182,0),(0,182,182),(182,0,0),(182,0,182),(182,73,0),(182,182,182),(73,73,73),(73,73,255),(73,255,73),(73,255,255),(255,73,73),(255,73,255),(255,255,73),(255,255,255)]
for name in ('tater','flower','melons'):
 cx,cy,page,hw=map(int,(p/f'{name}.txt').read_text().split());v=(p/f'{name}.vram').read_bytes();h=192 if hw else 176
 pix=[]
 for y in range(h):
  for x in range(256):
   xx=(cx+x)&255 if hw else x;yy=page*256+((cy+y)&255 if hw else y+16)
   pix.append(pal[(v[yy*128+xx//2]>>(0 if xx&1 else 4))&15])
 im=Image.new('RGB',(256,h));im.putdata(pix);im.resize((768,h*3),Image.Resampling.NEAREST).save(p/f'{name}.png')
