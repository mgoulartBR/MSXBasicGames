from pathlib import Path
import sys,re
root=Path(sys.argv[1]);symbols={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+(?:main|game|keen_msx_s7_b1|keen_msx_s8_b1|keen_msx_s14_b1|keen_msx_s81_b1|keen_msx_s15_b1|world|actors|hud|pickups|cpu)\s*$',(root/'build/keen_msx.map').read_text(),re.M)}
all_symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (root/'build/keen_msx.map').read_text(),re.M)}
symbols.update({n:all_symbols[n] for n in ('game_score','game_lives')})
symbols['pickups']=symbols['world_collision']+876
for dst,src in [('player_x','stable_x'),('player_y','stable_y'),('grounded','stable_grounded'),('player_frame','stable_frame'),('simulation_ticks','stable_ticks')]: symbols[dst]=symbols[src]
header='\n'.join(f'set {n} {a}'for n,a in symbols.items())
body=r'''
set throttle on
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {a} {return [debug read memory $a]}
proc word {a} {return [expr {[byte $a]+256*[byte [expr {$a+1}]]}]}
proc check {condition msg} {
 if {![uplevel 1 [list expr $condition]]} {
  set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;puts $f "x=[word $::player_x] y=[word $::player_y] vy=[word $::player_vy] ground=[byte $::grounded] ticks=[word $::simulation_ticks] frame=[byte $::player_frame]";close $f;exit;error $msg
 }
}
proc snap {name} {
 if {[byte $::render_commit]} {after time 0.001 [list snap $name];return}
 global drawn_x drawn_y drawn_frame drawn_cx drawn_cy drawn_camera_px front_page simulation_ticks hardware_scroll drawn_camera_py
 screenshot -raw $::env(KEEN_TEST_OUTPUT)/$name.png
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.vram wb]
 puts -nonewline $f [debug read_block VRAM [expr {[byte $front_page]*32768} ] 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/$name.txt w]
 puts $f "[word $drawn_x] [word $drawn_y] [byte $drawn_frame] [byte $drawn_cx] [byte $drawn_cy] [word $simulation_ticks] [word $drawn_camera_px] [byte $hardware_scroll] [word $drawn_camera_py] [word [expr {$::hud_ammo+2*[byte $front_page]}]] [byte [expr {$::hud_keys+[byte $front_page]}]] [word $::game_score] [word [expr {$::game_score+2}]] [byte $::game_lives]"
 for {set i 0} {$i<29} {incr i} {
  set a [expr {$::actors_old+[byte $front_page]*174+$i*6}]
  puts $f "[word $a] [word [expr {$a+2}]] [byte [expr {$a+4}]] [byte [expr {$a+5}]]"
 };close $f
}
proc probe_jump {} {
 global min_y player_y
 set y [word $player_y]
 if {$y<$min_y} {set min_y $y}
}
proc sample_jump {n} {
 probe_jump
 if {$n>0} {after time 0.02 [list sample_jump [expr {$n-1}]]}
}
# Enter Horseradish Hill through Tuberia for legacy level regression tests.
proc enter_first_level {} {
 if {[byte $::world_active]!=1} {after time 0.1 enter_first_level;return}
 keymatrixdown 8 16
 after time 0.6 {keymatrixup 8 16;keymatrixdown 8 1}
 after time 0.9 {keymatrixup 8 1}
}
if {![info exists ::env(KEEN_WORLD_TEST)]} {after time 0.1 enter_first_level}
after time 10 {
 check {[byte $scene_ready]==165} "Boot"
 check {[byte $grounded]==1} "Initial landing"
 set start_x [word $player_x];set start_y [word $player_y]
 snap spawn
 set min_y $start_y
 keymatrixdown 8 1
 sample_jump 70
 after time 0.07 {
  keymatrixup 8 1
  after time 1.5 {
   set short_min $min_y
   check {$short_min<$start_y-200} "Short jump height"
   check {[byte $grounded]==1} "Short jump landing"
   set min_y $start_y
   keymatrixdown 8 1
   sample_jump 90
   after time 0.35 {snap jump}
   after time 0.6 {keymatrixup 8 1}
   after time 2 {
    set long_min $min_y
    check {$long_min<$short_min-200} "Variable jump height"
    check {[byte $grounded]==1} "Long jump landing"
    check {[word $player_y]==$start_y} "Flat floor stability"
    # Isolate movement from enemy damage; combat has its own test.
    debug write memory [expr {$::enemy+10}] 1
    debug write memory [expr {$::enemy+13}] 1
    debug write memory [expr {$::enemy+8}] 94
    debug write memory [expr {$::enemy+9}] 1
    keymatrixdown 8 16
    after time 2.2 {
     keymatrixup 8 16
     after time 0.3 {
      check {[word $player_x]<$start_x-1000} "Walk left"
      check {[byte $camera_x]<118} "Camera follow"
      check {[word $slope_hits]>0} "Slope contacts"
      snap walk
      set left_x [word $player_x]
      keymatrixdown 8 128
      after time 0.4 {
       check {[word $player_x]>$left_x} "Walk right"
       check {[byte $player_frame]<8} "Face right"
       snap right
       keymatrixup 8 128
       keymatrixdown 4 128
       after time 0.2 {
        keymatrixup 4 128
        after time 0.4 {
         check {[word $player_x]==$start_x && [word $player_y]==$start_y} "Restart"
         check {[byte $grounded]==1} "Restart landing"
         set f [open $env(KEEN_TEST_OUTPUT)/PASS.txt w]
         puts $f "PASS: boot, variable jump, landing, left/right, camera, slopes, restart."
         puts $f "short_min=$short_min long_min=$long_min start_y=$start_y ticks=[word $simulation_ticks] slopes=[word $slope_hits] walls=[word $wall_hits] ceilings=[word $ceiling_hits]"
         close $f
         exit
        }
       }
      }
     }
    }
   }
  }
 }
}
'''
(root/'build/game-test.tcl').write_text(header+'\n'+body)
