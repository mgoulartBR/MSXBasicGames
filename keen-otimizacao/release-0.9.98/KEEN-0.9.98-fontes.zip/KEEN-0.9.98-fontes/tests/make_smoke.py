"""Generate assertions using current linker symbols, never hardcoded RAM addresses."""
import pathlib,re,sys
root=pathlib.Path(sys.argv[1])
mapfile = root/'src/out/keen_sandbox.map'
if not mapfile.exists():
    mapfile = root/'build/keen_sandbox.map'
symbols={name:int(addr,16) for addr,name in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+main\s*$',mapfile.read_text(),re.M)}
header='\n'.join(f'set {n} {symbols[n]}' for n in ('sandbox_ready','sandbox_frames','player_x','player_y_q4'))
body=r'''
set throttle on
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {addr} { return [debug read memory $addr] }
proc word {addr} { return [expr {[byte $addr] + 256 * [byte [expr {$addr+1}]]}] }
proc check {condition message} {
    if {![uplevel 1 [list expr $condition]]} {
        puts stderr "FAIL: $message"
        exit
        error $message
    }
}
after time 10 {

    check {[byte $sandbox_ready] == 165} "ROM did not initialize"
    check {[word $sandbox_frames] > 20} "VBlank counter did not advance"
    check {[byte $player_x] == 120} "Initial X"
    check {[word $player_y_q4] == 2560} "Initial Y"
    screenshot -raw $env(KEEN_TEST_OUTPUT)/boot.png
    keymatrixdown 8 128
    after time 0.3 {
        keymatrixup 8 128
        check {[byte $player_x] > 120} "Right input did not move player"
        set moved_x [byte $player_x]
        keymatrixdown 8 16
        after time 0.2 {
            keymatrixup 8 16
            check {[byte $player_x] < $moved_x} "Left input did not move player"
            keymatrixdown 8 1
            after time 0.15 {
                keymatrixup 8 1
                check {[word $player_y_q4] < 2560} "Space did not trigger jump"
                screenshot -raw $env(KEEN_TEST_OUTPUT)/jump.png
                after time 1.5 {
                    check {[word $player_y_q4] == 2560} "Player did not land"
                    set f [open $env(KEEN_TEST_OUTPUT)/PASS.txt w]
                    puts $f "PASS: boot, VBlank, right, left, jump, landing."
                    puts $f "Ready=[byte $sandbox_ready]; frames=[word $sandbox_frames]; x=[byte $player_x]; y_q4=[word $player_y_q4]"
                    close $f
                    exit
                }
            }
        }
    }
}
'''
(root/'build/smoke.tcl').write_text(header+'\n'+body)
