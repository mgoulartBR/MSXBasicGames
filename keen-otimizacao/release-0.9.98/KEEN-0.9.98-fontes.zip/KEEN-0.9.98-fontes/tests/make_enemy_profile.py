"""Emulated-time service measurements, plus the four ROM keyboard modes."""
from pathlib import Path
import re,sys
m=Path(sys.argv[1]);out=Path(sys.argv[2]);d={n:int(a,16)for a,n in re.findall(r'([0-9A-F]{8})\s+_(\w+)',m.read_text())}
s='\n'.join(f'set {n} {d[n]}' for n in ['enemy_probe','enemy_mode','render_count','simulation_ticks','enemy','player_x','player_y','pickup_taken','defeats','game_fps'])
s+=r'''
set throttle off
set save_settings_on_exit false
set measuring 0
set starts [dict create]
set totals {0.0 0.0 0.0}
set calls {0 0 0}
proc word {a} {expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc mark {i} {
 if {!$::measuring} {return}
 set k [expr {$i/2}];set t [machine_info time]
 if {!($i&1)} {dict set ::starts $k $t} elseif {[dict exists $::starts $k]} {
  lset ::totals $k [expr {[lindex $::totals $k]+$t-[dict get $::starts $k]}]
  lset ::calls $k [expr {[lindex $::calls $k]+1}];dict unset ::starts $k
 }
}
for {set i 0} {$i<6} {incr i} {debug set_watchpoint write_mem [expr {$enemy_probe+$i}] {} [list mark $i]}
proc fixture {} {
 # Keep the enemy visible and away from contact, no deaths to bias the load.
 putword $::enemy [expr {[word $::player_x]-1280}]
 putword [expr {$::enemy+2}] [word $::player_y]
 debug write memory [expr {$::enemy+10}] 1
 if {!$::heavy} {putword $::pickup_taken 1023}
}
proc jump {} {keymatrixdown 8 1;after time 0.6 {keymatrixup 8 1};after time 1.6 jump}
proc sample {} {
 fixture;incr ::f
 if {$::f<240} {after frame sample;return}
 set ::measuring 0
 set sec [expr {[machine_info time]-$::begin}]
 set renders [expr {([word $::render_count]-$::initial_render)&65535}]
 set ticks [expr {([word $::simulation_ticks]-$::initial_tick)&65535}]
 set o [open $::env(KEEN_PROFILE_OUT) w]
 puts $o "mode=[expr {[debug read memory $::enemy_mode]+1}]"
 puts $o "heavy=$::heavy"
 puts $o "seconds=$sec"
 puts $o "renders=$renders"
 puts $o "ticks=$ticks"
 puts $o "fps=[expr {$renders/$sec}]"
 puts $o "defeats=[word $::defeats]"
 for {set k 0} {$k<3} {incr k} {
  set name [lindex {logic erase draw} $k]
  puts $o "${name}_ms=[expr {1000*[lindex $::totals $k]}]"
  puts $o "${name}_calls=[lindex $::calls $k]"
 }
 close $o;exit
}
after time 10 {
 set profile_mode $::env(KEEN_PROFILE_MODE);set heavy $::env(KEEN_PROFILE_HEAVY)
 keymatrixdown 0 [expr {2<<$profile_mode}]
 fixture
 after time 0.5 {
  keymatrixup 0 [expr {2<<$::profile_mode}]
  if {[debug read memory $::enemy_mode]!=$::profile_mode} {error "Keyboard mode selection failed"}
  set begin [machine_info time];set initial_render [word $render_count];set initial_tick [word $simulation_ticks]
  set measuring 1;set f 0;keymatrixdown 8 16
  if {$heavy} {jump}
  after frame sample
 }
}
'''
out.write_text(s)
