"""Run complete old/new combat implementations through identical deterministic inputs."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
source=r'''
#include <stdio.h>
#include <assert.h>
#include "msxgl.h"
u16 test_map[5032];u8 test_props[1168];
#define GAME_MAP test_map
#define GAME_COLLISION test_props
#include "game.c"
#include "pickups.c"
#include COMBAT_SOURCE
#define OUT(x) fwrite((const void*)&(x),sizeof(x),1,stdout)
int main(int argc,char**argv){
 FILE*f=fopen(argv[1],"rb");assert(f&&fread(test_map,1,sizeof test_map,f)==sizeof test_map);fclose(f);
 f=fopen(argv[2],"rb");assert(f&&fread(test_props,1,sizeof test_props,f)==sizeof test_props);fclose(f);
 for(unsigned run=0;run<50;run++){
  Game_Reset();CombatReset();InventoryAdd(20);enemy_mode=0;
  for(unsigned t=0;t<2000;t++){
   u8 in=(t%500<250)?1:2;
   if(t%113<40)in|=16;if(t%37==0)in|=64;if(t%79<15)in|=4;
   if(t%601==600)in|=32;
   if(t%151==0){enemy.x=player_x+(int)(run%7)*64-192;enemy.y=player_y;enemy.active=1;enemy.state=run%3==0;enemy.timer=50;}
   if(!death_ticks)Game_Tick(in);else simulation_ticks++;
   CombatTick(in);
   OUT(player_x);OUT(player_y);OUT(player_vx);OUT(player_vy);OUT(player_frame);OUT(grounded);
   OUT(enemy);OUT(shots);OUT(hero_frame);OUT(hero_visible);OUT(death_ticks);OUT(throw_ticks);
   OUT(flower_ammo);OUT(pickup_taken);OUT(shots_fired);OUT(flower_hits);OUT(flower_returns);OUT(defeats);
   OUT(pickups_collected);OUT(seeds_recovered);OUT(empty_throws);
  }
 }
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'trace.c').write_text(source);traces=[]
 for name,src in [('old',root/'build/logic-baseline/combat.c'),('new',root/'src/combat.c')]:
  subprocess.run(['cc','-O2','-std=c99','-I'+str(root/'tests/host'),'-I'+str(root/'src'),'-DCOMBAT_SOURCE="'+str(src)+'"',str(p/'trace.c'),'-o',str(p/name)],check=True)
  traces.append(subprocess.check_output([str(p/name),str(root/'assets/scene/map.bin'),str(root/'assets/scene/collision.bin')]))
 assert traces[0]==traces[1],next(i for i,(a,b) in enumerate(zip(*traces)) if a!=b)
 print(f'PASS: 100000 complete game/combat ticks identical, {len(traces[0])} trace bytes; contacts, flowers, throws, recovery, deaths, resets.')
