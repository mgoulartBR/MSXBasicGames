from pathlib import Path
import subprocess,os,re
r=Path(__file__).resolve().parents[1]
symbols={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
for name,header,extra in [('header-e',0x45,False),('header-e-corrupt',0x45,True),('header-f',0x46,False),('header-reference',0x45,False)]:
 out=r/'build'/('0913-'+name);out.mkdir(exist_ok=True)
 b=bytearray((r/'build/keen_msx.rom').read_bytes());b[0]=header
 if name=='header-reference':b[46*16384]=0x45
 if extra:b[0x201]^=1 # Not covered by the sampled bank hash.
 rom=out/'fault.rom';rom.write_bytes(b)
 script=f'''set throttle off
set save_settings_on_exit false
set accepted 0
debug set_bp {symbols["CpuAuto"]&65535} {{[debug read memory {symbols["g_CurrentSegment"]}]==30}} {{set accepted 1}}
after time 3 {{
 debug write ioports 0xa8 [expr {{([debug read ioports 0xa8]&0xc3)|0x14}}]
 reg PC 0x401c
}}
after time 40 {{
 screenshot {{{out/'result.png'}}}
 set f [open {{{out/'result.vram'}}} wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f
 set f [open {{{out/'result.txt'}}} w];puts $f "PC [reg PC] HEADER [debug read memory 0x4000] ACCEPTED $accepted";close $f
 exit
}}
'''
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=log,stderr=log,timeout=60,check=True)
 print(name,(out/'result.txt').read_text(),flush=True)

 assert ('ACCEPTED 1' if name=='header-e' else 'ACCEPTED 0') in (out/'result.txt').read_text()
