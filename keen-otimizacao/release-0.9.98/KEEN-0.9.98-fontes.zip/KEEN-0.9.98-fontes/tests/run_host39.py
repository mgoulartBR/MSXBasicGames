from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1]
for name,asset,typ in [('hill','scene',0),('mines','melon',0),('bridge29','bridge',0),('rapids','rapids',0),('pass','pass',1),('city','city',2),('apple','apple',2),('grove','grove',2),('bay','bay',2),('swamp','swamp',2),('boobus','boobus',2),('castle','castle',2),('campaign','',3)]:
 with (r/'build'/f'0939-host-{name}.log').open('w') as log:
  exe=r/'build'/f'host39-{name}'
  subprocess.run(['gcc','-O2','-ffunction-sections','-fdata-sections','-Wno-implicit-function-declaration','-I'+str(r/'tests/host'),'-I'+str(r/'src'),str(r/'tests/host'/f'test_{name}.c'),'-Wl,--gc-sections','-o',str(exe)],stdout=log,stderr=log,check=True)
  args=[] if typ==3 else [str(r/'assets'/asset/('packed_map.bin' if typ==0 else 'load_data.bin')),str(r/'assets'/asset/'stage_data.bin')]+([str(r/'assets'/asset/'map.bin')] if typ==2 else [])
  subprocess.run([str(exe),*args],stdout=log,stderr=log,check=True)
 print(name,'PASS',flush=True)
