"""External debugger profiler for unmodified 0.9.25: disjoint frame costs.
Initial checkpoint only; original enemy positions and normal simulation thereafter.
"""
from pathlib import Path
import os,re,subprocess,sys,json,csv,statistics,hashlib
r=Path(__file__).resolve().parents[1]
freq=int(sys.argv[1]) if len(sys.argv)>1 else 3579545
mode=sys.argv[2] if len(sys.argv)>2 else 'fire'
deep=len(sys.argv)>3 and sys.argv[3]=='deep'
assert mode in ('fire','walk')
label=os.environ.get('KEEN_PROFILE_LABEL','0925')
out=r/'build'/(f'pauses-{label}-{freq}-{mode}-v3'+('-deep' if deep else ''));out.mkdir(exist_ok=True)
rom=r/'build/keen_msx.rom';mp=r/'build/keen_msx.map'
assert hashlib.sha256(rom.read_bytes()).hexdigest()==os.environ.get('KEEN_PROFILE_EXPECTED_SHA','bd259bfde635583f9784b96dae7482385f280cb47d0065b67deadd253192e91a')
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='2',KEEN_TEST_OUTPUT=str(out))
for name in ('game','world','keydoor'):
 subprocess.run([sys.executable,str(r/f'tests/make_{name}_test.py'),str(r)],check=True)
s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+='\n'+ '\n'.join(f'set sym({n}) {a}' for n,a in syms.items())+'\n'
s+=f'set requested_freq {freq}\nset fire_mode {int(mode=="fire")}\n'
s+=r'''
proc fatal {message} {
 set f [open $::env(KEEN_TEST_OUTPUT)/ERROR.txt w]
 puts $f "$message\n$::errorInfo";close $f;exit
}
set trace_count 0
proc trace_event {event name} {
 if {$::trace_count<100} {
  incr ::trace_count
  set f [open $::env(KEEN_TEST_OUTPUT)/trace.txt a]
  puts $f "$event $name pc=[reg PC] sp=[reg SP] stack=$::phase_stack";close $f
 }
}
set profiling 0
set armed 0
set finished 0
set phase_stack {}
set tags {cart_step cart_contact key game combat prepare background actors camera upload render_other other wait_background wait_actors wait_upload wait_other sync idle}
array set totals {}
array set calls {}
foreach t $tags {set totals($t) 0.0;set calls($t) 0}
set frame_index 0
set previous_time -1
set last_event 0
set snapshots {}
proc category {} {
 if {![llength $::phase_stack]} {return other}
 set n [lindex $::phase_stack end]
 if {$n=="VDP_CommandWait"} {
  set parent [lindex $::phase_stack end-1]
  switch $parent {RingScene {return wait_background} ActorsDraw {return wait_actors} HWUpload {return wait_upload} default {return wait_other}}
 }
 switch $n {
  CartStep {return cart_step} CartContact {return cart_contact} KeyDoorTick {return key}
  Game_Tick {return game} CombatTick {return combat} ActorsPrepare {return prepare}
  RingScene {return background} ActorsDraw {return actors} FollowCamera {return camera}
  HWUpload {return upload} DrawScene {return render_other} SyncHalt {return sync} IdleHalt {return idle}
  default {return other}
 }
}
proc charge {} {
 set now [machine_info time]
 set cat [category]
 set ::totals($cat) [expr {$::totals($cat)+$now-$::last_event}]
 set ::last_event $now
}
proc enter {name} {
 if {$::armed && $name=="DrawScene"} {
  set ::armed 0;set ::profiling 1;set ::last_event [machine_info time]
 }
 if {!$::profiling} {return}
 if {[info exists ::pending($name)]} {return}
 trace_event enter $name
 charge
 lappend ::phase_stack $name
 incr ::calls([category])
 set sp [expr {([reg SP]+2)&65535}]
 if {[info exists ::pending($name)]} {error "recursive measured routine $name"}
 if {$name=="VDP_CommandWait"} {set ::pending($name) fixed;return}
 set ::pending($name) [debug set_bp [word [reg SP]] "\[reg SP\]==$sp" [list safe_leave $name]]
}
proc safe_leave {name} {if {[catch {leave $name} msg]} {fatal $msg}}
proc leave {name} {
 if {!$::profiling || ![info exists ::pending($name)]} {return}
 trace_event leave $name
 charge
 if {[lindex $::phase_stack end]!=$name} {error "unbalanced phase stack: $name $::phase_stack"}
 set ::phase_stack [lrange $::phase_stack 0 end-1]
 if {$::pending($name)!="fixed"} {debug remove_bp $::pending($name)}
 unset ::pending($name)
 if {$name=="DrawScene"} {presented}
}
proc halt_enter {name} {
 if {!$::profiling} {return}
 if {[lindex $::phase_stack end]==$name} {return}
 trace_event halt $name
 charge;lappend ::phase_stack $name;incr ::calls([category])
}
proc halt_leave {name} {
 if {!$::profiling} {return}
 trace_event leave $name
 charge
 if {[lindex $::phase_stack end]!=$name} {return}
 set ::phase_stack [lrange $::phase_stack 0 end-1]
}
proc fire_once {} {
 if {!$::profiling || $::finished} {return}
 keymatrixdown 3 1
 after time 0.4 {keymatrixup 3 1}
 after time 0.9 fire_once
}
proc presented {} {
 set now [machine_info time]
 set enemies 0;set projectiles 0
 set page [byte $::front_page]
 foreach i {1 20 21 22 23 24 25} {
  set a [expr {$::actors_old+$page*174+$i*6}]
  if {[byte [expr {$a+5}]]&1} {incr enemies}
 }
 foreach i {2 3} {
  set a [expr {$::actors_old+$page*174+$i*6}]
  if {[byte [expr {$a+5}]]&1} {incr projectiles}
 }
 if {$::previous_time>=0} {
  set duration [expr {$now-$::previous_time}]
  set row [list $::frame_index $now $duration [word $::raw_player_x] [word $::raw_player_y] [word $::drawn_camera_px] [word $::drawn_camera_py] $enemies $projectiles [byte $::sym(death_ticks)] [byte $::sym(game_lives)] [word $::sym(shots_fired)] [expr {([word $::sym(simulation_ticks)]-$::previous_ticks)&65535}]]
  set sum 0
  foreach t $::tags {set d [expr {$::totals($t)-$::previous_totals($t)}];lappend row $d;set sum [expr {$sum+$d}]}
  if {abs($sum-$duration)>0.00000001} {error "time accounting mismatch $sum $duration"}
  puts $::log [join $row ,]
  incr ::frame_index
 } else {
  set ::started $now
  after time 15 {set ::finished 1}
  after time 0.5 {keymatrixdown 8 16}
  after time 0.9 {keymatrixup 8 16}
  after time 3 {keymatrixdown 8 128}
  after time 3.15 {keymatrixup 8 128}
  after time 6 {keymatrixdown 8 16}
  after time 6.4 {keymatrixup 8 16}
  after time 9 {keymatrixdown 8 128}
  after time 9.15 {keymatrixup 8 128}
  if {$::fire_mode} {fire_once}
 }
 if {[byte $::sym(death_ticks)] || [byte $::sym(game_lives)]<3} {set ::finished 1}
 if {$::frame_index%5==0} {set n [format "frame%04d" $::frame_index];snap $n;lappend ::snapshots $n}
 set ::previous_time $now;set ::previous_ticks [word $::sym(simulation_ticks)]
 foreach t $::tags {set ::previous_totals($t) $::totals($t)}
 if {$::finished} {
  close $::log
  set f [open $::env(KEEN_TEST_OUTPUT)/snapshots.txt w];puts $f [join $::snapshots \n];close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: disjoint frame accounting; ROM unchanged";close $f
  exit
 }
}
proc setup_checkpoint {} {
 if {[byte $::render_commit]} {after time 0.001 setup_checkpoint;return}
 check {[byte $::active_level]==2} "Melon loaded"
 # One initial checkpoint. Original tomatoes are never moved/frozen by the test.
 place 1144 304
 putword $::sym(flower_ammo) 20
 debug write memory $::enemy_mode 0
 after time 1 {set z80_freq $::requested_freq;set z80_freq_locked false;set ::armed 1}
}
set log [open $::env(KEEN_TEST_OUTPUT)/frames.csv w]
puts $log [join [concat {frame time duration x y camera_x camera_y visible_enemies visible_shots death_ticks lives shots_fired logic_steps} $tags] ,]
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 40 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 5 setup_checkpoint
}
after time 100 {fatal "profiler timeout"}
'''
for name in ['Game_Tick','CombatTick','ActorsPrepare','RingScene','ActorsDraw','FollowCamera','HWUpload','DrawScene','VDP_CommandWait']+(['CartStep','CartContact','KeyDoorTick'] if deep else []):
 a=syms[name];condition='1' if a<65536 else f'[byte $sym(g_CurrentSegment)]=={a>>16}'
 s+=f'\ndebug set_bp {a&65535} {{{condition}}} {{if {{[catch {{enter {name}}} msg]}} {{fatal $msg}}}}\n'
wait_addr=syms['VDP_CommandWait']
assert rom.read_bytes()[wait_addr-0x4000+24]==0xc9
s+=f'\ndebug set_bp {wait_addr+24} {{$profiling}} {{safe_leave VDP_CommandWait}}\n'
for module,func,bank,label in [('main','main',0,'IdleHalt'),('keen_msx_s31_b1','DrawScene',31,'SyncHalt')]:
 listing=(r/f'src/out/{module}.lst').read_text()
 foffset=int(re.search(r'([0-9A-F]{8})\s+\d+ _'+func+r'::',listing)[1],16)
 base=(syms[func]&65535)-foffset
 halts=re.findall(r'([0-9A-F]{8}) 76\s+\[.*?\]\s+\d+\s+halt',listing)
 assert len(halts)==1,(module,halts)
 addr=base+int(halts[0],16)
 resume=addr+(4 if label=='SyncHalt' else 1)
 cond='$profiling'+(f' && [byte $sym(g_CurrentSegment)]=={bank}' if bank else '')
 s+=f'\ndebug set_bp {addr} {{{cond}}} {{if {{[catch {{halt_enter {label}}} msg]}} {{fatal $msg}}}}\ndebug set_bp {resume} {{{cond}}} {{if {{[catch {{halt_leave {label}}} msg]}} {{fatal $msg}}}}\n'
(out/'test.tcl').write_text(s);(out/'FAIL.txt').write_text('');(out/'PASS.txt').write_text('PENDING');(out/'trace.txt').write_text('');(out/'ERROR.txt').write_text('')
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=180,check=True)
assert (out/'PASS.txt').read_text().startswith('PASS'),(out/'emulator.log').read_text()
rows=list(csv.DictReader((out/'frames.csv').open()))
assert rows
values=[float(x['duration']) for x in rows];duration=sum(values)
tags=list(rows[0])[13:]
summary=dict(frequency=freq,mode=mode,rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),frames=len(rows),seconds=duration,fps=len(rows)/duration,median_ms=1000*statistics.median(values),p95_ms=1000*sorted(values)[int(.95*(len(values)-1))],max_ms=1000*max(values),visible_enemy_frames=sum(int(x['visible_enemies'])>=2 for x in rows),visible_shot_frames=sum(int(x['visible_shots'])>0 for x in rows),death_frames=sum(int(x['death_ticks'])>0 for x in rows),shots_fired=int(rows[-1]['shots_fired'])-int(rows[0]['shots_fired']),phase_seconds={k:sum(float(x[k]) for x in rows) for k in tags})
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
names=(out/'snapshots.txt').read_text().split()
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
(out/'VERIFIED.txt').write_text('PASS: sampled full viewports reconstructed from original assets.\n')
