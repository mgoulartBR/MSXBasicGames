"""C-BIOS with explicit EXTBIO fixtures. Not real DOS/Turbo-R validation."""
from pathlib import Path
import re,subprocess,os
r=Path(__file__).resolve().parents[1]
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
for name,status,alloc,free in [('absent',0,0,0),('ready',4,1,1),('no-free',2,0,0),('alloc-failed',3,1,0),('invalid',1,0,0),('free-failed',5,1,1)]:
 out=r/'build'/('0913-mapper-'+name);out.mkdir(exist_ok=True)
 script='''set throttle off
set save_settings_on_exit false
set alloc_calls 0
set free_calls 0
proc bytes {a vals} {foreach v $vals {debug write memory $a $v;incr a}}
proc ret {} {set a [reg SP];reg PC [expr {[debug read memory $a]+256*[debug read memory [expr {$a+1}]]}];reg SP [expr {$a+2}]}
'''
 if name!='absent':
  script+=f'''after time 15 {{
 debug write memory 0xfb20 [expr {{[debug read memory 0xfb20]|1}}]
 bytes 0xf100 {{139 32 {0 if name=='no-free' else 8} 6 18 0 0 0}}
 bytes 0xf120 {{195 64 241 195 80 241}}
 bytes 0xf140 {{{'55 201' if name=='alloc-failed' else '62 7 183 201'}}}
 bytes 0xf150 {{{'55 201' if name=='free-failed' else '175 201'}}}
}}
debug set_bp 0xffca {{}} {{
 if {{[reg DE]==0x0401}} {{reg A 139;reg HL 0xf100}}
 if {{[reg DE]==0x0402}} {{reg A 32;reg B 139;reg C {0 if name=='no-free' else 8};reg HL {'0x8100' if name=='invalid' else '0xf120'}}}
 ret
}}
debug set_bp 0xf140 {{}} {{incr alloc_calls}}
debug set_bp 0xf150 {{}} {{incr free_calls}}
'''
 script+=f'''after time 17 {{keymatrixdown 4 64;after time 0.3 {{keymatrixup 4 64}}}}
after time 24 {{
 set f [open {{{out/'result.txt'}}} w]
 puts $f "status [debug read memory {s['mapper_status']}] alloc $alloc_calls free $free_calls hot [debug read memory {s['hot_ok']}]"
 close $f;screenshot {{{out/'result.png'}}};exit
}}
'''
 (out/'test.tcl').write_text(script)
 with (out/'run.log').open('w') as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),stdout=log,stderr=log,timeout=60,check=True)
 result=(out/'result.txt').read_text().strip();print(name,result,flush=True)
 assert result==f'status {status} alloc {alloc} free {free} hot 1'
