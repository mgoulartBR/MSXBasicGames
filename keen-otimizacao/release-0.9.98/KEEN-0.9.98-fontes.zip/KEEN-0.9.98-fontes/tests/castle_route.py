"""Find a keyboard-walkable world route with production directional collision boxes.
Earlier stages completed is an explicit checkpoint, not an automated playthrough.
"""
from pathlib import Path
from collections import deque
import json
r=Path(__file__).resolve().parents[1];m=json.loads((r/'assets/tuberia/manifest.json').read_text());raw=(r/'assets/tuberia/packed_map.bin').read_bytes();head=(r/'src/tuberia_data.h').read_text();import re
flags=list(map(int,re.search(r'tuber_walls\[\]=\{([^}]+)',head)[1].split(',')));base=[((raw[i+(i>>3)]|raw[i+(i>>3)+1]<<8)>>(i&7))&511 for i in range(5610)];nodes=dict(m['nodes'])
def route(start,completed,goal):
 ids=base.copy()
 for i,normal,done,owner in m['patches']:ids[i]=done if completed&owner else normal
 def wall(x,y,s):return x<32 or y<32 or x>=1328 or y>=1024 or flags[ids[y//16*85+x//16]]&(1<<s)
 def selected(x,y):
  for yy in range((y+2)//16,(y+14)//16+1):
   for xx in range((x+2)//16,(x+13)//16+1):
    if yy*85+xx in nodes:return nodes[yy*85+xx]
  return 0
 # Four-pixel grid keeps keyboard turns away from the tightest cell edges.
 parent={start:None};q=deque([start]);target=None
 while q:
  x,y=q.popleft()
  if selected(x,y)==goal:target=(x,y);break
  for dx,dy in ((-4,0),(4,0),(0,-4),(0,4)):
   nx,ny=x+dx,y+dy
   if not(32<=nx<=1312 and 32<=ny<=1008)or(nx,ny)in parent:continue
   valid=True
   for step in range(1,5):
    px=x+(step if dx>0 else -step if dx<0 else 0);py=y+(step if dy>0 else -step if dy<0 else 0)
    if dx and(wall(px+(13 if dx>0 else 2),y+3,3 if dx>0 else 1)or wall(px+(13 if dx>0 else 2),y+14,3 if dx>0 else 1)):valid=False;break
    if dy and(wall(x+3,py+(14 if dy>0 else 2),0 if dy>0 else 2)or wall(x+12,py+(14 if dy>0 else 2),0 if dy>0 else 2)):valid=False;break
   if valid:parent[(nx,ny)]=(x,y);q.append((nx,ny))
 if target is None:return None
 path=[];p=target
 while p is not None:path.append(p);p=parent[p]
 path.reverse();turns=[path[0]];last=None
 for a,b in zip(path,path[1:]):
  d=(b[0]-a[0],b[1]-a[1])
  if last is not None and d!=last:turns.append(a)
  last=d
 turns.append(path[-1]);return turns
if __name__=='__main__':
 assert route((768,624),1023,11)is None
 castle=route((768,624),1023,12);assert castle
 boss=route(castle[-1],1023|2048,11);assert boss
 (r/'build/0938-route.json').write_text(json.dumps(dict(castle=castle,boss=boss,checkpoint_completed=1023,bombs=12),indent=2));print('PASS: boss inaccessible before Castle; keyboard route',castle,'; passage route',boss)

def distance_field(completed,goal):
 from array import array
 ids=base.copy()
 for i,normal,done,owner in m['patches']:ids[i]=done if completed&owner else normal
 walls=[flags[t]for t in ids];W=1360;H=1056
 def wall(x,y,s):return walls[y//16*85+x//16]&(1<<s)
 def valid(x,y,dx,dy):
  nx=x+dx;ny=y+dy
  if not(32<=nx<=1312 and 32<=ny<=1008):return False
  if dx:return not(wall(nx+(13 if dx>0 else 2),y+3,3 if dx>0 else 1)or wall(nx+(13 if dx>0 else 2),y+14,3 if dx>0 else 1))
  return not(wall(x+3,ny+(14 if dy>0 else 2),0 if dy>0 else 2)or wall(x+12,ny+(14 if dy>0 else 2),0 if dy>0 else 2))
 dist=array('H',[65535])*(W*H);q=deque()
 for pos,level in nodes.items():
  if level!=goal:continue
  tx,ty=pos%85*16,pos//85*16
  for y in range(ty-14,ty+14):
   for x in range(tx-13,tx+14):
    if any(nodes.get(yy*85+xx)==goal for yy in range((y+2)//16,(y+14)//16+1)for xx in range((x+2)//16,(x+13)//16+1)):
     idx=y*W+x
     if dist[idx]==65535:dist[idx]=0;q.append((x,y))
 while q:
  x,y=q.popleft();d=dist[y*W+x]+1
  for dx,dy in ((-1,0),(1,0),(0,-1),(0,1)):
   px,py=x-dx,y-dy
   if not(32<=px<=1312 and 32<=py<=1008)or dist[py*W+px]!=65535:continue
   if valid(px,py,dx,dy):dist[py*W+px]=d;q.append((px,py))
 permissions=bytearray(W*H)
 for y in range(32,1009):
  for x in range(32,1313):
   if dist[y*W+x]==65535:continue
   for dx,dy,bit in ((-1,0,16),(1,0,128),(0,-1,32),(0,1,64)):
    if valid(x,y,dx,dy):permissions[y*W+x]|=bit
 (r/'build'/f'0938-permissions-{goal}.bin').write_bytes(permissions)
 return dist
if __name__=='__main__':
 for name,completed,goal in [('castle',1023,12),('boss',3071,11)]:
  d=distance_field(completed,goal);assert d[624*1360+768]!=65535
  (r/'build'/f'0938-distance-{name}.bin').write_bytes(d.tobytes());print(name,'reverse native keyboard field ready',flush=True)
