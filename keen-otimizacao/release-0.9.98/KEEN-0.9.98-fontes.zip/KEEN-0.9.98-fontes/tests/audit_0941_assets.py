from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
a=(r/'baseline/KEEN0939.ROM').read_bytes();b=(r/'build/keen_msx.rom').read_bytes()
assert len(a)==len(b)==2097152
count=0
for off,name in re.findall(r'offset: (0x[0-9a-f]+), file: "([^"]+)"',(r/'src/project_config.js').read_text()):
 if name=='../build/core15/CORE15.BIN':continue
 off=int(off,16);n=len((r/'src'/name).read_bytes())
 assert a[off:off+n]==b[off:off+n],name
 count+=1
print(f'PASS: {count} existing packaged asset ranges remain byte-identical to 0.9.39, including all level maps and graphics.')
