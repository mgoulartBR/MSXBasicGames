from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/keydoor-test.tcl').read_text().split('after time 10 {')[0]
s+=r'''
proc finish_capture {} {
 if {[byte $::render_commit]} {after time 0.001 finish_capture;return}
        snap returned
        set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w]
        puts $f "PASS: overlapping frozen enemies/hero, retained frames, relocation, disappearance, camera movement and return. Controlled positions; ROM rendering."
        close $f;exit
}
proc hold_player {} {place $::hx $::hy;after time 0.03 hold_player}
proc tomato_place {index x y} {
 set t [expr {$::world_collision+1026+$index*13}]
 putword $t [expr {$x*16}];putword [expr {$t+2}] [expr {$y*16}]
}
after time 10 {
 putword $::world_x 608;putword $::world_y 448;keymatrixdown 8 1
 after time 0.3 {keymatrixup 8 1}
 after time 4 {
  check {[byte $::active_level]==2} "Melon loaded"
  debug write memory $::enemy_mode 1
  set ::hx 1240;set ::hy 192;hold_player
  tomato_place 0 1240 192;tomato_place 1 1250 200;tomato_place 2 1320 240
  after time 2 {
   snap overlap
   after time 1 {
    snap retained
    tomato_place 0 1270 204
    after time 2 {
     snap separated
     debug write memory $::enemy_mode 3
     after time 2 {
      snap removed
      debug write memory $::enemy_mode 1
      set ::hx 1300;set ::hy 240
      after time 3 {
       snap scrolled
       set ::hx 1240;set ::hy 192
       after time 3 {
        finish_capture
       }
      }
     }
    }
   }
  }
 }
}
after time 50 {check {0} "Timeout"}
'''
(r/'build/redraw-test.tcl').write_text(s)
