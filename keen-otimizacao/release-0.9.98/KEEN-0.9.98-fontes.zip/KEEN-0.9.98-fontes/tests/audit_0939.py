"""Independent original map/object/property audit and preserved previous assets."""
from pathlib import Path
import json,struct,sys,hashlib
from zipfile import ZipFile
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'tools'));from import_ega import planar
m=next(x for x in json.loads((r/'assets/generated/maps.json').read_text())if x['id']==16);p=r/'assets/castle';layout=json.loads((p/'combat_assets.json').read_text());a=(p/'atlas.bin').read_bytes();ids=struct.unpack('<6800H',(p/'map.bin').read_bytes());data=(p/'stage_data.bin').read_bytes();mh=(r/'assets/generated/MAPHEAD.KDR').read_bytes();aliases={(bg,fg):i for bg,fg,i in json.loads((p/'tile_keys.json').read_text())['aliases']}
equivalents={}
for key,i in aliases.items():
 bg,fg=key;q=r/'assets/generated'/f'chunk_{370+bg:04}.bin';pix=planar(q.read_bytes())[0]if q.exists()else[0]*256
 if fg:
  c,k=planar((r/'assets/generated'/f'chunk_{1810+fg:04}.bin').read_bytes(),16,16,True);pix=[(b if keep else 0)|f for b,f,keep in zip(pix,c,k)]
 equivalence=(bytes(pix),tuple(mh[3382+d*1206+fg]for d in range(6)))
 if i in equivalents:assert equivalents[i]==equivalence,key
 else:equivalents[i]=equivalence
 x,y=layout['tiles'][i]
 for yy in range(16):
  row=a[(y+yy)*128+x//2:(y+yy)*128+x//2+8];assert row==bytes((pix[yy*16+j]<<4)|pix[yy*16+j+1]for j in range(0,16,2)),key
 assert tuple(data[352+4*data[i]:356+4*data[i]])==tuple(mh[3382+d*1206+fg]for d in range(4)),key
 assert bool(data[480+i//8]&(1<<(i&7)))==(mh[3382+5*1206+fg]&127==1)
 f=layout['foreground'][i];assert bool(f)==bool(fg and mh[3382+5*1206+fg]&128)
 if f:assert layout['sprites'][f]['chunk']==1810+fg
for key,i in zip(zip(*m['planes'][:2]),ids):assert aliases[key]==i
assert len(layout['tiles'])==251 and (m['width'],m['height'])==(85,80)
assert len([v for v in m['planes'][2]if v in (47,42,45,49,57,46)])==22
assert sum(v==32 for v in m['planes'][2])==sum(v==33 for v in m['planes'][2])==2
assert sum(21<=v<=28 for v in m['planes'][2])==29
assert sum(1 if v==29 else 5 if v==30 else 0 for v in m['planes'][2])==40
assert not any(v==31 for v in m['planes'][2])
manifest=json.loads((r/'assets/tuberia/manifest.json').read_text());assert [(pos,level)for pos,level in manifest['nodes']if level==12]==[(1150,12),(1151,12),(1234,12),(1235,12),(1236,12)]
assert len([x for x in manifest['patches']if x[3]==2048])==4
old=r.parent/'deliverables/v0.9.38/keen-dreams-msx-0.9.38-rom-source.zip';count=0
with ZipFile(old)as z:
 for n in z.namelist():
  rel=n.removeprefix('keen-msx/')
  if rel.startswith('assets/') and rel.endswith('.bin') and rel.split('/')[1]in ('scene','melon','bridge','rapids','pass','city','apple','grove','bay','swamp','boobus','castle'):
   if rel in ('assets/boobus/atlas.bin','assets/boobus/load_data.bin'):continue
   assert (r/rel).read_bytes()==z.read(n),n;count+=1
rom=(r/'build/keen_msx.rom').read_bytes();assert len(rom)==2097152 and rom[46*16384:47*16384]==rom[:16384]
assert hashlib.sha256((r.parent/'deliverables/v0.9.38/KEEN0938.ROM').read_bytes()).hexdigest()=='705f9cab70ca8d1a716a6702acfe92f5ddc14b69792041162e5610539c7f872b'
print(f'PASS: all 6800 original Castle cells and 395 original pairs; exact pixels and six-property canonicalization; complete original roster, keys/doors/29 bonuses/40 seeds/no invented bombs; Castle world node12/code18 and four original passage patches; {count} unchanged previous-stage binaries; .38 preserved and bank46 boot-copy valid.')
