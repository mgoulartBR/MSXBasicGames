"""BIOS/OCM protocol fixtures; no real R800 or FPGA emulation."""
from pathlib import Path
import re,os,subprocess
root=Path(__file__).resolve().parents[1];out=root/'build/099-cpu';out.mkdir(exist_ok=True)
s={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(root/'build/keen_msx.map').read_text(),re.M)}
data=Path(os.environ['OPENMSX_SYSTEM_DATA'])
b=bytearray((data/'systemroms/cbios_main_msx2+.rom').read_bytes());b[45]=3
# CHGCPU stores selector in unused RAM; GETCPU returns its low two bits.
b[0x180:0x186]=bytes([0xc3,0,0x30,0xc3,8,0x30]);b[0x3000:0x3004]=bytes([0x32,0,0xf1,0xc9]);b[0x3008:0x300e]=bytes([0x3a,0,0xf1,0xe6,3,0xc9])
(out/'stub.rom').write_bytes(b)
x=(data/'machines/C-BIOS_MSX2+.xml').read_text();x=re.sub(r'<sha1>.*?</sha1>','',x,count=1).replace('cbios_main_msx2+.rom',str(out/'stub.rom'));(data/'machines/Keen099Stub.xml').write_text(x)
for name in ['r800','ocm-preserve','ocm-enable']:
 dest=out/(name+'.txt')
 t=f'''set throttle off
proc check {{ok msg}} {{if {{!$ok}} {{finish "FAIL $msg"}}}}
proc finish {{msg}} {{set f [open {{{dest}}} w];puts $f $msg;close $f;exit}}
'''
 if name=='r800':
  t+=f'''after time 10 {{check [expr {{[debug read memory {s['cpu_mode']}]==2}}] auto82;keymatrixdown 0 4;after time 0.4 {{keymatrixup 0 4}}}}
after time 12 {{check [expr {{[debug read memory {s['cpu_mode']}]==1}}] rom81;keymatrixdown 0 2;after time 0.4 {{keymatrixup 0 2}}}}
after time 14 {{check [expr {{[debug read memory {s['cpu_mode']}]==0}}] z80;keymatrixdown 0 8;after time 0.4 {{keymatrixup 0 8}}}}
after time 16 {{check [expr {{[debug read memory {s['cpu_mode']}]==2}}] dram82;screenshot {{{out/'r800.png'}}};finish "PASS automatic DRAM and manual ROM/Z80/DRAM selectors; BIOS stubs only"}}
'''
 else:
  t+=f'source {{{root/"tests/ocm_fixture.tcl"}}}\n'
  if name=='ocm-preserve':t+='set keen_ocm::ports(66) 215\nset keen_ocm::ports(72) 162\nset z80_freq 10000000\nset z80_freq_locked true\n'
  count,freq=(0,10000000) if name=='ocm-preserve' else (1,8060000)
  t+=f'''after time 10 {{check [expr {{[debug read memory {s['cpu_mode']}]==4}}] mode;check [expr {{[llength $keen_ocm::commands]=={count}}}] writes;check [expr {{$z80_freq=={freq}}}] frequency;check [expr {{$keen_ocm::selected==8}}] restore;finish "PASS {name}: {count} clock writes, {freq} Hz; protocol fixture only"}}
'''
 script=out/(name+'.tcl');script.write_text(t)
 with (out/(name+'.log')).open('w') as log:subprocess.run(['openmsx','-machine','Keen099Stub' if name=='r800' else 'C-BIOS_MSX2+','-cart',str(root/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(script)],stdout=log,stderr=log,timeout=40,check=True)
 text=dest.read_text();print(text.strip(),flush=True);assert text.startswith('PASS')
