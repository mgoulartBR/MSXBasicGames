from pathlib import Path
import sys
r=Path(sys.argv[1]);s=(r/'build/stage-test.tcl').read_text().split('after time 10 {')[0]
s+='\nafter time 10 {\n debug write memory $enemy_mode 3\n'
for i,(face,y) in enumerate([(0,160),(1,160),(0,174),(1,174),(0,190),(1,190),(0,204),(1,204)]):
 s+=f''' after time {i+0.1} {{place [expr {{103*256-128}}] {y*16};debug write memory $climbing 1;debug write memory $facing_left {face};debug write memory $combat_dirty 1}}
 after time {i+0.7} {{snap pole_{i}}}
'''
s+=' after time 9 {exit}\n}\n';(r/'build/pole-visual.tcl').write_text(s)
