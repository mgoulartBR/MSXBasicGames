from pathlib import Path
import re,sys
r=Path(sys.argv[1]);out=Path(sys.argv[2]);freq=int(sys.argv[3])
mp=(r/'build/keen_msx.map').read_text()
syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp,re.M)}
# Reuse the deterministic scene setup; instrumentation stays outside the ROM.
import subprocess
subprocess.run([sys.executable,str(r/'tests/make_redraw_bench.py'),str(r),str(r/'build/keen_msx.map'),str(out)],check=True)
s=out.read_text();s=s.replace('after time 10 [list finish $mode]', 'keenprof::begin $mode\n after time 10 [list finish $mode]').replace('proc finish {mode} {','proc finish {mode} {\n keenprof::finish')
# Fifth scenario: moving camera, same objects, controlled vertical trajectory.
s=s.replace('if {$mode<3}', 'if {$mode<4}')
s=s.replace('debug write memory $::enemy_mode $mode', 'set ::profile_scroll [expr {$mode==4}]\n debug write memory $::enemy_mode [expr {$mode==4?0:$mode}]')
s=s.replace('putword $::player_x 19840;putword $::player_y 3072', 'putword $::player_x 19840\n  set y 192\n  if {$::profile_scroll} {set phase [expr {int([machine_info time]*45)%256}];set y [expr {128+($phase<128?$phase:256-$phase)}]}\n  putword $::player_y [expr {$y*16}]')
s=s.replace('putword $::player_y [expr {$y*16}]', r"""putword $::player_y [expr {$y*16}]
  # Bounded stress fixture: keep three living enemies visible, but let their
  # normal AI/animation run between corrections. No change to ROM logic.
  foreach {i x} {0 1150 1 1190 2 1290} {
   set t [expr {$::world_collision+1026+$i*13}]
   if {abs([word $t]/16-$x)>8 || abs([word [expr {$t+2}]]/16-($y+16))>8} {
    putword $t [expr {$x*16}];putword [expr {$t+2}] [expr {($y+16)*16}]
   }
  }""")
s=s.replace('set throttle off' ,'set profile_scroll 0\nset z80_freq '+str(freq)+'\nset z80_freq_locked false\nset throttle off')
# Validate the exact polling loop boundaries from ROM bytes.
rom=(r/'build/keen_msx.rom').read_bytes();wait=syms['VDP_CommandWait'];setup=syms['VDP_CommandSetupR32']
assert rom[setup-0x4000-1]==0xc9
assert setup-wait==25
s+='\nset profile_bank '+str(syms['g_CurrentSegment'])+'\n'+(r/'tests/vdp_profile.tcl').read_text()
s+=f'\ndebug set_bp {wait} {{}} keenprof::wait_enter\ndebug set_bp {setup-1} {{}} keenprof::wait_exit\ndebug probe set_bp VDP.commandExecuting {{}} keenprof::vdp\n'
for name in ['HWPrepare','HWUpload','HeroBitmap','Game_Tick','CombatTick','TomatoTick','ActorsPrepare','RingScene','ActorsDraw','ActorDraw','HudDraw','CartDraw','MapTile']:
 addr=syms[name];condition='{}' if addr<65536 else '{[byte '+str(syms['g_CurrentSegment'])+']=='+str(addr>>16)+'}'
 s+=f'debug set_bp {addr&65535} {condition} {{keenprof::enter {name}}}\n'
# Record actual visible enemies on every completed frame (not just active AI).
s+=f"set profile_actors {syms['actors_old']}\nset profile_front {syms['front_page']}\n"
s+=f"debug set_bp {syms['HWFlip']&65535} {{[byte {syms['g_CurrentSegment']}]==21}} keenprof::frame\n"
if len(sys.argv)>4 and sys.argv[4]=='control':
 s='\n'.join(line for line in s.splitlines() if not line.startswith('debug set_bp ') and not line.startswith('debug probe set_bp '))
 # Keep begin/finish timestamps, remove absent-probe state integration.
 s=s.replace('set busy [debug probe read VDP.commandExecuting]', 'set busy 0')
out.write_text(s)
