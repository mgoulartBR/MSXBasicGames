"""Explicit world checkpoint plus native Castle integration and full-frame pixel checks.
The checkpoint (ten stages completed/12 bombs) and Castle object/exit poses are
explicit fixtures. World movement, entry, door raising and completion run in Z80.
"""
from pathlib import Path
import os,re,subprocess,sys,hashlib,json
r=Path(__file__).resolve().parents[1];machine=sys.argv[1]if len(sys.argv)>1 else'C-BIOS_MSX2+';out=r/'build'/('0943-castle-rom'if machine=='C-BIOS_MSX2+'else'0943-castle-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_STAGE='12',KEEN_TEST_OUTPUT=str(out))
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')];syms={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
syms['WorldInput']=0x8000+int(re.search(r'_WorldInput\s+([0-9A-F]{8})', (r/'src/out/keen_msx_s8_b1.sym').read_text())[1],16)
syms['PatchWorld']=0x8000+int(re.search(r'_PatchWorld\s+([0-9A-F]{8})', (r/'src/out/keen_msx_s8_b1.sym').read_text())[1],16)
route=json.loads((r/'build/0938-route.json').read_text());spawns=[(45,42),(52,53),(33,64),(22,75),(31,75),(50,75),(65,75),(41,42),(13,53),(63,53),(41,23),(73,45),(8,53),(44,23),(45,64),(54,25),(66,25)]
s='\n'.join(f'set {n} {a}'for n,a in syms.items())+'\n'+snap
s+='set castle_route {'+' '.join('{%d %d}'%tuple(p)for p in route['castle'][1:])+'}\nset boss_route {'+' '.join('{%d %d}'%tuple(p)for p in route['boss'][1:])+'}\n'
s+=f'set route_fixture {1}\n'
s+='set spawns {'+' '.join('{%d %d}'%p for p in spawns)+'}\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set phase 0
set held 0
set names {}
set poses {124 130 128 134 112 108 152 153 154 155 156 157 158 159 160 161 162 163 116 117 118 119 120 121 122 123 136 137 90 91 92 93 164 165}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc checkpoint {} {if {$::phase==0} {putword $::world_completed 1023;putword $::boobus_bombs 12;set ::phase 1}}
proc hold {x y} {set ::held 1;set ::hx [expr {$x*16}];set ::hy [expr {$y*16}]}
proc fixture {} {if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc distance {x y} {if {$x<32 || $x>1312 || $y<32 || $y>1008} {return 65535};set off [expr {2*($y*1360+$x)}];binary scan $::distance_data @${off}su v;return $v}
proc walk {points callback} {
 set ::walk_callback $callback;set ::walking 1;set ::walk_steps 0
 set kind [expr {$::phase==2?"castle":"boss"}]
 set f [open $::env(KEEN_TEST_OUTPUT)/../0938-distance-$kind.bin rb];set ::distance_data [read $f];close $f
 set goal [expr {$::phase==2?12:11}];set f [open $::env(KEEN_TEST_OUTPUT)/../0938-permissions-$goal.bin rb];set ::permissions [read $f];close $f
}
proc navigate {} {
 if {![info exists ::walking] || !$::walking} {return}
 incr ::walk_steps;check {$::walk_steps<20000} "Keyboard route timeout: [word $::world_x],[word $::world_y] phase=$::phase"
 set x [word $::world_x];set y [word $::world_y];set d [distance $x $y]
 if {$d==0} {keys 0;set ::walking 0;after time 0.1 $::walk_callback;return}
 check {$d<65535} "No route from native coordinates $x,$y"
 set bits 0;set best $d;binary scan $::permissions @[expr {$y*1360+$x}]cu allowed
 foreach {dx dy bit} {-1 0 16 1 0 128 0 -1 32 0 1 64} {set v [distance [expr {$x+$dx}] [expr {$y+$dy}]];if {($allowed&$bit) && $v<$best} {set best $v;set bits $bit}}
 check {$bits!=0} "No descending route at $x,$y";keys $bits
}
proc start {} {
 if {![byte $::world_active] || [byte $::world_draw_busy]} {after time 0.1 start;return}
 check {[word $::world_completed]==1023 && [word $::boobus_bombs]==12 && [word $::world_x]==768 && [word $::world_y]==624} "Explicit checkpoint at normal world spawn"
 set ::phase 2;if {$::route_fixture} {putword $::world_x 720;putword $::world_y 236;after time 0.1 castle_enter} else {walk $::castle_route castle_enter}
}
proc castle_enter {} {check {[byte $::world_active] && [word $::boobus_bombs]==12} "Checkpoint coordinates and inventory reached Castle";keys 1;after time 0.3 {keys 0;after time 0.1 entered}}
proc entered {} {
 if {[byte $::active_level]!=12 || [byte $::world_active] || [byte $::scene_ready]!=165 || [byte $::render_commit]} {after time 0.1 entered;return}
 check {[byte [expr {$::world_collision+1120}]]==85 && [byte [expr {$::world_collision+1121}]]==80} "Original Castle map dimensions"
 set ::phase 3;debug write memory $::enemy_mode 1;after time 0.2 landed
}
proc landed {} {if {![byte $::grounded]} {after time 0.05 landed;return};set ::startx [word $::player_x];keys 128;after time 0.5 {keys 0;after time 0.1 movement}}
proc movement {} {check {[word $::player_x]>$::startx && ![byte $::death_ticks]} "Native walking from original Castle spawn";snap spawn;lappend ::names spawn;set ::object 0;key_get}
proc key_get {} {
 if {$::object==2} {check {[byte [expr {$::world_map+7490}]]==3 && [byte $::key_owned]==2} "Both original keys collected";set ::object 0;door_before;return}
 if {$::object==0} {hold 572 445} else {hold 28 717};after time 0.1 key_ready
}
proc key_ready {} {if {!([byte [expr {$::world_map+7490}]]&(1<<$::object))} {after time 0.05 key_ready;return};incr ::object;key_get}
proc door_before {} {
 if {$::object==2} {check {![byte $::key_owned]} "Doors consume two separate keys";set ::pose 0;pose;return}
 if {$::object==0} {hold 704 336} else {hold 1184 336};after time 0.5 door_snap
}
proc door_snap {} {
 if {[byte $::render_commit]} {after time 0.01 door_snap;return};set name "door-before-$::object";snap $name;lappend ::names $name
 if {$::object==0} {hold 764 333} else {hold 1244 333};after time 0.1 door_open
}
proc door_open {} {
 if {[byte [expr {$::world_map+7493+$::object}]]!=2} {after time 0.05 door_open;return}
 if {[byte $::render_commit]} {after time 0.01 door_open;return};set name "door-after-$::object";snap $name;lappend ::names $name;incr ::object;door_before
}
proc pose {} {
 if {$::pose==[llength $::poses]} {set ::object 0;seed_get;return}
 set ::frame [lindex $::poses $::pose]
 # Controlled render poses exercise every new streaming frame on the original map.
 for {set i 0} {$i<17} {incr i} {debug write memory [expr {$::world_map+7200+16*$i+10}] 0}
 for {set i 0} {$i<5} {incr i} {debug write memory [expr {$::world_collision+1026+13*$i+8}] 0}
 for {set i 0} {$i<3} {incr i} {debug write memory [expr {$::world_map+9240+16*$i+10}] 0}
 set a [expr {$::world_map+7200}];putword $a [expr {43*256}];putword [expr {$a+2}] [expr {22*256}];debug write memory [expr {$a+10}] 1;debug write memory [expr {$a+11}] $::frame;debug write memory [expr {$a+13}] 0
 hold 640 400;after time 0.8 pose_snap
}
proc pose_snap {} {
 if {[byte $::render_commit]} {after time 0.01 pose_snap;return}
 set found 0;for {set i 15} {$i<28} {incr i} {set d [expr {$::actors_old+[byte $::front_page]*174+6*$i}];if {[byte [expr {$d+5}]] && [byte [expr {$d+4}]]==$::frame} {set found 1}}
 if {!$found} {after time 0.05 pose_snap;return}
 set name "pose-$::frame";snap $name;lappend ::names $name;incr ::pose;pose
}
proc seed_get {} {
 if {$::object==16} {check {[word $::flower_ammo]==40 && [word $::boobus_bombs]==12} "All Castle seeds retain twelve bombs";hold 1310 336;set ::phase 4;after time 0.2 leave;return}
 set a [expr {$::world_collision+876+6*$::object}];hold [expr {[word $a]-4}] [expr {[word [expr {$a+2}]]-3}];after time 0.1 seed_ready
}
proc seed_ready {} {set flags [expr {[word $::pickup_taken]+65536*[word [expr {$::pickup_taken+2}]]}];if {!($flags&(1<<$::object))} {after time 0.05 seed_ready;return};incr ::object;seed_get}
proc leave {} {set ::held 0;debug write memory $::climbing 0;putword $::player_x [expr {83*256-304}];putword $::player_y [expr {22*256}];debug write memory $::grounded 1;keys 128;after time 0.01 completed}
proc completed {} {
 if {[byte $::level_done]!=2} {after time 0.1 completed;return}
 keys 0;keys 1;after time 0.3 {keys 0;after time 0.1 world_return}
}
proc world_return {} {
 if {![byte $::world_active] || [byte $::world_draw_busy]} {after time 0.1 world_return;return}
 check {[word $::world_completed]==3071 && [word $::boobus_bombs]==12} "Castle completion bit2048 and bombs retained"
 set f [open $::env(KEEN_TEST_OUTPUT)/world-complete.vram wb];puts -nonewline $f [debug read_block VRAM [expr {[byte $::wpage]*32768}] 32768];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/world-complete.txt w];puts $f "[word $::world_x] [word $::world_y] [byte $::wframe] [word $::wcx] [word $::wcy] [word $::world_completed] [byte $::hardware_scroll] [byte $::world_notice]";close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/world-complete.map wb];puts -nonewline $f [debug read_block memory $::world_map 6312];close $f
 set ::phase 5;if {$::route_fixture} {putword $::world_x 720;putword $::world_y 188;after time 0.1 boss_gate} else {walk $::boss_route boss_gate}
}
proc boss_gate {} {check {[word $::boobus_bombs]==12} "Keyboard route through opened Castle passage";putword $::boobus_bombs 11;keys 1;after time 0.3 {keys 0;after time 0.2 blocked}}
proc blocked {} {check {[byte $::world_active] && [byte $::active_level]==12} "Eleven bombs blocks boss entry";putword $::boobus_bombs 12;keys 1;after time 0.3 {keys 0;after time 0.1 boss_entered}}
proc boss_entered {} {
 if {[byte $::active_level]!=11 || [byte $::world_active] || [byte $::scene_ready]!=165 || [byte [expr {$::world_collision+1120}]]!=35 || [word $::drawn_x]!=3*256 || [byte $::render_commit]} {after time 0.1 boss_entered;return}
 check {[word $::boobus_bombs]==12 && [byte [expr {$::world_collision+1120}]]==35 && [byte [expr {$::world_map+7216}]]==12} "Boobus arena entered with 12 bombs and 12 HP"
 set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
 set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: world checkpoint positioning and native Castle walking, original map/spawn and native walking; 2 keys/doors, all 16 pickups/40 seeds; Castle exit/completion opens original passage, keyboard walk into Boobus Room, 11 bombs blocked/12 accepted; [llength $::names] independent frame captures. Explicit fixtures: ten-stage/12-bomb checkpoint, object/render/exit positioning; world positions are explicit fixtures on both machines; completion is never injected.";close $f;exit
}
after time 40 start
after time 400 {check {0} "Timeout phase=$::phase stage=[byte $::active_level] world=[word $::world_x],[word $::world_y] player=[word $::player_x],[word $::player_y]"}
'''
s+=''.join(f'after time {t} {{if {{$::phase<2 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n'for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["WorldInput"]&65535} {{[byte $::g_CurrentSegment]==8}} navigate\n'
s+=f'\ndebug set_bp {syms["PatchWorld"]&65535} {{[byte $::g_CurrentSegment]==8}} checkpoint\n'
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with(out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=500)
assert not(out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text();assert(out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
if machine=='C-BIOS_MSX2':
 (out/'PASS.txt').write_text((out/'PASS.txt').read_text().replace('world checkpoint positioning and native Castle walking','MSX2 world entry position fixtures; Castle integration').replace('keyboard walk into Boobus Room','boss entry position fixture after passage patch'))
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*(out/'names.txt').read_text().splitlines()],env=env,check=True)
subprocess.run([sys.executable,str(r/'tests/verify_world_pixels.py'),str(out),'world-complete'],env=env,check=True)
(out/'ROM-SHA256.txt').write_text(hashlib.sha256((r/'build/keen_msx.rom').read_bytes()).hexdigest()+'\n');(out/'VERIFIED.txt').write_text('PASS: independent original Castle and world full-frame pixels.\n');print((out/'PASS.txt').read_text())
