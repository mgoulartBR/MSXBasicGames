from pathlib import Path
import sys
p=Path(sys.argv[1]);s=(p/'build/game-test.tcl').read_text().split('after time 10 {')[0]
s=s.replace('set throttle on','set throttle off')
s+=r'''
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc select_enemy_mode {n} {keymatrixdown 0 [expr {2<<$n}];after time 0.25 [list keymatrixup 0 [expr {2<<$n}]]}
proc visible_enemy {} {byte [expr {$::actors_old+[byte $::front_page]*90+11}]}
after time 10 {
 check {[byte $scene_ready]==165} "Boot"
 debug write memory $hud_debug 1
 debug write memory $combat_dirty 1
 putword $enemy [expr {[word $player_x]-1280}];putword [expr {$enemy+2}] [word $player_y]
 debug write memory [expr {$enemy+10}] 1;debug write memory [expr {$enemy+14}] 0
 after time 0.6 {check {[visible_enemy]} "Normal enemy visible";snap normal;select_enemy_mode 1}
 after time 1.1 {set frozen_x [word $enemy];set frozen_y [word [expr {$enemy+2}]]}
 after time 1.7 {
  check {[byte $enemy_mode]==1 && [visible_enemy]} "Mode 2 visible"
  check {[word $enemy]==$frozen_x && [word [expr {$enemy+2}]]==$frozen_y} "Mode 2 frozen"
  snap frozen;select_enemy_mode 2
 }
 after time 2.6 {
  check {[byte $enemy_mode]==2 && ![visible_enemy]} "Mode 3 invisible"
  check {[word $enemy]!=$frozen_x || [word [expr {$enemy+2}]]!=$frozen_y} "Mode 3 logic continues"
  snap invisible;select_enemy_mode 3
 }
 after time 3.1 {set frozen_x [word $enemy];set frozen_y [word [expr {$enemy+2}]]}
 after time 3.7 {
  check {[byte $enemy_mode]==3 && ![visible_enemy]} "Mode 4 invisible"
  check {[word $enemy]==$frozen_x && [word [expr {$enemy+2}]]==$frozen_y} "Mode 4 frozen"
  snap neither
  # The moving courier can have left the viewport; reposition the fixture
  # before checking that mode 1 makes drawing visible again.
  putword $enemy [expr {[word $player_x]-1280}];putword [expr {$enemy+2}] [word $player_y]
  select_enemy_mode 0
 }
 after time 4.4 {
  check {[byte $enemy_mode]==0 && [visible_enemy]} "Return to normal"
  snap restored
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: four keyboard modes, frozen logic, hidden drawing, both disabled, restoration.";close $f;exit
 }
}
'''
(p/'build/enemy-mode-test.tcl').write_text(s)
