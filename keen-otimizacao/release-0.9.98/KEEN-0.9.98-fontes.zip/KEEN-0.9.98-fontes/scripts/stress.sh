#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_scroll_stress.py" "$PROJECT_ROOT"
MACHINE="${1:-C-BIOS_MSX2}"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/stress-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/scroll-stress.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
NAMES=()
for ((i=60;i>=1;--i)); do NAMES+=("stress$i"); done
python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" "${NAMES[@]}" | tee "$KEEN_TEST_OUTPUT/pixels.txt"
