from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.17';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0917.ROM';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
b=rom.read_bytes()
assert b'0.9.15' not in b and b'0.9.16' not in b
assert b'0.9.17 EXPERIMENTS' in b and b'KEEN 0.9.17 HARDWARE TEST' in b
assert b'KEEN 0.9.17 CORE / ROM / NO DRAW' in b and b'COMPARE WITH KCORE17 IN DOS' in b
assert b[0xc0000:0xc4000]==(root.parent/'deliverables/v0.9.16/KEEN0916.ROM').read_bytes()[0xc0000:0xc4000]
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ['keen_msx.rom','keen_msx.map','0917-build.log']:files.append(root/'build'/name)
for d in (root/'build').glob('0917-*'):
 if d.is_dir():files.extend(p for p in d.iterdir() if p.is_file() and p.suffix not in ('.rom','.com'))
assert (root/'build/0917-dos-bad-read-entry/result.txt').read_text().strip()=='FAIL WRSLT called instead of DOS RDSLT'
for case in ['pass','cpu-1','cpu-2','cpu-3','tpa-d406','tpa-min']:
 assert 'TRACE: 9775 STEPS: 0AF0' in (root/f'build/0917-dos-{case}/screen.txt').read_text()
assert 'status 0 alloc 1 free 1 ram 2 page2 1' in (root/'build/0917-dos-pass/result.txt').read_text()
assert (root/'build/0917-ef/result.txt').read_text().startswith('PASS')
files.extend(p for p in (root/'build/dos').iterdir() if p.is_file() and (p.name.startswith('kcore17.') or p.name=='KCORE17.COM'))
files.extend(p for p in (root/'build/core15').iterdir() if p.is_file())
assert (root/'build/0917-core-rom/result.txt').read_text().startswith('PASS')
com=out/'KCORE17.COM';shutil.copyfile(root/'build/dos/KCORE17.COM',com)
b=rom.read_bytes()
assert b[0xc0000:0xc4000]==(root/'build/core15/CORE15.BIN').read_bytes()
assert com.read_bytes().count(b[0xc0000:0xc4000])==1
assert b[:16384]==b[46*16384:47*16384]
archive=out/'keen-dreams-msx-0.9.17-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,com,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
