from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.7';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.7-bridge-enemies.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='2873cce8a2a20b8174d1d834f34f294d7e15bd702a81abd58f0fa3e7e9991b1d'
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','097-build-final.log','097-assets.log','097-host.txt','bridge-enemies.tcl','campaign3.tcl']:
 files.append(root/'build'/n)
for folder in ['097-release-plus','097-release-msx2','097-release-campaign']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS')
 assert not (d/'FAIL.txt').exists()
 files.extend(p for p in d.iterdir() if p.is_file())
archive=out/'keen-dreams-msx-0.9.7-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
