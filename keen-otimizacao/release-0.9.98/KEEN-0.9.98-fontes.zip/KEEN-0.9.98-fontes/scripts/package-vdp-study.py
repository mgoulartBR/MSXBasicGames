from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/vdp-study-0.8.7';out.mkdir(parents=True,exist_ok=True)
rom=r/'build/keen_msx.rom'
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='4a530502772d2b5cf60d5898de769a72346cf2cd3676217fd1456531cab4bb14'
assert (r/'build/088-profile-summary/PASS.txt').read_text().startswith('PASS:')
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','087-release-build.log','088-profile-standard.log','088-profile-turbo.log']:
 files.append(r/'build'/n)
for folder in ['088-profile-3579545','088-profile-7159090','088-profile-control-7159090','088-profile-summary']:
 files.extend(p for p in (r/'build'/folder).iterdir() if p.is_file() and p.suffix in ['.txt','.log','.tcl','.csv','.json'] and p.name!='generator-check.tcl')
zpath=out/'keen-dreams-msx-0.8.7-vdp-study-source.zip'
with ZipFile(zpath,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,Path('keen-msx')/p.relative_to(r))
with ZipFile(zpath) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
 assert z.read('keen-msx/docs/VDP-PROFILE-087.md')==(out/'keen-dreams-msx-vdp-study.md').read_bytes()
print(zpath,zpath.stat().st_size,hashlib.sha256(zpath.read_bytes()).hexdigest())
