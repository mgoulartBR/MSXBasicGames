#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_hw_test.py" "$PROJECT_ROOT"
export KEEN_WORLD_TEST=1 KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/089-hw-final"
mkdir -p "$KEEN_TEST_OUTPUT"
python3 - "$KEEN_TEST_OUTPUT" <<'CLEAN'
from pathlib import Path
import sys
for name in ('vblank.txt','PASS.txt'):(Path(sys.argv[1])/name).unlink(missing_ok=True)
CLEAN
timeout 45s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine C-BIOS_MSX2+ -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/hw-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
python3 "$PROJECT_ROOT/tests/verify_hw_test.py" "$KEEN_TEST_OUTPUT"
