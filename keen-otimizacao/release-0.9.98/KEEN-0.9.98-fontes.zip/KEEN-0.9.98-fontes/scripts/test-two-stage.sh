#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_world_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_two_stage_test.py" "$PROJECT_ROOT"
export KEEN_WORLD_TEST=1 KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/two-stage-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
timeout 60s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/two-stage-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
test -f "$KEEN_TEST_OUTPUT/PASS.txt"
python3 "$PROJECT_ROOT/tests/verify_world_pixels.py" "$KEEN_TEST_OUTPUT" hh_done both_done reset_world
python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" hh_spawn
KEEN_STAGE=2 python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" melon_spawn melon_pickup melon_deep
cmp "$PROJECT_ROOT/assets/melon/packed_map.bin" "$KEEN_TEST_OUTPUT/melon-map.bin"
cmp "$PROJECT_ROOT/assets/melon/stage_data.bin" "$KEEN_TEST_OUTPUT/melon-data.bin"
cat "$KEEN_TEST_OUTPUT/PASS.txt"
