"""Package the validated single-Tomatooth hardware experiment."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.8.9';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.8.9-hardware-tomato.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='42b1017bbf1445d5c93e49b4a59c803bb34e51da936e333a554d80f0ffde023d'
archive=out/'keen-dreams-msx-0.8.9-source.zip';files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.')for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','089-release-build.log','089-atlas-verify.log','089-redraw-msx2.log','089-redraw-plus.log','089-tomato-plus.log','hw-test.tcl','hw-bench.tcl','hw-flower-test.tcl']:
 files.append(root/'build'/n)
for folder in ['089-hw-final','089-hw-flower','087-redraw-test-C-BIOS_MSX2','087-redraw-test-C-BIOS_MSX2+','085-tomato-C-BIOS_MSX2+']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS:')
 assert not (d/'FAIL.txt').exists() or not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir()if p.is_file())
d=root/'build/089-hw-bench-final';assert len((d/'bench.txt').read_text().splitlines())==4
files.extend(p for p in d.iterdir()if p.is_file())
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive)as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
