#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_combat_bench.py" "$PROJECT_ROOT"
MACHINE="${1:-C-BIOS_MSX2+}"
export KEEN_BENCH_OUT="$PROJECT_ROOT/build/combat-benchmark-$MACHINE${KEEN_BENCH_AMMO:+-stock$KEEN_BENCH_AMMO}.txt"
timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/combat-bench.tcl" > "$PROJECT_ROOT/build/combat-benchmark-$MACHINE${KEEN_BENCH_AMMO:+-stock$KEEN_BENCH_AMMO}.log" 2>&1
test -s "$KEEN_BENCH_OUT"
cat "$KEEN_BENCH_OUT"
