#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.28';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0928.ROM';shutil.copyfile(r/'build/keen_msx.rom',rom)
b=rom.read_bytes();assert len(b)==1048576 and b[:2]==b'AB'
assert b'0.9.28 MELON MINES' in b and b'KEEN 0.9.28 HARDWARE TEST' in b
assert b'0.9.27' not in b
baseline=r.parent/'deliverables/v0.9.27/KEEN0927.ROM'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='d61e1b25968d0ddd4aff7091b86d32cad032af28b5912fb6643c7ddbfccc8fed'
for case in ('campaign-1','campaign-2','campaign-3','bridge_enemy-3','hill-rom','mines-rom','mines-msx2'):
 d=r/'build'/('0928-'+case);assert (d/'PASS.txt').read_text().startswith('PASS:');assert not (d/'FAIL.txt').read_text().strip()
assert 'PASS: complete continuous' in (r/'build/0928-host-hill.log').read_text()
assert '161 original actor/pose' in (r/'build/0928-hill-rom/VERIFIED.txt').read_text()
for case in ('mines-rom','mines-msx2'):
 assert '124 original actor/pose' in (r/'build'/('0928-'+case)/'VERIFIED.txt').read_text()
for name in ('mines','hill','bridge','campaign'):
 assert 'PASS:' in (r/'build'/('0928-host-'+name+'.log')).read_text()
with ZipFile(r.parent/'deliverables/v0.9.27/keen-dreams-msx-0.9.27-rom-source.zip') as z:
 for level in ('scene','bridge','tuberia'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),('Reference level binary changed',p)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ('keen_msx.rom','keen_msx.map','0928-build.log','0928-host-hill.log','0928-host-mines.log','0928-host-bridge.log','0928-host-campaign.log','0928-regression.log','0928-hill-rom.log','0928-mines-rom.log','0928-mines-msx2.log'): 
 p=r/'build'/name
 if p.exists():files.append(p)
for d in (r/'build').glob('0928-*'):
 if d.is_dir() and (d/'PASS.txt').exists():
  files.extend(p for p in d.iterdir() if p.is_file())
files.extend(p for p in (r/'build/core15').iterdir() if p.is_file())
hashtext=hashlib.sha256(b).hexdigest()+'  KEEN0928.ROM\n'
(out/'SHA256.TXT').write_text(hashtext)
archive=out/'keen-dreams-msx-0.9.28-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',hashtext)
with ZipFile(archive) as z:
 assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
 for n in ('src/mines.c','src/mines_spawns.h','src/session.h','src/keen_msx_s50_b1.c','src/keen_msx_s51_b1.c','src/keen_msx_s52_b1.c','assets/melon/aspar.bin','assets/melon/mouth.bin','assets/melon/tater_attack.bin','assets/generated/MAPHEAD.KDR','tests/host/test_mines.c','tests/test_rom28_mines.py','docs/ROM-0928.md'):assert 'keen-msx/'+n in z.namelist()
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
