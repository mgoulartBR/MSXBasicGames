"""Package the validated 0.8.7 ROM, sandbox and current release evidence."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1]
out=root.parent/'deliverables/v0.8.7';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.8.7.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='4a530502772d2b5cf60d5898de769a72346cf2cd3676217fd1456531cab4bb14'
archive=out/'keen-dreams-msx-0.8.7-source.zip'
evidence=['keen_msx.rom','keen_msx.map','087-release-build.log','087-diag-msx2.log','087-diag-plus.log','087-redraw-msx2.log','087-redraw-plus.log','087-pickups-plus.log','087-tomato-plus.log','087-bench-baseline.log','087-bench-candidate.log','087-baseline/keen_msx.rom','087-baseline/keen_msx.map']
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.')for n in rel.parts):continue
 files.append(p)
files += [root/'build'/n for n in evidence]
for folder in ['087-diag-C-BIOS_MSX2','087-diag-C-BIOS_MSX2+','087-redraw-test-C-BIOS_MSX2','087-redraw-test-C-BIOS_MSX2+','087-redraw-pickups-C-BIOS_MSX2+','085-tomato-C-BIOS_MSX2+']:
 d=root/'build'/folder;assert (d/'PASS.txt').read_text().startswith('PASS:') and not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir() if p.is_file() and p.suffix in ['.txt','.vram','.log'])
for folder in ['087-redraw-baseline','087-redraw-candidate']:
 d=root/'build'/folder
 assert len((d/'bench.txt').read_text().splitlines())==4
 files.extend(p for p in d.iterdir() if p.is_file() and p.suffix in ['.txt','.tcl','.log'])
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive)as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
 assert 'keen-msx/src/cart_images.h' in z.namelist()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
