"""Package the validated 0.8.4 ROM, sandbox and current release evidence."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1]
out=root.parent/'deliverables/v0.8.4';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.8.4.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='3ae0296a3857bdb7d05a78133dd0f7b6ad2e11079ea3c9bf87bf9333b85f1678'
archive=out/'keen-dreams-msx-0.8.4-source.zip'
evidence=['keen_msx.rom','keen_msx.map','084-release-build.log','084-before-fix.log','084-enemy-msx2.log','084-enemy-plus.log']
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.')for n in rel.parts):continue
 files.append(p)
files += [root/'build'/n for n in evidence]
for folder in ['084-deep-enemy-C-BIOS_MSX2','084-deep-enemy-C-BIOS_MSX2+']:
 d=root/'build'/folder;assert (d/'PASS.txt').read_text().startswith('PASS:') and not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir() if p.is_file() and (p.suffix in ['.txt','.vram','.map'] or p.name in ['route.log','emulator.log'] or p.name.endswith('-display.png')))
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive)as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
 assert 'keen-msx/src/cart_images.h' in z.namelist()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
