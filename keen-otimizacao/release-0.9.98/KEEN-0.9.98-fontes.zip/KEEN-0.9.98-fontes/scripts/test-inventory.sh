#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_inventory_test.py" "$PROJECT_ROOT"
MACHINE="${1:-C-BIOS_MSX2+}"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/inventory-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
python3 - "$KEEN_TEST_OUTPUT" <<'PY'
from pathlib import Path
import sys
for n in ['PASS.txt','FAIL.txt']:(Path(sys.argv[1])/n).unlink(missing_ok=True)
PY
timeout 45s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/inventory-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
if [[ -f "$KEEN_TEST_OUTPUT/FAIL.txt" ]]; then cat "$KEEN_TEST_OUTPUT/FAIL.txt";exit 1;fi
python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" empty collected thrown later reset | tee "$KEEN_TEST_OUTPUT/pixels.txt"
test -f "$KEEN_TEST_OUTPUT/PASS.txt"
cat "$KEEN_TEST_OUTPUT/PASS.txt"
