#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_world_test.py" "$PROJECT_ROOT"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/world-$MACHINE" KEEN_WORLD_TEST=1
mkdir -p "$KEEN_TEST_OUTPUT"
rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
timeout 45s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/world-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
test -f "$KEEN_TEST_OUTPUT/PASS.txt"
python3 "$PROJECT_ROOT/tests/verify_world_pixels.py" "$KEEN_TEST_OUTPUT" world_spawn entrance completed new_game | tee "$KEEN_TEST_OUTPUT/pixels.txt"
python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" level_spawn second_entry | tee -a "$KEEN_TEST_OUTPUT/pixels.txt"
cat "$KEEN_TEST_OUTPUT/PASS.txt"
