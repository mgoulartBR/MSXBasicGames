#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.29';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0929.ROM';shutil.copyfile(r/'build/keen_msx.rom',rom)
b=rom.read_bytes();assert len(b)==1048576 and b[:2]==b'AB'
assert b'0.9.29 BRIDGE BOTTOMS' in b and b'KEEN 0.9.29 HARDWARE TEST' in b
assert b'0.9.28' not in b
baseline=r.parent/'deliverables/v0.9.28/KEEN0928.ROM'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='c548621a9312720b6c30e49d10214d01b6f0bba0f9ea932ff931a6c56dff90eb'
for case in ('campaign-1','campaign-2','campaign-3','bridge_enemy-3','bridge-rom','bridge-msx2','mines-rom'):
 d=r/'build'/('0929-'+case);assert (d/'PASS.txt').read_text().startswith('PASS:');assert not (d/'FAIL.txt').read_text().strip()
assert 'PASS: complete continuous' in (r/'build/0929-host-hill.log').read_text()
assert '345 calls' in (r/'build/0929-bridge_enemy-3/PASS.txt').read_text()
for case in ('mines-rom',):
 assert '124 original actor/pose' in (r/'build'/('0929-'+case)/'VERIFIED.txt').read_text()
for name in ('mines','hill','bridge','campaign'):
 assert 'PASS:' in (r/'build'/('0929-host-'+name+'.log')).read_text()
with ZipFile(r.parent/'deliverables/v0.9.28/keen-dreams-msx-0.9.28-rom-source.zip') as z:
 for level in ('scene','melon','bridge','tuberia'):
  for p in (r/'assets'/level).glob('*.bin'):
   assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),('Reference level binary changed',p)
for case in ('bridge-rom','bridge-msx2'):
 assert '95 original actor/pose' in (r/'build'/('0929-'+case)/'VERIFIED.txt').read_text()
assert 'ROM verified:' in (r/'build/0929-rom-verification.log').read_text()
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ('keen_msx.rom','keen_msx.map','0929-build.log','0929-host-hill.log','0929-host-mines.log','0929-host-bridge.log','0929-host-campaign.log','0929-regression.log','0929-bridge-rom.log','0929-bridge-msx2.log','0929-mines-rom.log','0929-rom-verification.log'): 
 p=r/'build'/name
 if p.exists():files.append(p)
for d in (r/'build').glob('0929-*'):
 if d.is_dir() and (d/'PASS.txt').exists():
  files.extend(p for p in d.iterdir() if p.is_file())
files.extend(p for p in (r/'build/core15').iterdir() if p.is_file())
hashtext=hashlib.sha256(b).hexdigest()+'  KEEN0929.ROM\n'
(out/'SHA256.TXT').write_text(hashtext)
archive=out/'keen-dreams-msx-0.9.29-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',hashtext)
with ZipFile(archive) as z:
 assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
 for n in ('src/bridge.c','src/bridge_spawns.h','tests/host/test_bridge29.c','tests/make_bridge29_enemy_test.py','tests/test_rom29_bridge.py','src/session.h','src/keen_msx_s50_b1.c','src/keen_msx_s51_b1.c','src/keen_msx_s52_b1.c','assets/melon/aspar.bin','assets/melon/mouth.bin','assets/melon/tater_attack.bin','assets/generated/MAPHEAD.KDR','tests/host/test_mines.c','tests/test_rom28_mines.py','docs/ROM-0929.md'):assert 'keen-msx/'+n in z.namelist()
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
