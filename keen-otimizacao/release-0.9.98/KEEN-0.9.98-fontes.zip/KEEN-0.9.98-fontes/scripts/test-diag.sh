#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_world_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_keydoor_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_diag_test.py" "$PROJECT_ROOT"
export KEEN_WORLD_TEST=1 KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/087-diag-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
python3 - "$KEEN_TEST_OUTPUT" <<'CLEAN'
from pathlib import Path
import sys
d=Path(sys.argv[1]);(d/'PASS.txt').write_text('PENDING\n');(d/'FAIL.txt').write_text('')
CLEAN
timeout 90s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/diag-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
python3 - "$KEEN_TEST_OUTPUT" <<'CHECK'
from pathlib import Path
import sys
d=Path(sys.argv[1]);assert not (d/'FAIL.txt').read_text().strip(),(d/'FAIL.txt').read_text();assert (d/'PASS.txt').read_text().startswith('PASS:')
CHECK
cat "$KEEN_TEST_OUTPUT/PASS.txt"
KEEN_STAGE=2 KEEN_ENEMY_PROFILE=1 python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" mode1 mode2 mode3 mode4 timings counters
KEEN_STAGE=2 python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" inventory
