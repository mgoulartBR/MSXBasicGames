#!/usr/bin/env python3
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.27';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0927.ROM';shutil.copyfile(r/'build/keen_msx.rom',rom)
b=rom.read_bytes();assert len(b)==1048576 and b[:2]==b'AB'
assert b'0.9.27 HORSERADISH HILL' in b and b'KEEN 0.9.27 HARDWARE TEST' in b
assert b'0.9.26' not in b
baseline=r.parent/'deliverables/v0.9.26/KEEN0926.ROM'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='656b77fb279be5723fd202ddcf6b3f357b4ff2858fb80129775faee101a92551'
for case in ('campaign-1','campaign-2','campaign-3','bridge_enemy-3','hill-rom','hill-msx2'):
 d=r/'build'/('0927-'+case);assert (d/'PASS.txt').read_text().startswith('PASS:');assert not (d/'FAIL.txt').read_text().strip()
assert 'PASS: complete continuous' in (r/'build/0927-host-route.log').read_text()
assert '161 original actor/pose' in (r/'build/0927-hill-rom/VERIFIED.txt').read_text()
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ('keen_msx.rom','keen_msx.map','0927-build.log','0927-host-route.log','0927-regression.log','0927-hill-rom.log','0927-hill-msx2.log'): 
 p=r/'build'/name
 if p.exists():files.append(p)
for d in (r/'build').glob('0927-*'):
 if d.is_dir() and (d/'PASS.txt').exists():
  files.extend(p for p in d.iterdir() if p.is_file())
files.extend(p for p in (r/'build/core15').iterdir() if p.is_file())
hashtext=hashlib.sha256(b).hexdigest()+'  KEEN0927.ROM\n'
(out/'SHA256.TXT').write_text(hashtext)
archive=out/'keen-dreams-msx-0.9.27-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',hashtext)
with ZipFile(archive) as z:
 assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
 for n in ('src/hill.c','src/hill_spawns.h','assets/generated/MAPHEAD.KDR','tests/host/test_hill.c','docs/ROM-0927.md'):assert 'keen-msx/'+n in z.namelist()
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
