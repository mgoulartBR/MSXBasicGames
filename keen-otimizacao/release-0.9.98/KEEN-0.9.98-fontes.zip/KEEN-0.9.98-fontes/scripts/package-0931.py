#!/usr/bin/env python3
"""Package only after current-ROM evidence passes; preserve the tested 0.9.30."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.31';out.mkdir(parents=True,exist_ok=True)
b=(r/'build/keen_msx.rom').read_bytes();assert len(b)==1048576 and b[:2]==b'AB'
rom_sha=hashlib.sha256(b).hexdigest()
assert b'0.9.31 PARSNIP PASS' in b and b'KEEN 0.9.31 HARDWARE TEST' in b and b'0.9.30' not in b
for case in ('campaign-1','campaign-2','campaign-3','campaign-4','campaign-5','bridge_enemy-3','pass-rom','pass-msx2'):
 d=r/'build'/('0931-'+case);assert (d/'PASS.txt').read_text().startswith('PASS:');assert not (d/'FAIL.txt').read_text().strip()
for case in ('pass-rom','pass-msx2'):assert 'all 135 fifth-stage' in (r/'build'/('0931-'+case)/'VERIFIED.txt').read_text()
for name in ('0931-pass-rom','0931-pass-msx2','0931-campaign-1','0931-campaign-2','0931-campaign-3','0931-campaign-4','0931-campaign-5','0931-bridge_enemy-3','0929-hill-rom','0929-mines-rom','0929-bridge-rom','0930-rapids-rom'):
 assert (r/'build'/name/'ROM-SHA256.txt').read_text().strip()==rom_sha,name
for n in ('hill','mines','bridge','campaign','rapids','pass'):assert 'PASS:' in (r/'build'/('0931-host-'+n+'.log')).read_text()
for n,count in (('hill',161),('mines',124),('bridge',95)):
 d=r/'build'/('0929-'+n+'-rom');assert (d/'PASS.txt').read_text().startswith('PASS:');assert str(count)+' original actor/pose' in (d/'VERIFIED.txt').read_text();assert not (d/'FAIL.txt').read_text().strip()
assert 'ROM verified:' in (r/'build/0931-build.log').read_text()
assert rom_sha in (r/'build/0931-final-build.log').read_text()
reference=r.parent/'deliverables/v0.9.30'
assert hashlib.sha256((reference/'KEEN0930.ROM').read_bytes()).hexdigest()=='9f22bfcafad0b87c6dcdd164c5e9a111bcdcdd10aec977f0a44df752d3083fc4'
with ZipFile(reference/'keen-dreams-msx-0.9.30-rom-source.zip') as z:
 for level in ('scene','melon','bridge','rapids'):
  for p in (r/'assets'/level).glob('*.bin'):assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p
rom=out/'KEEN0931.ROM';rom.write_bytes(b)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or any(n in ('out','emul','__pycache__') or n.startswith('.') for n in rel.parts):continue
 files.append(p)
for p in (r/'build').glob('0931-*'):
 if p.is_file():files.append(p)
 elif (p/'PASS.txt').exists():files.extend(f for f in p.iterdir() if f.is_file())
assert (r/'build/0930-rapids-rom/VERIFIED.txt').read_text().startswith('PASS:')
for n in ('hill','mines','bridge'):
 d=r/'build'/('0929-'+n+'-rom');files.extend(p for p in d.iterdir() if p.is_file())
files.extend(p for p in (r/'build/0930-rapids-rom').iterdir() if p.is_file())
for n in ('keen_msx.rom','keen_msx.map'):files.append(r/'build'/n)
files.extend(p for p in (r/'build/core15').iterdir() if p.is_file())
archive=out/'keen-dreams-msx-0.9.31-rom-source.zip'
romhash=hashlib.sha256(b).hexdigest()+'  KEEN0931.ROM\n'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',romhash)
with ZipFile(archive) as z:assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
(out/'SHA256-0931.TXT').write_text(romhash+hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
