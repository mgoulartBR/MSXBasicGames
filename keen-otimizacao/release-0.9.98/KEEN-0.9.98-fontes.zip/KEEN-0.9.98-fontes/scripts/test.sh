#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
MACHINE="${1:-C-BIOS_MSX2}"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/game-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
timeout 45s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx \
    -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" \
    -romtype ASCII16 -script "$PROJECT_ROOT/build/game-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
if [[ -f "$KEEN_TEST_OUTPUT/FAIL.txt" ]]; then cat "$KEEN_TEST_OUTPUT/FAIL.txt" >&2; exit 1; fi
test -f "$KEEN_TEST_OUTPUT/PASS.txt"

python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" | tee "$KEEN_TEST_OUTPUT/pixels.txt"
cat "$KEEN_TEST_OUTPUT/PASS.txt"
