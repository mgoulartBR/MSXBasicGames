"""Package the validated 0.9.42 source, ROMs and selected evidence."""
from pathlib import Path
import hashlib,zipfile
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables0942';out.mkdir(exist_ok=True)
rom=r/'build/keen_msx.rom'
assert rom.read_bytes()==(out/'KEEN0942.ROM').read_bytes()
checks=['0942-pass-rom/VERIFIED.txt','0942-boss-pixels-rom/VERIFIED.txt','0942-boss-pixels-msx2/VERIFIED.txt','0942-title/PASS.txt','0942-title/PIXELS-PASS.txt','0942-exit-C-BIOS_MSX2+/PIXELS-PASS.txt','0942-exit-C-BIOS_MSX2/PIXELS-PASS.txt','0942-finale-C-BIOS_MSX2+-1/PIXELS-PASS.txt','0942-finale-C-BIOS_MSX2-12/PIXELS-PASS.txt']
for name in checks:assert (r/'build'/name).read_text().startswith('PASS:'),name
host=(r/'build/0942-host-suite.log').read_text();assert host.count(' PASS')==13,host
assert '1246' in (r/'build/0942-exits.log').read_text()
(out/'README-0.9.42.txt').write_bytes((r/'README-0.9.42.txt').read_bytes())
zpath=out/'keen-dreams-msx-0.9.42-rom-source.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in ['KEEN0942.ROM','K942B1.ROM','SHA256.txt','README-0.9.42.txt']:z.write(out/n,n)
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(r)
  if any(n in rel.parts for n in ['out','__pycache__','.git']):continue
  if rel.parts[0]=='build':continue
  if p.name.endswith(('.pyc','.tmp')):continue
  z.write(p,'keen-msx/'+str(rel))
 evidence=['keen_msx.rom','keen_msx.map','0942-clean-build.log','0942-host-suite.log','0942-exits.log','0942-performance.json','0942-pass-native.log','0942-boss-pixels.log','0942-finale-final.log']
 for n in evidence:z.write(r/'build'/n,'keen-msx/build/'+n)
 for folder in ['0942-pass-rom','0942-boss-pixels-rom','0942-boss-pixels-msx2','0942-exit-C-BIOS_MSX2+','0942-exit-C-BIOS_MSX2','0942-finale-C-BIOS_MSX2+-1','0942-finale-C-BIOS_MSX2-12','0942-title']:
  for p in (r/'build'/folder).iterdir():
   if p.is_file() and (p.suffix in ['.txt','.vram','.map','.palette','.regs'] or p.name=='complete.png' or p.name.startswith('finale-') and p.suffix=='.png'):
    if p.name=='FAIL.txt':assert not p.read_text().strip();continue
    z.write(p,'keen-msx/build/'+folder+'/'+p.name)
 with_meta='\n'.join(f'{hashlib.sha256((out/n).read_bytes()).hexdigest()}  {n}'for n in ['KEEN0942.ROM','K942B1.ROM'])+'\n'
 assert with_meta==(out/'SHA256.txt').read_text()
with zipfile.ZipFile(zpath)as z:assert z.testzip() is None
print('PASS:',zpath,zpath.stat().st_size,'bytes')
