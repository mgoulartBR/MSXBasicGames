"""Package the hardware Keen / bitmap enemies experiment and its evidence."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.2';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.2-platform-fix.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='d214e64d92929d58e321937caa632c000b47a8769e7aa75033d805621aa6f43e'
archive=out/'keen-dreams-msx-0.9.2-source.zip';files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','092-release-build.log','092-rom-verify.log','092-redraw.log','092-poles.log','092-atlas.log','hero-test.tcl','hero-transition-test.tcl','092-baseline/keen_msx.map']:
 files.append(root/'build'/n)
for folder in ['092-hero-plus','092-hero-msx2','092-transitions','092-redraw-test-C-BIOS_MSX2+','pole-limits']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS')
 assert not (d/'FAIL.txt').exists() or not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir() if p.is_file())
for scene in ['pole','melon']:
 for variant in ['', 'draw-']:
  for tag in ['old','new']:
   d=root/'build'/f'092-{scene}-{variant}{tag}'
   assert len((d/'bench.txt').read_text().splitlines())==4
   files.extend(p for p in d.iterdir() if p.is_file())
   files.append(root/'build'/f'platform-{scene}-{variant}{tag}.tcl')
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
