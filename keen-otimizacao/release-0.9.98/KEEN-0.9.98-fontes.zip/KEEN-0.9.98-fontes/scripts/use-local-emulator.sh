#!/usr/bin/env bash
# Source this file when using the optional locally extracted Ubuntu runtime.
KEEN_PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KEEN_RUNTIME="$(dirname "$KEEN_PROJECT_ROOT")/emulator-runtime"
if [[ -x "$KEEN_RUNTIME/usr/bin/openmsx" ]]; then
    # The extracted distribution may lack the system-wide C-BIOS symlinks.
    if [[ -d "$KEEN_RUNTIME/usr/share/cbios" && ! -f "$KEEN_RUNTIME/usr/share/openmsx/systemroms/cbios_sub.rom" ]]; then
        cp "$KEEN_RUNTIME"/usr/share/cbios/*.rom "$KEEN_RUNTIME/usr/share/openmsx/systemroms/"
    fi
    export PATH="$KEEN_RUNTIME/usr/bin:$PATH"
    export LD_LIBRARY_PATH="$KEEN_RUNTIME/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    export OPENMSX_SYSTEM_DATA="$KEEN_RUNTIME/usr/share/openmsx"
    export TCL_LIBRARY="$KEEN_RUNTIME/usr/share/tcltk/tcl8.6"
fi
