"""Package the hardware Keen / bitmap enemies experiment and its evidence."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.1';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.1-hardware-keen.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='837a5acd5ac410ceb579fd898dbca4c6efe30dfcf3e460e258a06467afe8a906'
archive=out/'keen-dreams-msx-0.9.1-source.zip';files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','091-release-build.log','091-redraw.log','091-poles.log','091-atlas.log','hero-test.tcl','hero-transition-test.tcl','hero-bench-old.tcl','hero-bench-new.tcl','090-baseline/keen_msx.map']:
 files.append(root/'build'/n)
for folder in ['091-hero-plus','091-hero-msx2','091-transitions','087-redraw-test-C-BIOS_MSX2+','pole-limits']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS')
 assert not (d/'FAIL.txt').exists() or not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir() if p.is_file() and p.name!='probe.txt')
for folder in ['091-bench-old','091-bench-new']:
 d=root/'build'/folder;assert len((d/'bench.txt').read_text().splitlines())==4
 files.extend(p for p in d.iterdir() if p.is_file())
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
