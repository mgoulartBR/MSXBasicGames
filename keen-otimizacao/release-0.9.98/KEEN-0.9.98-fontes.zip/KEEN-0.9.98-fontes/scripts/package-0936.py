#!/usr/bin/env python3
"""Package current tested ROM and evidence; leave 0.9.34 untouched."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.36';out.mkdir(parents=True,exist_ok=True)
b=(r/'build/keen_msx.rom').read_bytes();digest=hashlib.sha256(b).hexdigest()
assert len(b)==2097152 and b[:2]==b'AB' and b'0.9.36 SQUASH SWAMP' in b and b'KEEN 0.9.36 HARDWARE TEST' in b
cases=['0936-swamp-rom','0936-swamp-msx2','0935-bay-rom','0935-bay-msx2','0934-grove-rom','0934-grove-msx2','0933-apple-rom','0933-apple-msx2','0932-city-rom','0932-city-msx2','0931-pass-rom','0929-hill-rom','0929-mines-rom','0929-bridge-rom','0930-rapids-rom']+['0936-campaign-%d'%i for i in range(1,11)]+['0936-bridge_enemy-3']
for case in cases:
 p=r/'build'/case;assert (p/'PASS.txt').read_text().startswith('PASS:'),case
 assert not (p/'FAIL.txt').read_text().strip(),case
 assert (p/'ROM-SHA256.txt').read_text().strip()==digest,case
for case in ('0936-swamp-rom','0936-swamp-msx2'):
 assert 'all 67 tenth-stage' in (r/'build'/case/'VERIFIED.txt').read_text()
for name in ('hill','mines','bridge29','rapids','pass','city','apple','grove','bay','swamp','campaign'):
 assert 'PASS:' in (r/'build'/('0936-host-'+name+'.log')).read_text(),name
assert '140 unchanged previous-stage binaries' in (r/'build/0936-source-audit.log').read_text()
assert hashlib.sha256((r.parent/'deliverables/v0.9.35/KEEN0935.ROM').read_bytes()).hexdigest()=='4a1fdeca1d0e6d4d7b59b0f7cb039af3f8b3eee6942a0dd73a94e325720144bc'
assert digest in (r/'build/0936-final-build.log').read_text()
rom=out/'KEEN0936.ROM';rom.write_bytes(b)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or any(n in ('out','emul','__pycache__') or n.startswith('.') for n in rel.parts):continue
 files.append(p)
for case in cases:
 files.extend(p for p in (r/'build'/case).iterdir() if p.is_file() and "trace" not in p.name)
files.extend(p for p in (r/'build').glob('0936-*.log')if p.is_file() and 'regression-campaign' not in p.name)
files.extend(p for p in (r/'build/core15').iterdir()if p.is_file())
files.extend(r/'build'/n for n in ('keen_msx.rom','keen_msx.map'))
archive=out/'keen-dreams-msx-0.9.36-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',digest+'  KEEN0936.ROM\n')
with ZipFile(archive)as z:assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
(out/'SHA256-0936.TXT').write_text(digest+'  KEEN0936.ROM\n'+hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
