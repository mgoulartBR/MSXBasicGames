#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_world_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_world_scroll_test.py" "$PROJECT_ROOT"
export KEEN_WORLD_TEST=1 KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/world-scroll-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
timeout 35s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/world-scroll-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
test -f "$KEEN_TEST_OUTPUT/PASS.txt"
python3 - "$PROJECT_ROOT" "$KEEN_TEST_OUTPUT" <<'PY'
from pathlib import Path
import subprocess,sys,statistics
root,out=map(Path,sys.argv[1:]);times=list(map(float,(out/'timing.txt').read_text().split()))
names=['scroll'+str(i) for i in range(1,len(times)+1)]
result=subprocess.run([sys.executable,str(root/'tests/verify_world_pixels.py'),str(out),*names],text=True,capture_output=True)
(out/'pixels.txt').write_text(result.stdout+result.stderr)
assert result.returncode==0,result.stdout+result.stderr
frames=[tuple(map(int,(out/(n+'.txt')).read_text().split())) for n in names]
assert any(f[3]%16 for f in frames),'Horizontal camera never used fine positions'
assert any(f[4]%16 for f in frames),'Vertical camera never used fine positions'
# Frame intervals include direction changes and stops; not a monitor refresh rate.
d=[b-a for a,b in zip(times,times[1:]) if b<15.0]
summary=f'{len(times)} presented frames verified; median interval {statistics.median(d)*1000:.1f} ms, maximum {max(d)*1000:.1f} ms. Fine X/Y camera positions verified.\n'
(out/'summary.txt').write_text(summary);print(summary)
PY
cat "$KEEN_TEST_OUTPUT/PASS.txt"
