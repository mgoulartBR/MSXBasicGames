#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
FREQ="${1:-3579545}"
MODE="${2:-profile}"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/088-profile-$FREQ"
if [ "$MODE" = control ]; then export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/088-profile-control-$FREQ"; fi
mkdir -p "$KEEN_TEST_OUTPUT"
: > "$KEEN_TEST_OUTPUT/profile.txt"
: > "$KEEN_TEST_OUTPUT/bench.txt"
python3 "$PROJECT_ROOT/tests/make_vdp_profile.py" "$PROJECT_ROOT" "$KEEN_TEST_OUTPUT/profile.tcl" "$FREQ" "$MODE"
timeout 90s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine C-BIOS_MSX2+ -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$KEEN_TEST_OUTPUT/profile.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
python3 - "$KEEN_TEST_OUTPUT/profile.txt" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text();assert sum(x.startswith('SCENE ') for x in s.splitlines())==5,s
print(s)
PY
