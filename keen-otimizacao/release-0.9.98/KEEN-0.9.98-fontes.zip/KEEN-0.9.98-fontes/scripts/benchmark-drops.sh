#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
BENCH_ROOT="${1:-$PROJECT_ROOT/build}"
python3 "$PROJECT_ROOT/tests/make_drop_bench.py" "$BENCH_ROOT/keen_msx.map" "$BENCH_ROOT/drop-bench.tcl"
export KEEN_BENCH_OUT="$BENCH_ROOT/drop-bench.txt"
timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine C-BIOS_MSX2+ -cart "$BENCH_ROOT/keen_msx.rom" -romtype ASCII16 -script "$BENCH_ROOT/drop-bench.tcl" > "$BENCH_ROOT/drop-bench.log" 2>&1
python3 - "$BENCH_ROOT" <<'PY'
import json,sys,statistics
from pathlib import Path
p=Path(sys.argv[1]);rows=[list(map(int,s.split(','))) for s in (p/'drop-bench.txt').read_text().splitlines()[1:]]
r=[x for x in rows if x[2]>0] # Downward scrolling, excluding launch/idle gaps.
assert len(r)>=12, 'Not enough descending frames'
v=sorted(x[0] for x in r);d=dict(descending_frames=len(r),median_video_frames=statistics.median(v),p95_video_frames=v[(95*len(v)+99)//100-1],worst_video_frames=max(v),mean_edges_video_frames=statistics.mean(x[3]for x in r),max_camera_step=max(x[2]for x in r))
d['descending_full_redraws']=sum(max(0,c[7]-a[7]) for a,c in zip(rows,rows[1:]) if c[2]>0)
(p/'drop-summary.json').write_text(json.dumps(d,indent=2));print(json.dumps(d,indent=2))
PY
