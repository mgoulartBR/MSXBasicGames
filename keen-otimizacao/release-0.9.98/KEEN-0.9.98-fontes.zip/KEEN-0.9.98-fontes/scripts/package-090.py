"""Package the first-stage hardware-only Carrot experiment and its evidence."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.0';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.0-hardware-carrot.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='ce9253fef74ecca031b1707981cad0540951626112498d1be4854dab8c93f4c0'
archive=out/'keen-dreams-msx-0.9.0-source.zip';files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','090-release-build.log','090-redraw.log','carrot-test.tcl','carrot-flower-test.tcl','carrot-bench-old.tcl','carrot-bench-new.tcl','090-baseline/keen_msx.map']:
 files.append(root/'build'/n)
for folder in ['090-carrot','090-carrot-msx2','090-flower','087-redraw-test-C-BIOS_MSX2+']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS:')
 assert not (d/'FAIL.txt').exists() or not (d/'FAIL.txt').read_text().strip()
 files.extend(p for p in d.iterdir() if p.is_file())
for folder in ['090-bench-old','090-bench-new']:
 d=root/'build'/folder;assert len((d/'bench.txt').read_text().splitlines())==4
 files.extend(p for p in d.iterdir() if p.is_file())
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
