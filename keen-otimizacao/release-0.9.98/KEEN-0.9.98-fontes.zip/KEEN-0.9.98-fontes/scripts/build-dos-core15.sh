#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
sdcc="${MSXGL_ROOT:-$root/../deps/MSXgl}/tools/sdcc/bin/sdcc"
mkdir -p "$root/build/dos"
"$sdcc" -L"$(dirname "$sdcc")/../lib/z80" -mz80 --no-std-crt0 --code-loc 0x0100 --data-loc 0x6000 --opt-code-speed "$root/dos/kcore15.c" -o "$root/build/dos/kcore15.ihx"
python3 - "$root/build/dos" <<'PY'
from pathlib import Path
import sys,hashlib,re
p=Path(sys.argv[1]);data={}
for line in (p/'kcore15.ihx').read_text().splitlines():
 b=bytes.fromhex(line[1:]);assert sum(b)%256==0
 if b[3]==0:
  start=int.from_bytes(b[1:3],'big')
  for i,v in enumerate(b[4:4+b[0]]):data[start+i]=v
symbols={n:int(v,16) for v,n in re.findall(r'^\s+([0-9A-F]{8})\s+([sl]__\w+)\s*$',(p/'kcore15.map').read_text(),re.M)}
assert symbols['s__DATA']==0x6000 and symbols['s__DATA']+symbols['l__DATA']<0x7000
assert min(data)==0x100 and max(data)<0x6000
blob=bytes(data.get(i,0) for i in range(0x100,max(data)+1))
assert blob.count((p.parent/'core15/CORE15.BIN').read_bytes())==1, 'Shared payload differs'
assert blob[0]==0xcd and blob[3:6]==b'\xc3\x00\x00'
(p/'KCORE15.COM').write_bytes(blob)
print('DOS COM verified:',len(blob),'bytes; SHA256',hashlib.sha256(blob).hexdigest())
PY
