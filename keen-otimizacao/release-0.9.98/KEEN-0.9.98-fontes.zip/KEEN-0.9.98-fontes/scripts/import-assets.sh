#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ $# -ne 1 ]]; then echo "Usage: $0 /path/to/keendreams.zip" >&2; exit 2; fi
python3 "$PROJECT_ROOT/tools/import_ega.py" "$1" \
    --upstream "$PROJECT_ROOT/../upstream/keen" --output "$PROJECT_ROOT/assets/generated"
python3 "$PROJECT_ROOT/tools/build_scene.py"

python3 "$PROJECT_ROOT/tools/build_scroll.py"

python3 "$PROJECT_ROOT/tools/build_combat_assets.py"

python3 "$PROJECT_ROOT/tools/build_pickups.py"

python3 "$PROJECT_ROOT/tools/build_features.py"

python3 "$PROJECT_ROOT/tools/build_tuberia.py"

python3 "$PROJECT_ROOT/tools/build_world_header.py"

python3 "$PROJECT_ROOT/tools/build_stages.py"

python3 "$PROJECT_ROOT/tools/build_cart.py"

python3 "$PROJECT_ROOT/tools/build_keydoor.py"
