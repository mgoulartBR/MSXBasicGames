#!/usr/bin/env bash
# The playable combat path now starts with collecting ammunition.
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
exec bash "$PROJECT_ROOT/scripts/test-inventory.sh" "${1:-C-BIOS_MSX2+}"
