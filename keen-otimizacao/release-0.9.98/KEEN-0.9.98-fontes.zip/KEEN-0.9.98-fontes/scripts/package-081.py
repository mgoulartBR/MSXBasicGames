"""Package the validated 0.8.1 ROM, sandbox and current release evidence."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1]
out=root.parent/'deliverables/v0.8.1';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.8.1.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='c7c928c00b16202d31f486c4a07f4932ff35bf5d761a09a3f4df710e29fb677e'
archive=out/'keen-dreams-msx-0.8.1-source.zip'
evidence=['keen_msx.rom','keen_msx.map','081-release-build.log','081-route-msx2.log','081-route-plus.log','081-carts-msx2.log','081-carts-plus.log','081-hh-regression.log']
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.')for n in rel.parts):continue
 files.append(p)
files += [root/'build'/n for n in evidence]
for folder in ['melon-route-C-BIOS_MSX2','melon-route-C-BIOS_MSX2+','carts-C-BIOS_MSX2','carts-C-BIOS_MSX2+']:
 d=root/'build'/folder;assert (d/'PASS.txt').is_file() and not (d/'FAIL.txt').exists()
 files.extend(p for p in d.iterdir() if p.is_file() and (p.suffix in ['.txt','.vram','.map'] or p.name in ['route.log','emulator.log'] or p.name.endswith('-display.png')))
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive)as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
 assert 'keen-msx/src/cart_images.h' in z.namelist()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
