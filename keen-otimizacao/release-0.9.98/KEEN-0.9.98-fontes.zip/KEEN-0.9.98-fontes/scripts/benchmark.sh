#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tests/make_scroll_bench.py" "$PROJECT_ROOT"
MACHINE="${1:-C-BIOS_MSX2}"
export KEEN_BENCH_OUT="$PROJECT_ROOT/build/benchmark-$MACHINE.txt"
timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/scroll-bench-current.tcl" > "$PROJECT_ROOT/build/benchmark-$MACHINE.log" 2>&1
cat "$KEEN_BENCH_OUT"
