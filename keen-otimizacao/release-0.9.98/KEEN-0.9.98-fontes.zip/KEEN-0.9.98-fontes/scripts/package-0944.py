"""Package only final 0.9.44 sources, ROMs and successful validations."""
from pathlib import Path
import hashlib,zipfile,json
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables0944';audit=r.parent/'audit0944'
sha=hashlib.sha256((r/'build/keen_msx.rom').read_bytes()).hexdigest()
assert sha=='9f7ee8627145006695c1da658bfa4823346d8473d577dc9eaceccf164138babe'
assert (out/'KEEN0944.ROM').read_bytes()==(r/'build/keen_msx.rom').read_bytes()
assert sha in (r/'build/0944-build.log').read_text()
assert (r/'build/0944-host.log').read_text().count(' PASS')==13
assert '1246' in (r/'build/0944-exits.log').read_text()
assert (r/'build/0944-assets.log').read_text().startswith('PASS: 83')
folders=['0943-mines-rom','0943-mines-msx2','0943-pass-rom','0943-city-rom','0943-apple-rom','0943-grove-rom','0943-bay-rom','0943-swamp-rom','0943-castle-rom','0943-boss-pixels-rom','0943-boss-pixels-msx2','0943-hud-cache-C-BIOS_MSX2+','0943-hud-cache-C-BIOS_MSX2','0943-finale-C-BIOS_MSX2+-12','0943-exit-C-BIOS_MSX2+','0943-exit-C-BIOS_MSX2','0944-hybrid','0944-hybrid-3x']
for folder in folders:
 p=r/'build'/folder
 assert (p/'PASS.txt').read_text().startswith('PASS:'),folder
 if (p/'FAIL.txt').exists():assert not(p/'FAIL.txt').read_text().strip(),folder
 if (p/'ROM-SHA256.txt').exists():assert (p/'ROM-SHA256.txt').read_text().strip()==sha,folder
 if folder.startswith('0943-exit-') or folder.startswith('0943-finale-'):assert (p/'PIXELS-PASS.txt').read_text().startswith('PASS:'),folder
for hz,case in [(10738635,'separate'),(10738635,'stacked'),(3579545,'separate')]:
 assert json.loads((audit/f'keen0944-{hz}-{case}/metrics.json').read_text())['sha256']==sha
validation='PASS: full build; unchanged persistent RAM end EFFF; 13 host suites; 1246 exit-sign checks; 83 unchanged packaged assets; 1028 independent bitmap/HUD captures across tested stages and platforms; 120 hardware-pose pixel checks and 12 selector fixtures; boss finale and centered exit screens; native direct-start test ROMs on MSX2 and MSX2+.\nNormal ROM SHA256: '+sha+'\nExisting regression folder names retain the 0943 prefix; included captures were generated with the final 0944 ROM.\n'
(out/'VALIDACAO-0944.txt').write_text(validation)
zpath=out/'keen-dreams-msx-0.9.44-rom-source.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['KEEN0944.ROM','K944T3.ROM','K943T3.ROM','SHA256.txt','SHA256-normal.txt','README-0.9.44.txt','VALIDACAO-0944.txt','build_tomatoes_direct.py','test_tomatoes_direct.py','test_tomatoes_baseline.py']:z.write(out/name,name)
 for p in sorted(r.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(r)
  if rel.parts[0] in ['build','emul'] or any(n in rel.parts for n in ['out','__pycache__','.git']):continue
  if p.suffix in ['.log','.pyc','.tmp']:continue
  z.write(p,'keen0944/'+str(rel))
 for p in sorted((r/'build').glob('0944-*.log')):z.write(p,'keen0944/build/'+p.name)
 for name in ['keen_msx.rom','keen_msx.map']:z.write(r/'build'/name,'keen0944/build/'+name)
 for folder in folders:
  for p in sorted((r/'build'/folder).iterdir()):
   if not p.is_file() or p.name in ['FAIL.txt','cachetrace.txt','uploads.txt','fire-log.txt']:continue
   if p.suffix in ['.txt','.vram','.map','.palette','.regs','.tcl','.json']:z.write(p,'keen0944/build/'+folder+'/'+p.name)
 for p in sorted(audit.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.name=='baseline-mines-validation.log':continue
  z.write(p,'audit0944/'+str(p.relative_to(audit)))
 for folder in ['tomatoes-direct-C-BIOS_MSX2plus','tomatoes-direct-C-BIOS_MSX2','tomatoes-baseline-C-BIOS_MSX2plus','tomatoes-baseline-C-BIOS_MSX2']:
  assert (out/folder/'PASS.txt').read_text().startswith('PASS:'),folder
  for p in (out/folder).iterdir():
   if p.is_file() and p.suffix in ['.txt','.tcl','.regs','.vram']:z.write(p,'direct-tests/'+folder+'/'+p.name)
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
print('PASS:',zpath,zpath.stat().st_size,'bytes')
