#!/usr/bin/env python3
"""Package current tested ROM and evidence; leave 0.9.33 untouched."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.34';out.mkdir(parents=True,exist_ok=True)
b=(r/'build/keen_msx.rom').read_bytes();digest=hashlib.sha256(b).hexdigest()
assert len(b)==1048576 and b[:2]==b'AB' and b'0.9.34 GRAPE GROVE' in b and b'KEEN 0.9.34 HARDWARE TEST' in b
cases=['0934-grove-rom','0934-grove-msx2','0933-apple-rom','0933-apple-msx2','0932-city-rom','0932-city-msx2','0931-pass-rom','0929-hill-rom','0929-mines-rom','0929-bridge-rom','0930-rapids-rom']+['0934-campaign-%d'%i for i in range(1,9)]+['0934-bridge_enemy-3']
for case in cases:
 p=r/'build'/case;assert (p/'PASS.txt').read_text().startswith('PASS:'),case
 assert not (p/'FAIL.txt').read_text().strip(),case
 assert (p/'ROM-SHA256.txt').read_text().strip()==digest,case
for case in ('0934-grove-rom','0934-grove-msx2'):
 assert 'all 168 eighth-stage' in (r/'build'/case/'VERIFIED.txt').read_text()
for name in ('hill','mines','bridge29','rapids','pass','city','apple','grove','campaign'):
 assert 'PASS:' in (r/'build'/('0934-host-'+name+'.log')).read_text(),name
assert '98 unchanged previous-stage binaries' in (r/'build/0934-source-audit.log').read_text()
assert hashlib.sha256((r.parent/'deliverables/v0.9.33/KEEN0933.ROM').read_bytes()).hexdigest()=='835b6fce4a9c35c4c7c91884884d32bb188d153cd33329fca250e62f19636fad'
assert digest in (r/'build/0934-final-build.log').read_text()
rom=out/'KEEN0934.ROM';rom.write_bytes(b)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or any(n in ('out','emul','__pycache__') or n.startswith('.') for n in rel.parts):continue
 files.append(p)
for case in cases:
 files.extend(p for p in (r/'build'/case).iterdir() if p.is_file())
files.extend(p for p in (r/'build').glob('0934-*.log')if p.is_file())
files.extend(p for p in (r/'build/core15').iterdir()if p.is_file())
files.extend(r/'build'/n for n in ('keen_msx.rom','keen_msx.map'))
archive=out/'keen-dreams-msx-0.9.34-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',digest+'  KEEN0934.ROM\n')
with ZipFile(archive)as z:assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
(out/'SHA256-0934.TXT').write_text(digest+'  KEEN0934.ROM\n'+hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
