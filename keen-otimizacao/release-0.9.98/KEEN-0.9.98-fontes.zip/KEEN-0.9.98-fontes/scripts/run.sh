#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
exec openmsx -machine "${1:-C-BIOS_MSX2}" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16
