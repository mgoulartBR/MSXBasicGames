from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.13';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0913.ROM';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ['keen_msx.rom','keen_msx.map','0913-build.log']:files.append(root/'build'/name)
for d in (root/'build').glob('0913-*'):
 if d.is_dir():files.extend(p for p in d.iterdir() if p.is_file() and p.suffix!='.rom')
for name in ['z80-rom','z80-ram','fast-rom','fast-ram']:
 result=(root/'build'/('0913-'+name)/'result.txt').read_text()
 assert 'done 1' in result and 'hot_ok 1' in result and 'simulation_ticks 700' in result
 assert 'shots_fired 8' in result and 'flower_hits 1' in result
b=rom.read_bytes()
assert b[:16384]==b[46*16384:47*16384]
archive=out/'keen-dreams-msx-0.9.13-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
