from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.9';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN099.ROM';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ['keen_msx.rom','keen_msx.map','099-build.log']:files.append(root/'build'/name)
for name in ['099-plus','099-msx2','099-lowram','099-badbank','099-cpu']:
 d=root/'build'/name
 if name in ['099-plus','099-msx2']:assert (d/'result.txt').read_text().startswith('PASS')
 if name=='099-cpu':
  for n in ['r800','ocm-preserve','ocm-enable']:assert (d/(n+'.txt')).read_text().startswith('PASS')
 files.extend(p for p in d.iterdir() if p.is_file() and p.suffix!='.rom')
archive=out/'keen-dreams-msx-0.9.9-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
