#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
BENCH_ROOT="${2:-$PROJECT_ROOT/build}"
python3 "$PROJECT_ROOT/tests/make_load_matrix.py" "$BENCH_ROOT/keen_msx.map" "$BENCH_ROOT/load-matrix.tcl"
mkdir -p "$BENCH_ROOT/loads-$MACHINE"
for KEEN_LOAD_CASE in {0..7}; do
 export KEEN_LOAD_CASE KEEN_BENCH_OUT="$BENCH_ROOT/loads-$MACHINE/case$KEEN_LOAD_CASE.txt"
 timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$BENCH_ROOT/keen_msx.rom" -romtype ASCII16 -script "$BENCH_ROOT/load-matrix.tcl" > "$BENCH_ROOT/loads-$MACHINE/case$KEEN_LOAD_CASE.log" 2>&1
done
python3 - "$BENCH_ROOT/loads-$MACHINE" <<'PY'
from pathlib import Path
import statistics,sys,json
p=Path(sys.argv[1]);results=[]
for i in range(8):
 lines=(p/f'case{i}.txt').read_text().splitlines();r=[list(map(int,s.split(',')))for s in lines[1:]if ','in s]
 results.append(dict(case=i,enemy=bool(i&1),pickups=bool(i&2),jump=bool(i&4),renders=len(r),window_frames=240,fps=len(r)/4,mean_interval=statistics.mean(x[0]for x in r),worst=max(x[0]for x in r),enemy_frames=sum(x[3]!=0 for x in r),pickup_frames=sum(x[4]!=0 for x in r),vertical_frames=sum(x[2]!=0 for x in r),outcome=lines[-1]))
text=json.dumps(results,indent=2);(p/'summary.json').write_text(text);print(text)
PY
