#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
python3 "$PROJECT_ROOT/tests/test_ocm_cpu.py"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_enemy_mode_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_scroll_stress.py" "$PROJECT_ROOT"
for CASE in enemy-mode scroll-stress; do
 export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/ocm-$CASE"
 mkdir -p "$KEEN_TEST_OUTPUT"
 rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
 if [[ "$CASE" == enemy-mode ]]; then SCRIPT=enemy-mode-test; else SCRIPT=scroll-stress; fi
 timeout 30s openmsx -machine C-BIOS_MSX2+ -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/tests/ocm_fixture.tcl" -script "$PROJECT_ROOT/build/$SCRIPT.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
 if [[ "$CASE" == enemy-mode ]]; then
  test -f "$KEEN_TEST_OUTPUT/PASS.txt"
  NAMES=(normal frozen invisible neither restored)
 else
  NAMES=();for ((i=60;i>=1;--i)); do NAMES+=("stress$i"); done
 fi
 if [[ "$CASE" == enemy-mode ]]; then
  KEEN_ENEMY_PROFILE=1 python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" "${NAMES[@]}" | tee "$KEEN_TEST_OUTPUT/pixels.txt"
 else
  python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" "${NAMES[@]}" | tee "$KEEN_TEST_OUTPUT/pixels.txt"
 fi
done
