#!/usr/bin/env python3
"""Package only after current-ROM evidence passes; preserve the tested 0.9.29."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.30';out.mkdir(parents=True,exist_ok=True)
b=(r/'build/keen_msx.rom').read_bytes();assert len(b)==1048576 and b[:2]==b'AB'
assert b'0.9.30 RHUBARB RAPIDS' in b and b'KEEN 0.9.30 HARDWARE TEST' in b and b'0.9.29' not in b
for case in ('campaign-1','campaign-2','campaign-3','campaign-4','bridge_enemy-3','rapids-rom','rapids-msx2'):
 d=r/'build'/('0930-'+case);assert (d/'PASS.txt').read_text().startswith('PASS:');assert not (d/'FAIL.txt').read_text().strip()
for case in ('rapids-rom','rapids-msx2'):assert 'all 133 fourth-stage' in (r/'build'/('0930-'+case)/'VERIFIED.txt').read_text()
for n in ('hill','mines','bridge','campaign','rapids'):assert 'PASS:' in (r/'build'/('0930-host-'+n+'.log')).read_text()
for n,count in (('hill',161),('mines',124),('bridge',95)):
 d=r/'build'/('0929-'+n+'-rom');assert (d/'PASS.txt').read_text().startswith('PASS:');assert str(count)+' original actor/pose' in (d/'VERIFIED.txt').read_text();assert not (d/'FAIL.txt').read_text().strip()
assert 'ROM verified:' in (r/'build/0930-build.log').read_text()
reference=r.parent/'restored-reference'/'Desenvolvimento MSX — MSXGL'
assert hashlib.sha256((reference/'KEEN0929.ROM').read_bytes()).hexdigest()=='7d2aad4836ef4f57216eb814f08462d1fb67c3eda8b23476841fbe52140cebdc'
with ZipFile(reference/'keen-dreams-msx-0.9.29-rom-source.zip') as z:
 for level in ('scene','melon','bridge'):
  for p in (r/'assets'/level).glob('*.bin'):assert p.read_bytes()==z.read('keen-msx/'+p.relative_to(r).as_posix()),p
rom=out/'KEEN0930.ROM';rom.write_bytes(b)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or any(n in ('out','emul','__pycache__') or n.startswith('.') for n in rel.parts):continue
 files.append(p)
for p in (r/'build').glob('0930-*'):
 if p.is_file():files.append(p)
 elif (p/'PASS.txt').exists():files.extend(f for f in p.iterdir() if f.is_file())
for n in ('hill','mines','bridge'):
 d=r/'build'/('0929-'+n+'-rom');files.extend(p for p in d.iterdir() if p.is_file())
for n in ('keen_msx.rom','keen_msx.map'):files.append(r/'build'/n)
files.extend(p for p in (r/'build/core15').iterdir() if p.is_file())
archive=out/'keen-dreams-msx-0.9.30-rom-source.zip'
romhash=hashlib.sha256(b).hexdigest()+'  KEEN0930.ROM\n'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',romhash)
with ZipFile(archive) as z:assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
(out/'SHA256-0930.TXT').write_text(romhash+hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
