#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
TAG="${1:-candidate}"
ROM="$PROJECT_ROOT/build/keen_msx.rom"
MAP="$PROJECT_ROOT/build/keen_msx.map"
if [ "$TAG" = baseline ]; then ROM="$PROJECT_ROOT/build/087-baseline/keen_msx.rom"; MAP="$PROJECT_ROOT/build/087-baseline/keen_msx.map"; fi
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/087-redraw-$TAG"
mkdir -p "$KEEN_TEST_OUTPUT"
: > "$KEEN_TEST_OUTPUT/bench.txt"
python3 "$PROJECT_ROOT/tests/make_redraw_bench.py" "$PROJECT_ROOT" "$MAP" "$KEEN_TEST_OUTPUT/bench.tcl"
timeout 90s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine C-BIOS_MSX2+ -cart "$ROM" -romtype ASCII16 -script "$KEEN_TEST_OUTPUT/bench.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
python3 - "$KEEN_TEST_OUTPUT/bench.txt" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text();assert len(s.splitlines())==4,s;print(s)
PY
