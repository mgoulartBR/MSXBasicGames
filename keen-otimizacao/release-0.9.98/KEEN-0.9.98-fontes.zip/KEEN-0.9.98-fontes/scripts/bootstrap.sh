#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BASE="$(dirname "$PROJECT_ROOT")"
fetch() {
    local url="$1" dest="$2" revision="$3"
    if [[ ! -d "$dest/.git" ]]; then
        git clone "$url" "$dest"
    fi
    if [[ "$(git -C "$dest" rev-parse HEAD)" != "$revision" ]]; then
        if [[ -n "$(git -C "$dest" status --porcelain)" ]]; then
            echo "Refusing to change modified checkout: $dest" >&2
            exit 1
        fi
        git -C "$dest" fetch origin "$revision"
        git -C "$dest" checkout --detach "$revision"
    fi
}
fetch https://github.com/aoineko-fr/MSXgl.git "$BASE/deps/MSXgl" ab4b26feda36189e677aa23b56acfdc3218f7953
fetch https://github.com/keendreams/keen.git "$BASE/upstream/keen" 4348b4719be87a0b873f5f4f77b4de82ddf7050c
"$BASE/deps/MSXgl/tools/sdcc/bin/sdcc" --version
printf '%s\n' 'On Ubuntu/Linux Mint install host dependencies if missing:' 'sudo apt-get install git nodejs python3 openmsx cbios'
