#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_game_test.py" "$PROJECT_ROOT"
python3 "$PROJECT_ROOT/tests/make_enemy_mode_test.py" "$PROJECT_ROOT"
export KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/enemy-modes-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
rm -f "$KEEN_TEST_OUTPUT/PASS.txt" "$KEEN_TEST_OUTPUT/FAIL.txt"
timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/enemy-mode-test.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
test -f "$KEEN_TEST_OUTPUT/PASS.txt"
KEEN_ENEMY_PROFILE=1 python3 "$PROJECT_ROOT/tests/verify_game_pixels.py" "$KEEN_TEST_OUTPUT" normal frozen invisible neither restored | tee "$KEEN_TEST_OUTPUT/pixels.txt"
cat "$KEEN_TEST_OUTPUT/PASS.txt"
