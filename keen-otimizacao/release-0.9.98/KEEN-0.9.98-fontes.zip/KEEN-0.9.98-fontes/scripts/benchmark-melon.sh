#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
LABEL="${2:-085}"
ROM="${3:-$PROJECT_ROOT/build/keen_msx.rom}"
MAP="${4:-$PROJECT_ROOT/build/keen_msx.map}"
export KEEN_WORLD_TEST=1 KEEN_TEST_OUTPUT="$PROJECT_ROOT/build/$LABEL-melon-bench-$MACHINE"
mkdir -p "$KEEN_TEST_OUTPUT"
python3 "$PROJECT_ROOT/tests/make_melon_bench.py" "$PROJECT_ROOT" "$MAP" "$KEEN_TEST_OUTPUT/bench.tcl"
timeout 90s env SDL_AUDIODRIVER=dummy xvfb-run -a openmsx -machine "$MACHINE" -cart "$ROM" -romtype ASCII16 -script "$KEEN_TEST_OUTPUT/bench.tcl" > "$KEEN_TEST_OUTPUT/emulator.log" 2>&1
python3 - "$KEEN_TEST_OUTPUT/bench.txt" <<'PY'
from pathlib import Path
import sys,statistics
rows=Path(sys.argv[1]).read_text().splitlines();assert len(rows)==2
for line in rows:
 i,*v=line.split();v=list(map(float,v));assert len(v)>5
 print(i,'frames',len(v),'FPS',round(1/statistics.mean(v),2),'p95_ms',round(sorted(v)[int(len(v)*.95)]*1000),'max_ms',round(max(v)*1000))
PY
