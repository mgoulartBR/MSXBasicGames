from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.4';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.4-score-lives.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='31696af7557fa1c4ba7c0da3f86d129e4d95b0a9e1cb13369a142f4b9dd37d61'
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','094-release-build.log','094-atlas.log','094-host-test.txt','campaign1.tcl','campaign2.tcl']:
 files.append(root/'build'/n)
for folder in ['094-final-hill','094-final-melon','094-final-msx2','094-visual']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS')
 assert not (d/'FAIL.txt').exists()
 files.extend(p for p in d.iterdir() if p.is_file())
archive=out/'keen-dreams-msx-0.9.4-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
