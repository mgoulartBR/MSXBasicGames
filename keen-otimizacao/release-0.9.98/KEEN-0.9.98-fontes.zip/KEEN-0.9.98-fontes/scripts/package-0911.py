from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.11';out.mkdir(parents=True,exist_ok=True)
rom=out/'KEEN0911.ROM';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for name in ['keen_msx.rom','keen_msx.map','0911-build.log']:files.append(root/'build'/name)
for name in ['0911-p1-z80','0911-p1-fast','0911-p2-z80','0911-p2-fast','0911-plus','0911-msx2','0911-lowram','0911-badbank','0911-cpu','0911-bankzero']:
 d=root/'build'/name
 files.extend(p for p in d.iterdir() if p.is_file() and p.suffix!='.rom')
for name in ['0911-p2-z80','0911-p2-fast']:
 result=(root/'build'/name/'result.txt').read_text()
 assert 'phase2_done 1' in result and 'phase2_status 0' in result and 'phase2_steps 700' in result
 assert 'logic_vdp_writes 0' in result and 'cpu_vdp_writes 0' in result
files.append(root/'build/0911-checksum.txt')
archive=out/'keen-dreams-msx-0.9.11-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
