from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables/v0.9.5';out.mkdir(parents=True,exist_ok=True)
rom=out/'keen-dreams-msx-0.9.5-bridge-bottoms.rom';shutil.copyfile(root/'build/keen_msx.rom',rom)
assert len(rom.read_bytes())==1048576
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='bb07555bcb401e7539b329202b8005578111f3c58ce0095af27030c620804615'
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.parts[0]=='build' or 'out' in rel.parts or 'emul' in rel.parts or '__pycache__' in rel.parts or any(n.startswith('.') for n in rel.parts):continue
 files.append(p)
for n in ['keen_msx.rom','keen_msx.map','095-release-build.log','095-atlas.log','095-route-host.txt','095-world-route.json','bridge-test.tcl','hill-scroll-test.tcl','campaign1.tcl','campaign2.tcl','bridge-map.png']:
 files.append(root/'build'/n)
for folder in ['095-route-plus','095-route-msx2','095-campaign1','095-campaign2','095-hill-scroll']:
 d=root/'build'/folder
 assert (d/'PASS.txt').read_text().startswith('PASS')
 assert not (d/'FAIL.txt').exists()
 if folder.startswith('095-route'):assert 'PASS' in (d/'pixels.txt').read_text()
 files.extend(p for p in d.iterdir() if p.is_file())
archive=out/'keen-dreams-msx-0.9.5-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(root))
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('keen-msx/build/keen_msx.rom')==rom.read_bytes()
for p in [rom,archive]:print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
