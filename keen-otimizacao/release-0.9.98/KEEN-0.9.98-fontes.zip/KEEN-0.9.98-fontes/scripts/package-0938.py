#!/usr/bin/env python3
"""Package current tested ROM and evidence; leave 0.9.36 untouched."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables/v0.9.38';out.mkdir(parents=True,exist_ok=True)
b=(r/'build/keen_msx.rom').read_bytes();digest=hashlib.sha256(b).hexdigest()
assert len(b)==2097152 and b[:2]==b'AB' and b'0.9.38 CASTLE TUBERIA' in b and b'KEEN 0.9.38 HARDWARE TEST' in b
cases=['0938-castle-rom','0938-castle-msx2','0937-boobus-rom','0937-boobus-msx2','0936-swamp-rom','0935-bay-rom','0934-grove-rom','0933-apple-rom','0932-city-rom','0931-pass-rom','0929-hill-rom','0929-mines-rom','0929-bridge-rom','0930-rapids-rom']
for case in cases:
 p=r/'build'/case;assert (p/'PASS.txt').read_text().startswith('PASS:'),case
 assert not (p/'FAIL.txt').read_text().strip(),case
 assert (p/'ROM-SHA256.txt').read_text().strip()==digest,case
for case in ('0937-boobus-rom','0937-boobus-msx2','0938-castle-rom','0938-castle-msx2'):
 assert 'PASS: independent original' in (r/'build'/case/'VERIFIED.txt').read_text()
for name in ('hill','mines','bridge29','rapids','pass','city','apple','grove','bay','swamp','boobus','castle','campaign'):
 assert 'PASS:' in (r/'build'/('0938-host-'+name+'.log')).read_text(),name
assert '168 unchanged previous-stage binaries' in (r/'build/0938-source-audit.log').read_text()
assert hashlib.sha256((r.parent/'deliverables/v0.9.36/KEEN0936.ROM').read_bytes()).hexdigest()=='6a67701461671d563d45a717949410307a79091055a7eb7e990ee86365611333'
assert digest in (r/'build/0938-final-build.log').read_text()
rom=out/'KEEN0938.ROM';rom.write_bytes(b)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if rel.parts[0]=='build' or any(n in ('out','emul','__pycache__') or n.startswith('.') for n in rel.parts):continue
 files.append(p)
for case in cases:
 files.extend(p for p in (r/'build'/case).iterdir() if p.is_file() and "trace" not in p.name)
files.extend(p for p in (r/'build').glob('0938-*.log')if p.is_file() and 'regression-campaign' not in p.name)
files.extend(p for p in (r/'build/core15').iterdir()if p.is_file())
files.extend(r/'build'/n for n in ('keen_msx.rom','keen_msx.map'))
archive=out/'keen-dreams-msx-0.9.38-rom-source.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,Path('keen-msx')/p.relative_to(r))
 z.writestr('SHA256.TXT',digest+'  KEEN0938.ROM\n')
with ZipFile(archive)as z:assert z.testzip() is None and z.read('keen-msx/build/keen_msx.rom')==b
(out/'SHA256-0938.TXT').write_text(digest+'  KEEN0938.ROM\n'+hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for p in (rom,archive):print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
