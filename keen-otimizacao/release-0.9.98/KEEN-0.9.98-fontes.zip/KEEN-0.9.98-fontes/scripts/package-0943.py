"""Package the compiled, pixel-verified ROM, source and reproducible measurements."""
from pathlib import Path
import hashlib,zipfile,json
r=Path(__file__).resolve().parents[1];out=r.parent/'deliverables0943';audit=r.parent/'audit0943';base=r.parent/'audit0942'
rom=(r/'build/keen_msx.rom').read_bytes();sha=hashlib.sha256(rom).hexdigest()
assert (out/'KEEN0943.ROM').read_bytes()==rom
assert (audit/'ROM-SHA256.txt').read_text().strip()==sha
assert 'ROM verified:' in (r/'build/0943-clean-build.log').read_text() and sha in (r/'build/0943-clean-build.log').read_text()
assert 'CompileSkipOld = false' in (r/'src/project_config.js').read_text()
assert (r/'build/0943-host-suite.log').read_text().count(' PASS')==13
assert '1246' in (r/'build/0943-exits.log').read_text()
assert (r/'build/0943-assets.log').read_text().startswith('PASS: 83')
folders=['0943-mines-rom','0943-pass-rom','0943-city-rom','0943-apple-rom','0943-grove-rom','0943-bay-rom','0943-swamp-rom','0943-castle-rom','0943-boss-pixels-rom','0943-boss-pixels-msx2','0943-hud-cache-C-BIOS_MSX2+','0943-hud-cache-C-BIOS_MSX2','0943-exit-C-BIOS_MSX2+','0943-exit-C-BIOS_MSX2','0943-finale-C-BIOS_MSX2+-1','0943-finale-C-BIOS_MSX2-12','0943-title']
for name in folders:
 p=r/'build'/name
 assert (p/'PASS.txt').read_text().startswith('PASS:'),name
 if (p/'FAIL.txt').exists():assert not(p/'FAIL.txt').read_text().strip(),name
 if (p/'ROM-SHA256.txt').exists():assert (p/'ROM-SHA256.txt').read_text().strip()==sha,name
 if 'exit-' in name or 'finale-' in name:assert (p/'PIXELS-PASS.txt').read_text().startswith('PASS:'),name
 assert any((p/f).exists() and (p/f).read_text().startswith('PASS:') for f in ['VERIFIED.txt','PIXELS-PASS.txt','verify.log']),name
assert (audit/'verification.log').read_text().startswith('PASS:')
(out/'README-0.9.43.txt').write_bytes((r/'README-0.9.43.txt').read_bytes())
zpath=out/'keen-dreams-msx-0.9.43-rom-source.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in ['KEEN0943.ROM','K943B1.ROM','SHA256.txt','README-0.9.43.txt']:z.write(out/name,name)
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(r)
  if rel.parts[0]=='build' or any(n in rel.parts for n in ['out','__pycache__','.git']):continue
  if p.suffix in ['.log','.pyc','.tmp']:continue
  z.write(p,'keen-msx/'+str(rel))
 for p in (r/'build').glob('0943-*.log'):
  if any(n in p.name for n in ['baseline','detail','last','native','build43']):continue
  # Keep successful final validations, build and source-resource checks.
  if p.name=='0943-final-build.log':continue
  z.write(p,'keen-msx/build/'+p.name)
 for name in ['keen_msx.rom','keen_msx.map']:z.write(r/'build'/name,'keen-msx/build/'+name)
 for name in folders:
  for p in sorted((r/'build'/name).iterdir()):
   if p.is_file() and (p.suffix in ['.txt','.vram','.map','.palette','.regs','.tcl'] or p.name=='complete.png' or p.name.startswith('finale-') and p.suffix=='.png'):
    if p.name in ['FAIL.txt','cachetrace.txt','uploads.txt','fire-log.txt']:continue
    z.write(p,'keen-msx/build/'+name+'/'+p.name)
 for p in sorted(audit.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if p.name.startswith('run-') and p.name!='run-final.log':continue
  z.write(p,'audit-0943/'+str(p.relative_to(audit)))
 for name in ['measurements.json','measurements.csv','ROM-SHA256.txt','RELATORIO.txt','profile_redraw.py','summarize.py']:
  z.write(base/name,'baseline-audit-0942/'+name)
with zipfile.ZipFile(zpath)as z:assert z.testzip()is None
print('PASS:',zpath,zpath.stat().st_size,'bytes; normal SHA256',sha)
