#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
python3 "$PROJECT_ROOT/tools/build_fps_monitor.py" "$PROJECT_ROOT/build/keen_msx.map" "$PROJECT_ROOT/build/keen-fps.tcl"
exec openmsx -machine "${1:-C-BIOS_MSX2+}" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/keen-fps.tcl"
