#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
sdcc="${MSXGL_ROOT:-$root/../deps/MSXgl}/tools/sdcc/bin/sdcc"
mkdir -p "$root/build/core15"
python3 - "$root" <<'PY'
from pathlib import Path
import sys
r=Path(sys.argv[1]);s='// Generated from original stage assets.\n'
for name,file in [('core_map','packed_map.bin'),('core_collision','stage_data.bin')]:
 b=(r/'assets/scene'/file).read_bytes();s+='static const u8 '+name+'[]={'+','.join(str(x) for x in b)+'};\n'
(r/'experiments/core15/assets.h').write_text(s)
PY
"$sdcc" -L"$(dirname "$sdcc")/../lib/z80" -mz80 --no-std-crt0 --code-loc 0x8000 --data-loc 0xc140 --opt-code-speed "$root/experiments/core15/core.c" -o "$root/build/core15/core.ihx"
python3 - "$root" <<'PY'
from pathlib import Path
import sys,re,hashlib
r=Path(sys.argv[1]);p=r/'build/core15';data={}
for line in (p/'core.ihx').read_text().splitlines():
 b=bytes.fromhex(line[1:]);assert sum(b)%256==0
 if b[3]==0:
  for i,v in enumerate(b[4:4+b[0]]):data[int.from_bytes(b[1:3],'big')+i]=v
symbols={n:int(v,16) for v,n in re.findall(r'^\s+([0-9A-F]{8})\s+([sl]__\w+)\s*$',(p/'core.map').read_text(),re.M)}
assert symbols['s__DATA']==0xc140 and symbols['s__DATA']+symbols['l__DATA']<=0xc240
assert min(data)==0x8000 and max(data)<0xc000
blob=bytes(data.get(i,255) for i in range(0x8000,0xc000));assert blob[0]==0xc3
(p/'CORE15.BIN').write_bytes(blob)
(r/'dos/core15_blob.h').write_text('static const u8 core_blob[16384]={'+','.join(str(x) for x in blob)+'};\n')
print('Core size',max(data)-0x8000+1,'DATA end',hex(symbols['s__DATA']+symbols['l__DATA']),'SHA256',hashlib.sha256(blob).hexdigest())
PY
