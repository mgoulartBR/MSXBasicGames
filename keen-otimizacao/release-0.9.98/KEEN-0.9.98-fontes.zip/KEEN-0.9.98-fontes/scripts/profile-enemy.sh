#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$PROJECT_ROOT/scripts/use-local-emulator.sh"
MACHINE="${1:-C-BIOS_MSX2+}"
python3 "$PROJECT_ROOT/tests/make_enemy_profile.py" "$PROJECT_ROOT/build/keen_msx.map" "$PROJECT_ROOT/build/enemy-profile.tcl"
mkdir -p "$PROJECT_ROOT/build/enemy-profile-$MACHINE"
for KEEN_PROFILE_HEAVY in 0 1; do
 for KEEN_PROFILE_MODE in 0 1 2 3; do
  export KEEN_PROFILE_HEAVY KEEN_PROFILE_MODE
  export KEEN_PROFILE_OUT="$PROJECT_ROOT/build/enemy-profile-$MACHINE/h$KEEN_PROFILE_HEAVY-m$KEEN_PROFILE_MODE.txt"
  timeout 30s env SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy openmsx -machine "$MACHINE" -cart "$PROJECT_ROOT/build/keen_msx.rom" -romtype ASCII16 -script "$PROJECT_ROOT/build/enemy-profile.tcl" > "$KEEN_PROFILE_OUT.log" 2>&1
 done
done
python3 - "$PROJECT_ROOT/build/enemy-profile-$MACHINE" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);rows=[]
for f in sorted(p.glob('h*-m*.txt')):
 d={k:float(v) for k,v in (line.split('=') for line in f.read_text().splitlines())}
 assert d['defeats']==0
 for name in ['logic','erase','draw']:d[name+'_percent']=d[name+'_ms']/d['seconds']/10
 rows.append(d)
(p/'summary.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
PY
