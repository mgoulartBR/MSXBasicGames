// 0.9.43: renderer moved to segment 100 to preserve Apple atlas bank 51.
#include "msxgl.h"
