// Banked gameplay and toroidal renderer. World data are cached in main RAM.
#define KEEN_STEP2
#include "game.c"


#include "combat.c"



#include "foreground.c"
