#include "msxgl.h"
extern const unsigned char g_Font_MGL_Sample6[];
void TitleLoad(void);
#include "title_palette.h"
// Startup-only artwork. TitleLoad runs in the fixed bank while switching assets.
void TitleScreen(void) __banked
{
    VDP_SetMode(VDP_MODE_SCREEN7);VDP_EnableDisplay(FALSE);
    VDP_SetColor(0);VDP_EnableVBlank(TRUE);VDP_EnableSprite(FALSE);
    VDP_EnableTransparency(FALSE);VDP_SetLineCount(VDP_LINE_212);
    VDP_SetPage(0);VDP_SetPalette(title_palette);
    TitleLoad();
    Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
    VDP_CommandHMMV(190,199,132,11,0);VDP_CommandWait();
    Print_SetPosition(196,201);Print_DrawText("PRESS SPACE TO START");
    VDP_CommandWait();VDP_EnableDisplay(TRUE);
    // Release/press/release prevents a held boot key from skipping the title
    // or being interpreted as entering a level in Tuberia.
    while(Keyboard_IsKeyPressed(KEY_SPACE))Halt();
    while(!Keyboard_IsKeyPressed(KEY_SPACE))Halt();
    while(Keyboard_IsKeyPressed(KEY_SPACE))Halt();
    VDP_EnableDisplay(FALSE);
}


#include "grove_grapes.c"
