// Same command as the C tile-copy path. SDCC call(0), arguments on stack.
// Only the bank-114 renderer calls this non-banked routine.
void RingCopy(u16 tile,u8 tx,u8 ty,u8 dx,u16 dy,u16 w,u8 h) __sdcccall(0) __naked
{
 tile;tx;ty;dx;dy;w;h;
 __asm
  push ix
  ld ix,#0
  add ix,sp
  ld a,(_active_level)
  dec a
  add a,a
  ld e,a
  ld d,#0
  ld hl,#_tile_x
  add hl,de
  ld c,(hl)
  inc hl
  ld b,(hl)
  ld l,4(ix)
  ld h,5(ix)
  add hl,bc
  ld a,(hl)
  add a,6(ix)
  ld (_g_VDP_Command),a
  xor a
  ld (_g_VDP_Command+1),a
  ld hl,#_tile_y
  add hl,de
  ld c,(hl)
  inc hl
  ld b,(hl)
  ld l,4(ix)
  ld h,5(ix)
  add hl,hl
  add hl,bc
  ld e,(hl)
  inc hl
  ld d,(hl)
  ld l,7(ix)
  ld h,#0
  add hl,de
  ld (_g_VDP_Command+2),hl
  ld a,8(ix)
  ld (_g_VDP_Command+4),a
  xor a
  ld (_g_VDP_Command+5),a
  ld l,9(ix)
  ld h,10(ix)
  ld (_g_VDP_Command+6),hl
  ld l,11(ix)
  ld h,12(ix)
  ld (_g_VDP_Command+8),hl
  ld a,13(ix)
  ld (_g_VDP_Command+10),a
  xor a
  ld (_g_VDP_Command+11),a
  ld (_g_VDP_Command+13),a
  ld a,#0xD0
  ld (_g_VDP_Command+14),a
  pop ix
  jp _VDP_CommandSetupR32
 __endasm;
}
