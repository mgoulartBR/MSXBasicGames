// Original Asparagusto hitboxes.
static const i8 mines_boxes[8][4]={{0,0,38,15},{0,0,32,15},{0,0,37,15},{0,0,32,15},{1,0,39,15},{7,0,39,15},{2,0,39,15},{7,0,39,15}};
