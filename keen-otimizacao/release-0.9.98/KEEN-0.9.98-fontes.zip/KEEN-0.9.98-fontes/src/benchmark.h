#ifndef KEEN_BENCHMARK_H
#define KEEN_BENCHMARK_H
#include "msxgl.h"
extern u8 bench_requested;
void BenchmarkRun(void) __banked;
#endif
