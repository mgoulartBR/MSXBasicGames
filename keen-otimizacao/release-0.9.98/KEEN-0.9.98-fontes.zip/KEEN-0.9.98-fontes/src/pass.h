#ifndef KEEN_PASS_H
#define KEEN_PASS_H
#include "combat.h"
#include "world.h"
#define pass_actors ((CombatObject*)(world_map+9000))
#define pass_keys world_map[9200]
#define pass_rise world_map[9201]
#define pass_door world_map[9203]
#define pass_door_tick world_map[9205]
#define pass_random world_map[active_level==6?9256:9208]
#define pass_overflow world_map[9210]
#define pass_fry ((CombatObject*)(world_map+(active_level==6?9312:9240)))
void PassReset(void) __banked;
void PassSelect(void) __banked;
void PassTick(void) __banked;
u8 PassHit(CombatObject*) __banked;
void PassCollect(DrawObject*) __banked;
void PassObjectsTick(void) __banked;
void EnemyBrocco(CombatObject*) __banked;
void EnemyStep(CombatObject*,u8) __banked;
void EnemyCache(void) __banked;
void BroccoBitmap(u8,DrawObject*) __banked;
#endif
