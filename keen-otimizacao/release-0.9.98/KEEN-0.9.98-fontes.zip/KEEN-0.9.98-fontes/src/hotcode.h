#ifndef KEEN_HOTCODE_H
#define KEEN_HOTCODE_H
#include "msxgl.h"
extern u8 hot_code[48],hot_enabled,hot_ok,hot_slot;
extern u16 hot_entry;
extern const u8 MapTileKernelEnd[];
u16 MapTileKernel(u16 i);
u16 CastleMapTile(u16 i);
void HotInit(void) __banked;
void HotToggle(void) __banked;
void MapperReport(void) __banked;
#endif
