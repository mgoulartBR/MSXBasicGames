// SPDX-License-Identifier: GPL-2.0-or-later
// Tomatooth: kd_act1.c acceleration, bounce hold and two-frame animation.
#include "tomato.h"
#include "game.h"
#include "world.h"
extern volatile u16 camera_px,camera_py;
#define GAME_COLLISION world_collision
// Cache map decoding within a presented frame. Rebuilt before the next batch
// so opening a door never leaves a stale collision cache across frames.
static u16 wall_key[8];
static u8 wall_value[8];
static u8 Wall(u8 x,u8 y,u8 side)
{
 u16 index;u8 slot;
 if(x>=MAP_WIDTH || y>=MAP_HEIGHT)return 1;
 index=(u16)y*MAP_WIDTH+x;slot=(x+y)&7;
 if(wall_key[slot]!=index){wall_key[slot]=index;wall_value[slot]=GAME_COLLISION[MapTile(index)];}
 return GAME_COLLISION[352+(u16)wall_value[slot]*4+side];
}
// Exact wallclip heights from kd_play.c, including half-pixel slopes.
static u16 Height(u8 shape,u8 x)
{
    switch(shape&7)
    {
        case 0: return 256;
        case 1: return 0;
        case 2: return (u16)x*8;
        case 3: return 128+(u16)x*8;
        case 4: return (u16)x*16;
        case 5: return 120-(u16)x*8;
        case 6: return 248-(u16)x*8;
        default:return 240-(u16)x*16;
    }
}

u8 tomato_count;
static Tomato* nearby[TOMATO_COUNT];
static u8 random_byte;
// Original object-plane 42 positions; SpawnTomat subtracts one tile from Y.
#include "tomato_spawns.h"
#include "castle_spawns.h"
void TomatoReset(void) __banked
{
 u8 i;Tomato* t=tomatoes;
 tomato_count=0;random_byte=73;
 for(i=0;i<(active_level==12?5:TOMATO_COUNT);++i,++t){
  t->x=(active_level==12?castle_spawn[21+i][0]:active_level==4?36U:tomato_spawn[i][0])*256;t->y=(active_level==12?(u16)(castle_spawn[21+i][1]-1):active_level==4?37U:(u16)(tomato_spawn[i][1]-1))*256;
  t->vx=t->vy=0;t->timer=0;t->active=0;t->frame=TOMATO_FRAME+2;
  t->state=t->ground=t->tick=0;
 }
}
void TomatoSelect(void) __banked
{
 u8 i;Tomato* t=tomatoes;i16 dx,dy;
 tomato_count=0;tomato_budget=2;
 if(active_level!=2 && active_level!=4 && active_level!=12)return;
 for(i=0;i<(active_level==12?5:active_level==4?1:TOMATO_COUNT);++i,++t){
  dx=(t->x>>4)-camera_px;dy=(t->y>>4)-camera_py;
  // Hysteresis avoids waking/sleeping repeatedly at the viewport boundary.
  if(t->active){if(dx<-96 || dx>352 || dy<-96 || dy>288)t->active=0;}
  else if(dx>=-48 && dx<=304 && dy>=-48 && dy<=240)t->active=1;
  if(t->active)nearby[tomato_count++]=t;
 }
 if(tomato_count)for(i=0;i<8;++i)wall_key[i]=65535;
}
static u8 Overlap(u16 x,u16 y,u8 w,u8 h,Tomato* t)
{
 return (i16)(x-t->x)<384 && (i16)(t->x-x)<(i16)w*16 &&
        (i16)(y-t->y)<384 && (i16)(t->y-y)<(i16)h*16;
}
u8 TomatoHit(CombatObject* shot) __banked
{
 u8 i;Tomato* t;
 for(i=0;i<tomato_count;++i){t=nearby[i];
  if(!t->state && Overlap(shot->x,shot->y,8,8,t)){
   t->state=1;t->timer=simulation_ticks+350;t->frame=26;t->y-=128;t->vy=0;
   shot->active=0;++flower_hits;SoundPlay(SFX_HIT);return 1;
  }
 }
 return 0;
}
void TomatoTick(void) __banked
{
 u8 i,mx,wall; i8 row;u16 ox,oy,oldbottom,newbottom,mid,surface;Tomato* t;
 if(!tomato_count)return;
 combat_dirty=1;
 for(i=0;i<tomato_count;++i){
  t=nearby[i];ox=t->x;oy=t->y;
  oldbottom=t->y+(t->state?496:368);
  // Closed-form sum of four 70-Hz steps. Two acceleration updates per batch.
  // Keep the 10-tick bounce hold and terminal speed, without a per-tick loop.
  if(t->state){
   if((i16)(simulation_ticks-t->timer)>=0){t->timer=0;t->state=0;t->y+=128;t->vy=0;t->ground=0;++flower_returns;}

  }
  if(!t->state){
   t->tick+=4;if(t->tick>=40)t->tick-=40;
   t->x+=t->vx;
   if(player_x>ox){if(t->vx<16)++t->vx;}else if(t->vx>-16)--t->vx;
   t->x+=(i16)t->vx*2;
   if(player_x>ox){if(t->vx<16)++t->vx;}else if(t->vx>-16)--t->vx;
   t->x+=t->vx;
  }
  if(!t->state && t->ground>=4){t->ground-=4;t->y+=(i16)t->vy*4;}
  else {
   if(!t->state && t->ground){
    // Only two hold steps remain (10,6,2).
    t->y+=(i16)t->vy*3;t->ground=0;
    t->vy+=3;if(t->vy>80)t->vy=80;t->y+=t->vy;
   }else{
    t->y+=t->vy;
    t->vy+=3;if(t->vy>80)t->vy=80;t->y+=(i16)t->vy*2;
    t->vy+=3;if(t->vy>80)t->vy=80;t->y+=t->vy;
   }
  }
  if(t->state)t->frame=26+(((u16)(t->timer-simulation_ticks)/20)&3);
  else{
   t->frame=TOMATO_FRAME+(t->vx>0?2:0)+(t->tick>=20);
   mx=(t->x+(t->vx>0?368:0))>>8;
   if(t->vx && (Wall(mx,(t->y+64)>>8,t->vx>0?3:1) || Wall(mx,(t->y+336)>>8,t->vx>0?3:1))){t->x=ox;t->vx=-t->vx;}
  }
  newbottom=t->y+(t->state?496:368);mid=t->x+184;mx=mid>>8;
  if(t->vy<0){
   if(Wall(mx,t->y>>8,2)){t->y=oy;t->vy=-t->vy;t->ground=0;}
  }else{
   for(row=(oldbottom>>8)-1;row<=(i8)(newbottom>>8);++row){
    wall=Wall(mx,row,0);if(!wall)continue;
    surface=(u16)row*256+Height(wall,(mid>>4)&15)-1;
    if((i16)(surface-oldbottom)>=-16 && (i16)(surface-newbottom)<=0){
     t->y=surface-(t->state?496:368);
     if(t->state)t->vy=0;
     else {random_byte=random_byte*33+17;t->vy=-30-(random_byte>>4);t->ground=10;}
     break;
    }
   }
  }
  if(t->x<256 || t->x>((u16)MAP_WIDTH-2)*256 || t->y>((u16)MAP_HEIGHT-2)*256){
   u8 n=t-tomatoes;t->x=(active_level==12?castle_spawn[21+n][0]:active_level==4?36U:tomato_spawn[n][0])*256;t->y=(active_level==12?(u16)(castle_spawn[21+n][1]-1):active_level==4?37U:(u16)(tomato_spawn[n][1]-1))*256;
   t->vx=t->vy=0;t->ground=0;
  }
  if(!t->state && Overlap(player_x+64,player_y+48,16,28,t)){
   death_ticks=70;shots[0].active=shots[1].active=0;++defeats;SoundPlay(SFX_DEATH);return;
  }
 }
}
