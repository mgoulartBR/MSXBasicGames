// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_HILL_H
#define KEEN_HILL_H
#include "combat.h"
#include "world.h"
// Hill uses 5661 packed map bytes. This storage is private to stage 1.
#define hill_actors ((CombatObject*)(world_map+9600))
typedef char HillStorageFits[(11*sizeof(CombatObject)<=200)?1:-1];
void HillReset(void) __banked;
void HillSelect(void) __banked;
void HillTick(void) __banked;
u8 HillHit(CombatObject* shot) __banked;
void HillCollect(DrawObject* out) __banked;
#endif
