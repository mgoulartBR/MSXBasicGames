#ifndef KEEN_APPLE_SPAWNS_H
#define KEEN_APPLE_SPAWNS_H
// Original Apple Acres object plane.
static const u8 apple_spawn[12][3]={{46,25,47},{102,21,58},{105,29,58},{111,29,58},{60,25,59},{15,42,48},{6,5,31},{7,5,31},{8,5,31},{6,37,31},{7,37,31},{8,37,31}};
#endif
