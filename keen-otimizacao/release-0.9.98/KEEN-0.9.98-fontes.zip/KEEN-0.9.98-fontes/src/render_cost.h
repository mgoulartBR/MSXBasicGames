// Lookup only: no per-rectangle multiplication in the Z80 drawing path.
static u8 WholeChoice(const u8* choices,i16 left,i16 top,u8 w,u8 h,
                      u8 dx,u8 dy,u8 sy,u8 source_wrap,u8 view_h)
{
#if EXP_COST_CHOICE
 u16 offset=0;u8 cut=0,edges=0;
 // Circular/multiple-edge cases retain the validated partition.
 if((u16)dx+w>256 || (u16)dy+h>256 || (source_wrap && (u16)sy+h>256))return 0;
 if(left<0){cut=-left;offset=2;++edges;}
 if(left+w>256){cut=left+w-256;offset=2+(u16)(w-1)*2;++edges;}
 if(top<0){cut=-top;offset=2+(u16)(w-1)*4;++edges;}
 if(top+h>view_h){cut=top+h-view_h;offset=2+(u16)(w-1)*4+(u16)(h-1)*2;++edges;}
 if(edges>1)return 0;
 if(edges)offset+=(u16)(cut-1)*2;
 offset+=dx&1;
 return choices[offset>>3]&(1<<(offset&7));
#else
 return 0;
#endif
}
