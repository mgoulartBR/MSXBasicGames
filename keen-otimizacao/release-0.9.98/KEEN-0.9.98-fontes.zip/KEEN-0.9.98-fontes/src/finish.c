// SPDX-License-Identifier: GPL-2.0-or-later
#include "game.h"
#include "pickups.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 hardware_scroll;
extern u8 ReadInput(void) __banked;
static void FinishCentered(u8 y,const char* text)
{
 const char* p=text;u8 length=0;while(*p++){++length;}
 Print_SetPosition((256-(u16)length*6)/2,y);Print_DrawText(text);
}
void LevelComplete(void) __banked
{
 SoundPlay(SFX_COMPLETE);
 u16 n,divisor;char ammo[20]="FLOWER POWER: 00000";u8 i=14;
 VDP_CommandWait();VDP_SetVerticalOffset(0);
 if(hardware_scroll){VDP_RegWrite(26,0);VDP_RegWrite(27,0);VDP_RegWrite(25,0);}
 VDP_SetPage(0);VDP_CommandHMMV(0,0,256,512,0);VDP_CommandWait();
 Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 FinishCentered(56,"LEVEL COMPLETE");
 FinishCentered(80,active_level==12?"CASTLE TUBERIA":active_level==11?"BOOBUS ROOM":active_level==10?"SQUASH SWAMP":active_level==9?"BRUSSELS SPROUT BAY":active_level==8?"GRAPE GROVE":active_level==7?"APPLE ACRES":active_level==6?"SPUD CITY":active_level==5?"PARSNIP PASS":active_level==4?"RHUBARB RAPIDS":active_level==3?"BRIDGE BOTTOMS":active_level==2?"MELON MINES":"HORSERADISH HILL");
 n=flower_ammo;for(divisor=10000;divisor;divisor/=10){ammo[i++]=48+n/divisor;n%=divisor;}
 FinishCentered(104,ammo);FinishCentered(144,"SPACE / FIRE TO TUBERIA");
 VDP_CommandWait();level_done=2;
 while((ReadInput()&80)||Keyboard_IsKeyPressed(KEY_R))Halt();
 while(!(ReadInput()&80)&&!Keyboard_IsKeyPressed(KEY_R))Halt();
 while((ReadInput()&80)||Keyboard_IsKeyPressed(KEY_R))Halt();
 if(hardware_scroll)VDP_RegWrite(25,2);
}
