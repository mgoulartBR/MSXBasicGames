#include "boobus.h"
#include "swamp.h"
#include "bay.h"
#include "city.h"
// SPDX-License-Identifier: GPL-2.0-or-later
// PowerReact's eight floor profiles and sixteen rebound directions.
static const u8 rebound[8][8]={
 {0,0,0,0,0,0,0,0},{7,6,5,4,3,2,1,0},
 {5,4,3,2,1,0,15,14},{5,4,3,2,1,0,15,14},
 {3,2,1,0,15,14,13,12},{9,8,7,6,5,4,3,2},
 {9,8,7,6,5,4,3,2},{11,10,9,8,7,6,5,4}};
static void Rebound(CombatObject* s,u8 wall)
{
    static u16 ax,ay,speed,v;
    static u8 angle;
    ax=s->vx<0?-s->vx:s->vx;ay=s->vy<0?0:s->vy;
    if(ax>ay){if(ax>ay*2){angle=0;speed=ax*286U;}else{angle=1;speed=ax*362U;}}
    else{if(ay>ax*2){angle=3;speed=ay*256U;}else{angle=2;speed=ay*286U;}}
    if(s->vx>0)angle=7-angle;
    speed>>=1;angle=rebound[wall&7][angle];
    v=speed/286U;
    switch(angle){
    case 0:s->vx=v;s->vy=-(i16)v/2;break;
    case 1:v=speed/362U;s->vx=v;s->vy=-(i16)v;break;
    case 2:s->vy=-(i16)v;s->vx=v/2;break;
    case 3:case 4:case 11:case 12:s->vx=0;s->vy=-(i16)(speed/256);break;
    case 5:s->vy=-(i16)v;s->vx=-(i16)v/2;break;
    case 6:v=speed/362U;s->vx=s->vy=-(i16)v;break;
    case 7:s->vx=-(i16)v;s->vy=-(i16)v/2;break;
    case 8:s->vx=-(i16)v;s->vy=v/2;break;
    case 9:v=speed/362U;s->vx=-(i16)v;s->vy=v;break;
    case 10:s->vy=v;s->vx=-(i16)v/2;break;
    case 13:s->vy=v;s->vx=v/2;break;
    case 14:v=speed/362U;s->vx=s->vy=v;break;
    default:s->vx=v;s->vy=v/2;break;
    }
    s->state=1;
    if(speed<4096){s->state=2;s->timer=51;s->vx=s->vy=0;s->frame=32;}
}
void ShotTick(CombatObject* s) __banked
{
    static u16 ox,oy,mid,oldbottom,surface;
    static u8 wall,mx;
    if(!s->active)return;
    if(active_level==11 && s->state==3){BoobusBombTick(s);return;}
    if(s->state && ShotTouch(player_x+64,player_y+48,16,28,s->x,s->y,active_level==11?16:8,active_level==11?16:8)){
        s->active=0;if(active_level==11)++boobus_bombs;else InventoryAdd(1);++seeds_recovered;return;
    }
    if(s->state==2){if(active_level==11)BoobusBombTick(s);if(!--s->timer)s->active=0;return;}
    if(!s->timer)s->timer=140;
    --s->timer;s->frame=seed_frame[s->timer];if(active_level==11)BoobusBombTick(s);
    ox=s->x;oy=s->y;oldbottom=oy+(active_level==11?240:112);s->x+=s->vx;s->y+=s->vy;
    if(simulation_ticks&1){s->vy+=3;if(s->vy>80)s->vy=80;}
    // Stage dimensions: deep Melon Mines extends below Horseradish Hill.
    if(s->x<256 || s->x>((u16)MAP_WIDTH-2)*256U || s->y>(u16)MAP_HEIGHT*256U){s->active=0;return;}
    if(!(enemy_mode&1) && !s->state && enemy.active && !enemy.state && ShotTouch(s->x,s->y,8,8,enemy.x,enemy.y,32,32)){
        enemy.state=1;enemy.timer=350;enemy.frame=26;s->active=0;++flower_hits;SoundPlay(SFX_HIT);return;
    }
    if(!(enemy_mode&1) && !s->state && tomato_count && TomatoHit(s))return;
    if(active_level==2 && !(enemy_mode&1) && !s->state && MinesHit(s))return;
    if(active_level==1 && !(enemy_mode&1) && !s->state && HillHit(s))return;
    if(active_level==3 && !(enemy_mode&1) && !s->state && BridgeHit(s))return;
    if(active_level==4 && !(enemy_mode&1) && !s->state && RapidHit(s))return;
    if(active_level==5 && !(enemy_mode&1) && !s->state && PassHit(s))return;
    if(active_level==12 && !(enemy_mode&1) && !s->state && CastleHit(s))return;
    if(active_level==11 && !(enemy_mode&1) && !s->state && BoobusHit(s))return;
    if(active_level==10 && !(enemy_mode&1) && !s->state && SwampHit(s))return;
    if(active_level==9 && !(enemy_mode&1) && !s->state && BayHit(s))return;
    if(active_level==8 && !(enemy_mode&1) && !s->state && GroveHit(s))return;
    if(active_level==7 && !(enemy_mode&1) && !s->state && AppleHit(s))return;
    if(active_level==6 && !(enemy_mode&1) && !s->state && CityHit(s))return;
    // A wall rebound becomes a recoverable bonus, as in PowerReact.
    mx=(s->x+(s->vx>0?(active_level==11?240:112):0))>>8;
    if(s->vx && ShotWall(mx,(s->y+48)>>8,s->vx>0?3:1)){
        s->x=ox;s->vx=-s->vx/2;s->state=1;
    }
    mid=s->x+(active_level==11?120:56);mx=mid>>8;
    if(s->vy<0 && ShotWall(mx,s->y>>8,2)){s->y=oy;s->vy=-s->vy/2;return;}
    wall=ShotWall(mx,(s->y+(active_level==11?240:112))>>8,0);
    if(wall && s->vy>=0){
        surface=((s->y+(active_level==11?240:112))&0xff00)+ShotHeight(wall,(mid>>4)&15);
        if(s->y+(active_level==11?240:112)>=surface && oldbottom<=surface+80){
            s->y=surface-(active_level==11?241:113);Rebound(s,wall);if(active_level==11)BoobusBombTick(s);
        }
    }
}
