// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_APPLE_H
#define KEEN_APPLE_H
#include "combat.h"
#include "world.h"
#define apple_actors ((CombatObject*)(world_map+9000))
#define apple_peas ((CombatObject*)(world_map+9088))
#define apple_random world_map[9160]
#define apple_bombs world_map[9161]
#define apple_rise (world_map+9162)
#define apple_spits world_map[9170]
#define apple_resume (world_map+9171)
#define apple_foot (world_map+9180)
#define apple_overflow world_map[9189]
void AppleReset(void) __banked;
void AppleSelect(void) __banked;
void AppleTick(void) __banked;
u8 AppleHit(CombatObject*) __banked;
void AppleCollect(DrawObject*) __banked;
void AppleStatic(DrawObject*) __banked;
void AppleObjectsTick(void) __banked;
void AppleLoseBombs(void) __banked;
void AppleBitmap(u8,DrawObject*) __banked;
void AppleUpload(u8,const u8*,u16,u16);
#endif
