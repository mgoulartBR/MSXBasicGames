// Phase 2: three independent workloads, measured without a live overlay.
#include "msxgl.h"
#include "game.h"
#include "world.h"
#include "combat.h"
#include "tomato.h"
#include "campaign.h"
#include "pickups.h"
#include "hw_tomato.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 cpu_mode;
extern volatile u16 camera_px,camera_py;
extern u8 camera_x,camera_y;
u8 CpuRead(void) __banked;
void FollowCamera(void) __banked;
#include "session.h"
#define phase2_done (session.experiments.phase2_done)
#define phase2_stage (session.experiments.phase2_stage)
#define phase2_status (session.experiments.phase2_status)
#define phase2_hz (session.experiments.phase2_hz)
#define phase2_cpu (session.experiments.phase2_cpu)
#define phase2_logic (session.experiments.phase2_logic)
#define phase2_cpu_ticks (session.experiments.phase2_cpu_ticks)
#define phase2_vdp (session.experiments.phase2_vdp)
#define phase2_checksum (session.experiments.phase2_checksum)
#define phase2_steps (session.experiments.phase2_steps)
#define phase2_shots (session.experiments.phase2_shots)
#define phase2_hits (session.experiments.phase2_hits)
static u16 Clock(void){return *((volatile u16*)M_JIFFY);}
static void Text(u8 y,const char* s){Print_SetPosition(4,y);Print_DrawText(s);}
static void Value(u16 n){Print_DrawInt(n);}
static u8 Input(u8 t){u8 in=t<70?2:1;if(t<24||(t>=70&&t<94))in|=16;if((t>=30&&t<34)||(t>=100&&t<104))in|=64;return in;}
static void Time(u8 y,const char* label,u16 ticks){
 Text(y,label);Value(ticks);Print_DrawText(" T / ");
 Value((u32)ticks*1000/phase2_hz);Print_DrawText(" MS");
}
void Phase2Run(void) __banked
{
 u16 start,i,index,sum=0;u8 phase=0,in;
 phase2_done=phase2_status=0;phase2_hz=VDP_GetFrequency()?50:60;
 phase2_cpu=*((const u8*)0x2d)==3?CpuRead():cpu_mode;
 // Prepare identical HH-A initial state outside the timed interval.
 player_x=102U*256;player_y=29U*256;player_vx=player_vy=0;
 simulation_ticks=0;flower_ammo=100;enemy_mode=0;
 camera_px=player_x/16-112;camera_py=player_y/16-80;
 camera_x=camera_px>>4;camera_y=camera_py>>4;
 Game_Tick(0);CombatTick(0);FollowCamera();simulation_ticks=0;
 HWHide();VDP_CommandWait();
 // No throttling: elapsed completion time, NOT FPS. Keep normal BIOS interrupts.
 phase2_stage=1;start=Clock();
 for(i=0;i<700;++i){
  TomatoSelect();in=Input(phase);if(++phase==140)phase=0;
  Game_Tick(in);CombatTick(in);FollowCamera();
  if(death_ticks||restart_pending||level_done){phase2_status=1;break;}
 }
 phase2_logic=Clock()-start;phase2_steps=simulation_ticks;
 phase2_shots=shots_fired;phase2_hits=flower_hits;
 // Fixed workload: 32768 map/collision lookups, no VDP, input, banking or AI.
 // Calls the existing MapTile decoder (fixed ROM); map/collision data is RAM.
 phase2_stage=2;index=0;start=Clock();
 for(i=0;i<32768U;++i){
  sum+=world_collision[MapTile(index)];
  index+=37;if(index>=5000)index-=5000;
 }
 phase2_cpu_ticks=Clock()-start;phase2_checksum=sum;phase2_stage=0;
 // 128 non-overlapping 128x64 VRAM copies (524288 bytes total). Screen stays on.
 // Includes command setup and wait cost. No gameplay or transfer from CPU RAM.
 VDP_CommandWait();phase2_stage=3;start=Clock();
 for(i=0;i<128;++i){VDP_CommandHMMM(0,256,128,320,128,64);VDP_CommandWait();}
 phase2_vdp=Clock()-start;phase2_stage=4;
 VDP_EnableDisplay(FALSE);VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetPage(0);VDP_SetVerticalOffset(0);
 if(*((const u8*)0x2d)>=2){VDP_RegWrite(25,0);VDP_RegWrite(26,0);VDP_RegWrite(27,0);}
 VDP_EnableSprite(FALSE);VDP_ClearVRAM();VDP_SetColor(0);
 Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(4,"KEEN 0.9.11 - PHASE 2 / HH-A");
 Text(20,"CPU RAW/MODE: ");Print_DrawHex8(phase2_cpu);Print_DrawText("  HZ: ");Value(phase2_hz);
 Text(36,phase2_status?"LOGIC ABORTED: DO NOT COMPARE":"LOGIC: COMPLETE / RENDER OFF");
 Time(54,"LOGIC: ",phase2_logic);
 Text(70,"STEPS: ");Value(phase2_steps);Print_DrawText(" SHOTS/HITS: ");Value(phase2_shots);Print_DrawChar('/');Value(phase2_hits);
 Time(90,"CPU 32768: ",phase2_cpu_ticks);
 Text(106,"CPU CHECKSUM: ");Print_DrawHex16(phase2_checksum);
 Time(126,"VDP 128 BLITS: ",phase2_vdp);
 Text(146,"T = VBLANK TICKS; LOWER IS FASTER");
 Text(162,"LOGIC UNPACED / CODE STILL ROM");
 Text(180,"PHOTO RESULTS; RESET FOR NEXT CPU");
 VDP_CommandWait();VDP_EnableDisplay(TRUE);phase2_done=1;
 for(;;)Halt();
}

#include "grove_collect.c"
