// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_CITY_H
#define KEEN_CITY_H
#include "pass.h"
#include "mines.h"
#define city_actors ((CombatObject*)(world_map+9000))
#define city_random world_map[9256]
#define city_overflow world_map[9257]
#define city_bombs world_map[9258]
#define city_rise (world_map+9260)
#define city_seeds ((MinesSeed*)(world_map+9360))
void CityReset(void) __banked;
void CitySelect(void) __banked;
void CityTick(void) __banked;
u8 CityHit(CombatObject*) __banked;
void CityCollect(DrawObject*) __banked;
void CityObjectsTick(void) __banked;
void CityLoseBombs(void) __banked;
void CityCarrotTick(CombatObject*) __banked;
void CityFrenchTick(CombatObject*) __banked;
void CityFriesTick(void) __banked;
void CityCarrotBitmap(u8,DrawObject*) __banked;
void CityFrenchBitmap(u8,DrawObject*) __banked;
u16 CityMapTile(u16);
#endif
