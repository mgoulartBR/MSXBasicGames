// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_TOMATO_H
#define KEEN_TOMATO_H
#include "combat.h"
#include "world.h"
#define TOMATO_COUNT 6
#define TOMATO_FRAME 90
typedef struct {u16 x,y,timer;i8 vx,vy;u8 active,frame,ground,state,tick;} Tomato;
typedef char TomatoFitsMetadata[(sizeof(Tomato)*TOMATO_COUNT<=94)?1:-1];
// Unused stage metadata after 25 pickup records, before dimensions at 1120.
#define tomato_budget (world_collision[1104])
#define tomatoes ((Tomato*)(world_collision+1026))
extern u8 tomato_count;
void TomatoReset(void) __banked;
void TomatoSelect(void) __banked;
void TomatoTick(void) __banked;
u8 TomatoHit(CombatObject* shot) __banked;
#endif
