#ifndef KEEN_PICKUPS_H
#define KEEN_PICKUPS_H
#include "msxgl.h"
#include "world.h"
#define PICKUP_COUNT 10
typedef struct {u16 x,y;u8 amount,frame;} Pickup;
 #define pickups ((const Pickup*)(world_collision+876))
extern const u16 pickup_columns[136],pickup_rows[37];
extern u32 pickup_taken;
extern u16 flower_ammo;
extern volatile u16 pickups_collected,seeds_recovered,empty_throws;
void InventoryReset(void);
void InventoryTick(void);
void InventoryAdd(u8 n);
#endif
