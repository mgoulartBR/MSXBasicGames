#include "campaign_impl.c"
