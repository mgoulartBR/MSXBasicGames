// Hardware compatibility diagnostic; startup only.
#include "msxgl.h"
#include "bios.h"
#include "benchmark.h"
#include "hotcode.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 cpu_mode;
void CpuAuto(void) __banked;
u8 CpuRead(void) __banked;
void CpuZ80(void) __banked;
void CpuROM(void) __banked;
void CpuDRAM(void) __banked;
u16 BootBankHash(u8 bank);
u8 BootProbe(u16 offset,u8 bank);
#ifdef KEEN_DIAGNOSTICS
// Compare all bytes in both windows to a sealed copy, allowing only AB->EF at offsets 0 and 1.
typedef struct {u16 offset;u8 ref,mapped,fixed,reason;} HeaderDiff;
// reason 1: reference header changed; 2: mismatch after allowed AB->EF.
static u8 BootHeaderCheck(HeaderDiff* d){
 u16 off;u8 expected,mapped,fixed,raw;
 for(off=0;off<16384;++off){
  raw=expected=BootProbe(off,46);
  mapped=BootProbe(off,0);fixed=*((const u8*)(0x4000+off));
  if(off<2 && raw==(u8)(0x41+off))expected=(u8)(0x45+off);
  if((off<2 && raw!=(u8)(0x41+off)) || mapped!=expected || fixed!=expected){
   d->offset=off;d->ref=raw;d->mapped=mapped;d->fixed=fixed;
   d->reason=(off<2 && raw!=(u8)(0x41+off))?1:2;return 0;
  }
 }
 return 1;
}
static void Line(u8 y,const char* s){VDP_CommandHMMV(0,y,256,10,0);VDP_CommandWait();Print_SetPosition(6,y);Print_DrawText(s);VDP_CommandWait();}
static void Hex(u16 n){Print_DrawHex16(n);}
 #endif
void HardwareBoot(void) __banked
{
#ifndef KEEN_DIAGNOSTICS
 if(*((const u16*)0xfc4a)<0xf200){
  BIOS_InitScreen0();BIOS_TextPrint("NOT ENOUGH FREE RAM.\r\nBOOT ROM DIRECTLY; DISABLE DISK ROM.\r\n");
  for(;;)Halt();
 }
 bench_requested=0;HotInit();CpuAuto();
#else
 HeaderDiff diff;
 u8 bank,bad=255,old=255,tick;u16 got,actual=0,offset;u8 failures=0,found=0,value=0,header=0;
 // Do this before touching the game's globals above the loader's HIMEM.
 if(*((const u16*)0xfc4a)<0xf200){
  BIOS_InitScreen0();BIOS_TextPrint("HIMEM: ");
  got=*((const u16*)0xfc4a);
  for(bank=0;bank<4;++bank){bad=(got>>12)&15;BIOS_TextPrintChar(bad<10?bad+48:bad+55);got<<=4;}
  BIOS_TextPrint("\r\n");BIOS_TextPrint("KEEN 0.9.43 - NOT ENOUGH FREE RAM\r\nHIMEM MUST BE F200 OR HIGHER.\r\nBOOT ROM DIRECTLY; DISABLE DISK ROM.\r\nRESET REQUIRED.\r\n");
  for(;;)Halt();
 }
 VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetColor(0);VDP_EnableSprite(FALSE);
 VDP_ClearVRAM();Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Line(6,"KEEN 0.9.43 HARDWARE TEST");
 Line(22,"BIOS: ");Print_DrawHex8(*((const u8*)0x2d));
 Line(34,"HIMEM: ");Hex(*((const u16*)0xfc4a));
 Line(50,"ASCII16 BANK CHECK...");
 for(bank=0;bank<64;++bank){
  if(bank==42)continue;
  got=BootBankHash(bank);
  if(got!=((const u16*)0xbf00)[bank]){if(bank==0 && BootHeaderCheck(&diff)){header=1;continue;}++failures;if(bad==255){bad=bank;actual=got;}}
 }
 Line(64,"BANKS: ");
 if(bad!=255){
  Print_DrawText("FAIL ");Print_DrawHex8(bad);Print_DrawText(" COUNT ");Print_DrawHex8(failures);
  Line(80,"HASH GOT/EXPECTED: ");Hex(actual);Print_DrawChar('/');Hex(((const u16*)0xbf00)[bad]);
  if(bad==0){
   Line(96,"FULL CHECK OFFSET: ");Hex(diff.offset);
   Line(112,"REF/MAPPED/FIXED: ");Print_DrawHex8(diff.ref);Print_DrawChar('/');Print_DrawHex8(diff.mapped);Print_DrawChar('/');Print_DrawHex8(diff.fixed);
   Line(128,diff.reason==1?"REFERENCE HEADER ALSO CHANGED":"EXTRA DIFFERENCE AFTER AB>EF RULE");

  }
  Line(142,"READ MISMATCH; CAUSE NOT CONFIRMED");
  Line(158,"CHECK LOADER PATCHES AND MAPPER");
  Line(180,"PHOTO THIS SCREEN; RESET REQUIRED");
  for(;;)Halt();
 }

 Print_DrawText(header?"OK / HEADER AB>EF VERIFIED":"00-29 + 2B-3F OK");
 Line(80,"CHECKING MAPTILE ROM/RAM...");HotInit();
 Line(80,"CONFIGURING CPU...");CpuAuto();
 Line(80,"CPU CHECK READY");
 if(*((const u8*)0x2d)==3){
  Line(128,"1 Z80   2 R800 ROM   3 R800 DRAM");
 }else Line(128,"EXISTING OCM TURBO IS PRESERVED");
 Line(146,"B:GAME N:CPU M:ROM/RAM P:CORE");
 Line(158,"H: MAPTILE ROM/RAM  Q: MEMORY");
 Line(170,"MAPTILE: ROM");
 bench_requested=0;
 Line(180,"SPACE: TITLE AND GAME");
 while(Keyboard_IsKeyPressed(KEY_SPACE))Halt();
 tick=*((volatile u8*)M_JIFFY);
 for(;;){
  if(*((const u8*)0x2d)==3){
   if(Keyboard_IsKeyPressed(KEY_1)){CpuZ80();while(Keyboard_IsKeyPressed(KEY_1))Halt();}
   if(Keyboard_IsKeyPressed(KEY_2)){CpuROM();while(Keyboard_IsKeyPressed(KEY_2))Halt();}
   if(Keyboard_IsKeyPressed(KEY_3)){CpuDRAM();while(Keyboard_IsKeyPressed(KEY_3))Halt();}
   bank=CpuRead();
  }else bank=cpu_mode;
  if(bank!=old){
   Line(100,"CPU: ");Print_SetPosition(36,100);
   Print_DrawText(bank==2?"R800 DRAM":bank==1?"R800 ROM":bank==4?"OCM CUSTOM":bank==3?"PANASONIC TURBO":"Z80 / CURRENT CLOCK");old=bank;
   if(*((const u8*)0x2d)==3){Line(114,"GETCPU RAW: ");Print_DrawHex8(bank);}
  }
  if(Keyboard_IsKeyPressed(KEY_Q)){while(Keyboard_IsKeyPressed(KEY_Q))Halt();MapperReport();}
  if(Keyboard_IsKeyPressed(KEY_H)){HotToggle();Line(170,hot_enabled?"MAPTILE: RAM VERIFIED":(hot_ok?"MAPTILE: ROM":"MAPTILE COPY FAILED; USING ROM"));while(Keyboard_IsKeyPressed(KEY_H))Halt();}
  if(Keyboard_IsKeyPressed(KEY_P)){bench_requested=4;while(Keyboard_IsKeyPressed(KEY_P))Halt();break;}
  if(Keyboard_IsKeyPressed(KEY_B)){bench_requested=1;while(Keyboard_IsKeyPressed(KEY_B))Halt();break;}
  if(Keyboard_IsKeyPressed(KEY_N)){bench_requested=2;while(Keyboard_IsKeyPressed(KEY_N))Halt();break;}
  if(Keyboard_IsKeyPressed(KEY_M)){bench_requested=3;while(Keyboard_IsKeyPressed(KEY_M))Halt();break;}
  if(Keyboard_IsKeyPressed(KEY_SPACE))break;
  while((u8)(*((volatile u8*)M_JIFFY)-tick)<12)Halt();tick=*((volatile u8*)M_JIFFY);
 }
 while(Keyboard_IsKeyPressed(KEY_SPACE))Halt();
#endif
}

#include "apple_collect.c"
