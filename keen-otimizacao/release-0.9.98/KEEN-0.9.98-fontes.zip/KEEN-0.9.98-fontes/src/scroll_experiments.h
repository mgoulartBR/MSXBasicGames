// Compile-time ablation switches.
#define EXP_COST_CHOICE 0
#define EXP_RESTORE_BANDS 1
#define EXP_TEXTURE_SELECT 0
