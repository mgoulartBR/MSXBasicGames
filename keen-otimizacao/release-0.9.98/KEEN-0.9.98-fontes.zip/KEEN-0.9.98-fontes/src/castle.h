// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_CASTLE_H
#define KEEN_CASTLE_H
#include "combat.h"
#include "world.h"
// Map dictionary ends at 4359; sprite/tile metadata ends at 7082.
#define castle_actors ((CombatObject*)(world_map+7200))
#define castle_resume (world_map+7472)
#define castle_keys world_map[7490]
#define castle_rise (world_map+7491)
#define castle_doors (world_map+7493)
#define castle_door_ticks (world_map+7495)
#define castle_overflow world_map[7497]
void CastleLoad(void) __banked;
void CastleReset(void) __banked;
void CastleSelect(void) __banked;
void CastleTick(void) __banked;
u8 CastleHit(CombatObject*) __banked;
void CastleCollect(DrawObject*) __banked;
void CastleStatic(DrawObject*) __banked;
void CastleObjectsTick(void) __banked;
void CastleAtlas(u8);
void CastleSquashBitmap(u8,DrawObject*) __banked;
#endif
