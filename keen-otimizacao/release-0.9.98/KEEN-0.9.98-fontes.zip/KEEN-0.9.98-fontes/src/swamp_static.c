#include "swamp.h"
#include "swamp_bonus.h"
#include "combat_assets.h"
#include "campaign.h"
#include "game.h"
extern volatile u16 camera_px,camera_py;
extern volatile u8 hardware_scroll;
static void SwampStaticPut(DrawObject* out,u8* n,u16 x,u16 y,u8 f)
{
 DrawObject* d;const SpriteDef* sp=sprites[9]+f;if((i16)(x+SPR_OX(sp)-camera_px)<=-(i16)sp->w || (i16)(x+SPR_OX(sp)-camera_px)>=256 || (i16)(y+SPR_OY(sp)-camera_py)<=-(i16)sp->h || (i16)(y+SPR_OY(sp)-camera_py)>=(hardware_scroll?192:176))return;
 if(*n>=12){swamp_overflow=2;return;}d=out+(*n<10?4+*n:*n==10?1:28);++*n;d->x=x;d->y=y;d->frame=f;d->visible=1;
}
void SwampStatic(DrawObject* out) __banked
{
 u8 i,n=0;u32 bit=1;const Pickup* p=pickups;
 for(i=4;i<14;++i)out[i].visible=0;out[1].visible=out[28].visible=0;
 for(i=0;i<LEVEL_PICKUPS;++i,++p,bit<<=1)if(!(pickup_taken&bit))SwampStaticPut(out,&n,p->x,p->y,p->frame);
 for(i=0;i<13;++i){bit=i<32?1UL<<i:1UL<<(i-32);if(!((i<32?bonus_taken:bonus_high)&bit))SwampStaticPut(out,&n,swamp_bonus[i].x,swamp_bonus[i].y,94+swamp_bonus[i].kind);}
}
