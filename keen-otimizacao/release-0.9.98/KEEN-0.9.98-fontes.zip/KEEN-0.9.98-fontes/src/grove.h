#ifndef KEEN_GROVE_H
#define KEEN_GROVE_H
#include "combat.h"
#include "world.h"
#define grove_actors ((CombatObject*)(world_map+7960))
#define grove_resume (world_map+8590)
#define grove_bombs world_map[8630]
#define grove_rise (world_map+8631)
#define grove_overflow world_map[8634]
void GroveLoad(void) __banked;
void GroveReset(void) __banked;
void GroveSelect(void) __banked;
void GroveTick(void) __banked;
u8 GroveHit(CombatObject*) __banked;
void GroveCollect(DrawObject*) __banked;
void GroveStatic(DrawObject*) __banked;
void GroveObjectsTick(void) __banked;
void GroveLoseBombs(void) __banked;
void GroveFall(CombatObject*,u8) __banked;
void GroveSquasher(CombatObject*) __banked;
void GroveDecode(u8,const u8*,u16,u16);
void GroveCopy(u8,const u8*,u8*,u16);
#endif
