#include "bounds.c"
#include "pass.c"

#include "brocco_bitmap.c"

#include "rapids_spawns.h"
void RapidReset(void) __banked
{
 u8 i;CombatObject* a;if(active_level!=4)return;
 for(i=0;i<10;++i){a=rapid_actors+i;a->x=(u16)rapids_spawn[i][0]*256;a->y=(u16)rapids_spawn[i][1]*256;if(i!=7)a->y-=512;if(i<7)a->y+=15;
 a->vx=a->vy=a->timer=0;a->active=a->ground=a->state=a->tick=0;a->dir=1;a->frame=(i<7?124:i==7?112:116);}
 rapid_keys=rapid_bombs=0;rapid_random=73;
 for(i=0;i<3;++i)rapid_bomb_rise[i]=0;
 for(i=0;i<2;++i)rapid_rise[i]=rapid_doors[i]=rapid_door_ticks[i]=0;
}

#include "grove.h"
void GroveSquasher(CombatObject* a) __banked{u8 saved=pass_random;pass_random=world_map[8635];PassSquasher(a,5);world_map[8635]=pass_random;pass_random=saved;}

void GroveFall(CombatObject* a,u8 height) __banked
{
 u16 old=a->y+(u16)height*16,mid=a->x+184,surface;u8 wall;i8 row;
 if(simulation_ticks&1){a->vy+=3;if(a->vy>80)a->vy=80;}a->y+=a->vy;
 if(a->vy<0){if(PassWall(mid>>8,a->y>>8,2)){a->y-=a->vy;a->vy=0;}return;}
 for(row=(old>>8)-1;row<=(i8)((a->y+(u16)height*16)>>8);++row){wall=PassWall(mid>>8,row,0);if(!wall)continue;
 surface=(u16)row*256+PassHeight(wall,(mid>>4)&15)-1;
 if((i16)(surface-old)>=-16 && (i16)(surface-a->y-(u16)height*16)<=0){a->y=surface-(u16)height*16;a->ground=1;return;}}
 a->ground=0;
}
