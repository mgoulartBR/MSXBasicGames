void CITY_BITMAP(u8 page,DrawObject* ob) __banked
{
 const SpriteDef* sp=sprites[LEVEL_INDEX]+ob->frame;
 const u8* pixels=CITY_IMAGES[ob->frame-CITY_BASE];

 u8 row,texture_y,w,h,part,iw=sp->w,ih=sp->h,view_h=hardware_scroll?192:176;
 u16 x,y,dx,dy;i16 left=ob->x+SPR_OX(sp)-camera_px,top=ob->y+SPR_OY(sp)-camera_py,l=0,t=0,r=iw,b=ih;
 if(left>=256 || top>=view_h || left+iw<=0 || top+ih<=0){ob->visible=0;return;}
 if(left<0)l=-left;if(top<0)t=-top;if(left+r>256)r=256-left;if(top+b>view_h)b=view_h-top;
 dx=HWTexture(page,ob->frame,ih);texture_y=dx;
 VDP_CommandWait();
 if(!(dx&256)){
  for(row=0;row<ih;++row)VDP_WriteVRAM(pixels+(u16)row*iw,(u16)page*32768+(u16)(u8)(texture_y+row)*128+64,0,iw);
 }
 for(part=0;part<2;++part)for(y=t;y<b;y+=h){
  dy=hardware_scroll?(ob->y+SPR_OY(sp)+y)&255:16+top+y;h=b-y;if(hardware_scroll && dy+h>256)h=256-dy;if(((texture_y+y)&255)+h>256)h=256-((texture_y+y)&255);
  for(x=l;x<r;x+=w){dx=hardware_scroll?(ob->x+SPR_OX(sp)+x)&255:left+x;w=r-x;if(hardware_scroll && dx+w>256)w=256-dx;
   g_VDP_Command.SX=128+(part?iw:0)+x;g_VDP_Command.SY=(u16)page*256+((texture_y+y)&255);
   g_VDP_Command.DX=dx;g_VDP_Command.DY=(u16)page*256+dy;g_VDP_Command.NX=w;g_VDP_Command.NY=h;g_VDP_Command.ARG=0;
   g_VDP_Command.CMD=VDP_CMD_LMMM+(part?VDP_OP_OR:VDP_OP_AND);VDP_CommandSetupR32();}
 }
}
