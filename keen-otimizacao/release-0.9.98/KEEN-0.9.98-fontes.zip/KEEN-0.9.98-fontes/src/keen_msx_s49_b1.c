#include "msxgl.h"
#include "hw_tomato.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 cpu_mode;
u8 CpuRead(void) __banked;
void Core15Call(u8 action);
#define R ((volatile u16*)0xc100)
static void Text(u8 y,const char* s){Print_SetPosition(4,y);Print_DrawText(s);}
void Core15Run(void) __banked {
 u8 cpu=*((const u8*)0x2d)==3?CpuRead():cpu_mode;
 HWHide();VDP_CommandWait();
 Core15Call(0);Core15Call(1);
 VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetPage(0);VDP_SetVerticalOffset(0);
 if(*((const u8*)0x2d)>=2){VDP_RegWrite(25,0);VDP_RegWrite(26,0);VDP_RegWrite(27,0);}
 VDP_EnableSprite(FALSE);VDP_ClearVRAM();VDP_SetColor(0);Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(4,"KEEN 0.9.36 CORE / ROM / NO DRAW");
 Text(20,"CPU: ");Print_DrawHex8(cpu);Print_DrawText(" HZ: ");Print_DrawInt(VDP_GetFrequency()?50:60);
 Text(36,R[1]==1?"COMPLETE: 4 X 700 STEPS":"ABORTED: DO NOT COMPARE");
 Text(52,"TICKS (HEX): ");Print_DrawHex16(R[2]);
 Text(68,"TRACE: ");Print_DrawHex16(R[4]);Print_DrawText(" STEPS: ");Print_DrawHex16(R[3]);
 Text(84,"X/Y: ");Print_DrawHex16(R[5]);Print_DrawChar('/');Print_DrawHex16(R[6]);
 Text(100,"VX/VY: ");Print_DrawHex16(R[7]);Print_DrawChar('/');Print_DrawHex16(R[8]);
 Text(116,"WALL/CEILING/SLOPE: ");Print_DrawHex16(R[9]);Print_DrawChar('/');Print_DrawHex16(R[10]);Print_DrawChar('/');Print_DrawHex16(R[11]);
 Text(132,"RESPAWNS/STATE: ");Print_DrawHex16(R[12]);Print_DrawChar('/');Print_DrawHex16(R[13]);
 Text(154,"COMPARE WITH KCORE17 IN DOS");Text(172,"SAME CPU / SAME PAYLOAD / NO FPS");
 VDP_CommandWait();for(;;)Halt();
}

#include "finish.c"
