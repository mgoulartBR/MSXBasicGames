#ifndef KEEN_BAY_SPAWNS_H
#define KEEN_BAY_SPAWNS_H
static const u8 bay_spawn[4][3]={{81,11,45},{60,8,41},{39,17,41},{18,19,41}};
#endif
