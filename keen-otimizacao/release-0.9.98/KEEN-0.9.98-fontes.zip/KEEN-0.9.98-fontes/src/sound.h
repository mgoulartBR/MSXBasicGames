// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_SOUND_H
#define KEEN_SOUND_H
#include "msxgl.h"
enum {SFX_JUMP=1,SFX_THROW,SFX_PICKUP,SFX_HIT,SFX_DEATH,SFX_LIFE,SFX_KEY,SFX_EMPTY,SFX_COMPLETE,SFX_ENTER,SFX_BOMB};
void SoundInit(void) __banked;
void SoundPlay(u8 effect) __banked;
#endif
