static const u8 boobus_spawn[3]={21,26,61};
