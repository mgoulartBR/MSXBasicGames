#ifdef __SDCC
void CityMapBankMarker(void) {}
#else
#include "campaign_impl.c"
#endif
