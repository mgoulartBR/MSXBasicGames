// Bank 50: Melon Mines render records and hostile-seed reflection.
#include "mines.h"
#include "bridge.h"
#include "tomato.h"
#include "cart.h"
#include "keydoor.h"
#include "combat_assets.h"
#include "mines_spawns.h"
#include "benchmark.h"
extern volatile u16 camera_px,camera_py;
extern volatile u16 simulation_ticks;
// Original ProjectileReact: halve rebound speed, slope-specific reflection,
// remove exhausted hostile shots. Same angle table as Flower Power.
static const u8 mines_rebound[8][8]={
 {0,0,0,0,0,0,0,0},{7,6,5,4,3,2,1,0},{5,4,3,2,1,0,15,14},{5,4,3,2,1,0,15,14},
 {3,2,1,0,15,14,13,12},{9,8,7,6,5,4,3,2},{9,8,7,6,5,4,3,2},{11,10,9,8,7,6,5,4}};
void MinesBounce(MinesSeed* s,u8 wall) __banked
{
 u16 ax=s->vx<0?-s->vx:s->vx,ay=s->vy<0?0:s->vy,speed,v;u8 angle;
 if(ax>ay){if(ax>ay*2){angle=0;speed=ax*286U;}else{angle=1;speed=ax*362U;}}
 else{if(ay>ax*2){angle=3;speed=ay*256U;}else{angle=2;speed=ay*286U;}}
 if(s->vx>0)angle=7-angle;speed>>=1;angle=mines_rebound[wall&7][angle];v=speed/286U;
 switch(angle){
 case 0:s->vx=v;s->vy=-(i16)v/2;break;
 case 1:v=speed/362U;s->vx=v;s->vy=-(i16)v;break;
 case 2:s->vy=-(i16)v;s->vx=v/2;break;
 case 3:case 4:case 11:case 12:s->vx=0;s->vy=-(i16)(speed/256);break;
 case 5:s->vy=-(i16)v;s->vx=-(i16)v/2;break;
 case 6:v=speed/362U;s->vx=s->vy=-(i16)v;break;
 case 7:s->vx=-(i16)v;s->vy=-(i16)v/2;break;
 case 8:s->vx=-(i16)v;s->vy=v/2;break;
 case 9:v=speed/362U;s->vx=-(i16)v;s->vy=v;break;
 case 10:s->vy=v;s->vx=-(i16)v/2;break;
 case 13:s->vy=v;s->vx=v/2;break;
 case 14:v=speed/362U;s->vx=s->vy=v;break;
 default:s->vx=v;s->vy=v/2;break;
 }
 if(speed<4096)s->active=0;
}
static void MinesPut(DrawObject* out,u8* count,u16 x,u16 y,u8 frame)
{
 const SpriteDef* sp;i16 sx=x-camera_px,sy=y-camera_py;u8 slot;
 // All Mines sprite extents (offset + size) fit within 128 pixels.
 // Reject distant objects before consulting their frame metadata.
 if(sx<=-128 || sx>=256 || sy<=-128 || sy>=192)return;
 sp=&sprites[1][frame];sx+=SPR_OX(sp);sy+=SPR_OY(sp);
 if(sx<=-(i16)sp->w || sx>=256 || sy<=-(i16)sp->h || sy>=192)return;
 if(*count>=11){mines_overflow=1;return;}
 slot=*count+5;if(slot>=11)slot-=11;out+=slot;out->x=x;out->y=y;out->frame=frame;out->visible=1;++*count;
}
void MinesCollect(DrawObject* out) __banked
{
 u8 i,count=0,down;CombatObject* a;Tomato* t;MinesSeed* s;Cart* c;
 for(i=0;i<11;++i)out[i].visible=0;
 if(!bench_requested && !(enemy_mode&2)){
  for(i=0;i<6;++i){a=mines_walkers+i;if(!a->active)continue;
   MinesPut(out,&count,(a->x>>4)-(a->state==1?0:24),(a->y>>4)-(a->state==1?0:4),a->frame);
  }
  for(i=0;i<3;++i)if(mines_active[i]){down=mines_spawn[i+6][2]==52;
   MinesPut(out,&count,(u16)mines_spawn[i+6][0]*16-24,(u16)mines_spawn[i+6][1]*16-4,(down?136:138)+(mines_timer[i]<=12));
  }
 }
 for(i=0;i<TOMATO_COUNT;++i){t=tomatoes+i;if(t->active && !(enemy_mode&2))MinesPut(out,&count,t->x>>4,t->y>>4,t->frame);}
 for(i=0;i<3;++i){c=carts+i;MinesPut(out,&count,c->x>>4,c->y>>4,CART_FRAME+((simulation_ticks/5)&1));}
 if(!key_taken || key_rise)MinesPut(out,&count,KEY_X/16,KEY_Y/16-(key_taken?(40-key_rise)/2:0),key_taken?KEY_RISE_FRAME:KEY_FRAME+((simulation_ticks/20)&1));
 if(door_state!=2)MinesPut(out,&count,DOOR_X/16,DOOR_Y/16-(u16)door_ticks*2,DOOR_FRAME);
 if(!bench_requested && !(enemy_mode&2))for(i=0;i<4;++i){s=mines_seeds+i;if(s->active)MinesPut(out,&count,(s->x>>4)-24,(s->y>>4)-4,s->frame);}
}

void MinesReset(void) __banked
{
 u8 i;CombatObject* a;
 if(active_level!=2 || bench_requested)return;
 for(i=0;i<6;++i){a=mines_walkers+i;a->x=(u16)mines_spawn[i][0]*256;a->y=(u16)mines_spawn[i][1]*256;
  if(i<4)a->y-=497; // SpawnTater: -512 +15.
  a->vx=a->vy=a->timer=0;a->active=a->state=a->tick=0;a->ground=0;a->dir=1;a->frame=i<4?124:112;
 }
 for(i=0;i<3;++i){mines_timer[i]=200-(i*37);mines_active[i]=0;}
 for(i=0;i<4;++i)mines_seeds[i].active=0;
 mines_random=73;mines_overflow=0;
}

void BridgeMelon(CombatObject* a,u8 i) __banked
{
 u8 n;CombatObject* s;
 if(a->timer)--a->timer;
 if(a->state==2 && a->timer==6){
  for(n=7;n<11;++n){s=bridge_actors+n;if(s->active)continue;
   s->x=a->x+(i==5?384:0);s->y=a->y+128;
   bridge_random=bridge_random*33+17;
   s->vx=48+(bridge_random>>4);if(i==5)s->vx=-s->vx;s->vy=-20;
   s->active=1;s->timer=0;s->tick=0;s->dir=i==6;s->frame=i==5?142:140;break;
  }
 }
 if(a->timer)return;
 if(a->state){a->state=0;a->frame=i==5?138:136;a->timer=200;}
 else{a->state=2;a->frame=(i==5?138:136)+1;a->timer=12;}
}

void BridgeBounce(CombatObject* a,u8 wall) __banked
{
 MinesSeed seed;seed.vx=a->vx;seed.vy=a->vy;seed.active=a->active;
 MinesBounce(&seed,wall);a->vx=seed.vx;a->vy=seed.vy;a->active=seed.active;
}

#include "city.c"

#include "apple.c"
