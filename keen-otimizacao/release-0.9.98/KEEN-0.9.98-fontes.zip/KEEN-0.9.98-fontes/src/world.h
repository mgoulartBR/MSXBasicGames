#ifndef KEEN_WORLD_H
#define KEEN_WORLD_H
#include "msxgl.h"
extern u8 world_map[9835],world_collision[1168],active_level;
extern u8 cart_cache_valid;
u16 MapTile(u16 i);
void MapSet(u16 i,u16 tile);
#define LEVEL_INDEX (active_level-1)
#define MAP_WIDTH (world_collision[1120])
#define MAP_HEIGHT (world_collision[1121])
#define LEVEL_SPAWN_X (*((u16*)(world_collision+1122)))
#define LEVEL_SPAWN_Y (*((u16*)(world_collision+1124)))
#define LEVEL_LEFT (world_collision[1126])
#define LEVEL_PICKUPS (world_collision[1127])
#endif
