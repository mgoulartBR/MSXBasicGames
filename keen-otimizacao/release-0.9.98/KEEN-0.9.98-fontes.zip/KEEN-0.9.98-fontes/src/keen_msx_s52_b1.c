// 0.9.43: Tater renderer moved to segment 101 to preserve Apple atlas.
#include "msxgl.h"
