// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_BRIDGE_H
#define KEEN_BRIDGE_H
#include "combat.h"
#include "world.h"
// Stage 3 occupies 4534 map bytes. Its private actors use the otherwise unused
// tail, never touched in other stages (Melon Mines needs all 9835 map bytes).
#define bridge_actors ((CombatObject*)(world_map+9600))
#define bridge_random (world_map[9800])
typedef char BridgeStorageFits[(11*sizeof(CombatObject)<=200)?1:-1];
void BridgeBounce(CombatObject* seed,u8 wall) __banked;
void BridgeMelon(CombatObject* mouth,u8 index) __banked;
void BridgeReset(void) __banked;
void BridgeSelect(void) __banked;
void BridgeTick(void) __banked;
u8 BridgeHit(CombatObject* shot) __banked;
void BridgeCollect(DrawObject* out) __banked;
#endif
