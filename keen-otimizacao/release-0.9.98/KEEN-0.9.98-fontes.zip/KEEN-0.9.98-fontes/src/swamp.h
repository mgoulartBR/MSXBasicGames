#ifndef KEEN_SWAMP_H
#define KEEN_SWAMP_H
#include "combat.h"
#include "world.h"
#define swamp_actors ((CombatObject*)(world_map+7200))
#define swamp_overflow world_map[7296]
#define swamp_bombs world_map[7297]
#define swamp_rise (world_map+7298)
void SwampLoad(void) __banked;
void SwampReset(void) __banked;
void SwampSelect(void) __banked;
void SwampTick(void) __banked;
u8 SwampHit(CombatObject*) __banked;
void SwampCollect(DrawObject*) __banked;
void SwampStatic(DrawObject*) __banked;
void SwampAtlas(u8);
void SwampObjectsTick(void) __banked;
void SwampLoseBombs(void) __banked;
#endif
