// Phase 3: identical position-independent Z80 bytes in ROM and existing page-3 RAM.
#include "msxgl.h"
#include "world.h"
#include "hw_tomato.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 cpu_mode;
u8 CpuRead(void) __banked;
volatile u16 p3sum;
#include "session.h"
#define p3done (session.experiments.p3done)
#define p3stage (session.experiments.p3stage)
#define p3ok (session.experiments.p3ok)
#define p3cpu (session.experiments.p3cpu)
#define p3slot (session.experiments.p3slot)
#define p3hz (session.experiments.p3hz)
#define p3rom (session.experiments.p3rom)
#define p3ram (session.experiments.p3ram)
#define p3checks (session.experiments.p3checks)
#define p3size (session.experiments.p3size)
extern const u8 Phase3KernelEnd[];
void Phase3Kernel(void) __naked
{
 __asm
 ld bc,#32768
 ld de,#0
 ld hl,#0
 ld (_p3sum),hl
p3_loop:
 push bc
 push de
 ld a,e
 and #7
 ld b,a
 srl d
 rr e
 srl d
 rr e
 srl d
 rr e
 pop hl
 push hl
 add hl,de
 ld de,#_world_map
 add hl,de
 ld e,(hl)
 inc hl
 ld d,(hl)
 ld a,b
 or a
 jr z,p3_decoded
p3_shift:
 srl d
 rr e
 djnz p3_shift
p3_decoded:
 ld a,d
 and #1
 ld d,a
 ld hl,#_world_collision
 add hl,de
 ld e,(hl)
 ld d,#0
 ld hl,(_p3sum)
 add hl,de
 ld (_p3sum),hl
 pop de
 ld hl,#37
 add hl,de
 ld de,#5000
 or a
 sbc hl,de
 jr nc,p3_index
 add hl,de
p3_index:
 ex de,hl
 pop bc
 dec bc
 ld a,b
 or c
 jr nz,p3_loop
 ret
_Phase3KernelEnd::
 __endasm;
}
static u16 Clock(void){return *((volatile u16*)M_JIFFY);}
static void Text(u8 y,const char* s){Print_SetPosition(4,y);Print_DrawText(s);}
static void Times(u8 y,const char* label,u16 a,u16 b){Text(y,label);Print_DrawInt(a);Print_DrawChar('/');Print_DrawInt(b);Print_DrawText(" T");}
void Phase3Run(void) __banked
{
 u16 i,start;u8 round;u8* ram=world_map+6000;
 p3done=0;p3stage=0;p3ok=1;p3hz=VDP_GetFrequency()?50:60;
 p3cpu=*((const u8*)0x2d)==3?CpuRead():cpu_mode;p3slot=(g_PortPrimarySlot>>6)&3;
 if(g_EXPTBL[p3slot]&0x80)p3slot|=0x80|(((~g_SLTSL>>6)&3)<<2);
 p3size=(u16)Phase3KernelEnd-(u16)Phase3Kernel;
 if(p3size>256)p3ok=0;
 else{
  Mem_Copy((const void*)Phase3Kernel,ram,p3size);
  for(i=0;i<p3size;++i)if(ram[i]!=((const u8*)Phase3Kernel)[i])p3ok=0;
 }
 HWHide();VDP_CommandWait();
 if(p3ok){
  // ABBA order. Setup/copy/printing are excluded from the timed regions.
  p3stage=1;start=Clock();Phase3Kernel();p3rom[0]=Clock()-start;p3checks[0]=p3sum;
  p3stage=2;start=Clock();((void(*)(void))ram)();p3ram[0]=Clock()-start;p3checks[1]=p3sum;
  p3stage=3;start=Clock();((void(*)(void))ram)();p3ram[1]=Clock()-start;p3checks[2]=p3sum;
  p3stage=4;start=Clock();Phase3Kernel();p3rom[1]=Clock()-start;p3checks[3]=p3sum;
  for(round=0;round<4;++round)if(p3checks[round]!=0x386e)p3ok=0;
 }
 p3stage=0;
 VDP_EnableDisplay(FALSE);VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetPage(0);VDP_SetVerticalOffset(0);
 if(*((const u8*)0x2d)>=2){VDP_RegWrite(25,0);VDP_RegWrite(26,0);VDP_RegWrite(27,0);}
 VDP_EnableSprite(FALSE);VDP_ClearVRAM();VDP_SetColor(0);Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(4,"KEEN 0.9.12 - PHASE 3 / ROM-RAM");
 Text(20,p3ok?"PASS: SAME BYTES / SAME CHECKSUM":"FAIL: COPY OR CHECKSUM - STOP");
 Text(36,"CPU: ");Print_DrawHex8(p3cpu);Print_DrawText(" HZ: ");Print_DrawInt(p3hz);
 Text(52,"RAM SLOT: ");Print_DrawHex8(p3slot);Print_DrawText(" RAMAD3: ");Print_DrawHex8(*((const u8*)0xf344));
 Text(68,"ROM: ");Print_DrawHex16((u16)Phase3Kernel);Print_DrawText(" BANK 2D  RAM: ");Print_DrawHex16((u16)ram);
 Text(84,"KERNEL BYTES: ");Print_DrawInt(p3size);
 Times(104,"ROM RUNS: ",p3rom[0],p3rom[1]);Times(120,"RAM RUNS: ",p3ram[0],p3ram[1]);
 Text(136,"CHECKS: ");for(round=0;round<4;++round){Print_DrawHex16(p3checks[round]);Print_DrawChar(' ');}
 Text(152,"32768 LOOKUPS EACH / ORDER ABBA");Text(168,"T = VBLANK TICKS; LOWER IS FASTER");Text(184,"PHOTO RESULTS; RESET FOR NEXT CPU");
 VDP_CommandWait();VDP_EnableDisplay(TRUE);p3done=1;
 for(;;)Halt();
}

#include "grove_static.c"
