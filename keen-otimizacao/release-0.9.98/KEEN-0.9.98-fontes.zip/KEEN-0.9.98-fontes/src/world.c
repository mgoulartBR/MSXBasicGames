#include "hw_tomato.h"
#include "world.h"
u8 world_map[9835],world_collision[1168],active_level;
#include "hotcode.h"
u8 hot_code[48],hot_enabled,hot_ok,hot_slot;
u16 hot_entry;
#ifdef __SDCC
// SDCC call(1): HL argument, DE result. Same trampoline for ROM and RAM.
u16 MapTile(u16 i) __naked {
 i;
 __asm
 ld de,(_hot_entry)
 push de
 ret
 __endasm;
}
// Position independent body: only relative internal branches; same data in RAM.
u16 MapTileKernel(u16 i) __naked {
 i;
 __asm
 ld d,h
 ld e,l
 srl h
 rr l
 srl h
 rr l
 srl h
 rr l
 add hl,de
 ld a,e
 and #7
 ld b,a
 ld de,#_world_map
 add hl,de
 ld e,(hl)
 inc hl
 ld d,(hl)
 or a
 jr z,mt_done
mt_shift:
 srl d
 rr e
 djnz mt_shift
mt_done:
 ld a,d
 and #1
 ld d,a
 ret
_MapTileKernelEnd::
 __endasm;
}
u16 CityMapTile(u16 i) __naked {
 i;
 __asm
 ld bc,#(_world_map+1677)
 push bc
_DictionaryMapTile::
 ld a,l
 and #7
 push af
 srl h
 rr l
 srl h
 rr l
 srl h
 rr l
 call _MapTileKernel
 ex de,hl
 add hl,hl
 add hl,hl
 add hl,hl
 pop af
 ld e,a
 ld d,#0
 add hl,de
 ld d,h
 ld e,l
 srl h
 rr l
 srl h
 rr l
 srl h
 rr l
 add hl,de
 ld a,e
 and #7
 ld b,a
 pop de
 add hl,de
 ld e,(hl)
 inc hl
 ld d,(hl)
 or a
 jr z,city_done
city_shift:
 srl d
 rr e
 djnz city_shift
city_done:
 ld a,d
 and #1
 ld d,a
 ret
 __endasm;
}
u16 CastleMapTile(u16 i) __naked {
 i;
 __asm
 ld bc,#(_world_map+957)
 push bc
 jp _DictionaryMapTile
 __endasm;
}

#else
u16 MapTileKernel(u16 i){u16 n=i+(i>>3);return (((u16)world_map[n]|((u16)world_map[n+1]<<8))>>(i&7))&511;}
u16 CityMapTile(u16 i){u16 j=MapTileKernel(i>>3)*8+(i&7),n=j+(j>>3);return (((u16)world_map[1677+n]|((u16)world_map[1678+n]<<8))>>(j&7))&511;}
u16 CastleMapTile(u16 i){u16 j=MapTileKernel(i>>3)*8+(i&7),n=j+(j>>3);return (((u16)world_map[957+n]|((u16)world_map[958+n]<<8))>>(j&7))&511;}
u16 MapTile(u16 i){return active_level==12?CastleMapTile(i):active_level==6?CityMapTile(i):MapTileKernel(i);}
#endif
void MapSet(u16 i,u16 tile){u16 n=i+(i>>3),v=(u16)world_map[n]|((u16)world_map[n+1]<<8);u8 s=i&7;cart_cache_valid=0;hw->scene_map_dirty=3;hw->check_valid=0;v=(v&~(511U<<s))|(tile<<s);world_map[n]=v;world_map[n+1]=v>>8;}

#include "session.h"
SessionState session;
