#ifndef KEEN_BAY_H
#define KEEN_BAY_H
#include "combat.h"
#include "world.h"
#define bay_actors ((CombatObject*)(world_map+7200))
#define bay_overflow world_map[7264]
void BayLoad(void) __banked;
void BayReset(void) __banked;
void BaySelect(void) __banked;
void BayTick(void) __banked;
u8 BayHit(CombatObject*) __banked;
void BayCollect(DrawObject*) __banked;
void BayStatic(DrawObject*) __banked;
void BayAtlas(u8);
#endif
