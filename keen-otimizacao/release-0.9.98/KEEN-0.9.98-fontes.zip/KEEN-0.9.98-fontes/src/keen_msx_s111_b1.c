#include "actors_damage.c"
