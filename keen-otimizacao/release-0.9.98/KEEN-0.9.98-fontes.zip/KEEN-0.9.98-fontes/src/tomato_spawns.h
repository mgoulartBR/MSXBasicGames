// Generated from the EGA 1.93 object plane, object 42.
static const u8 tomato_spawn[TOMATO_COUNT][2]={{68,18},{75,21},{80,21},{35,85},{58,89},{74,89}};
