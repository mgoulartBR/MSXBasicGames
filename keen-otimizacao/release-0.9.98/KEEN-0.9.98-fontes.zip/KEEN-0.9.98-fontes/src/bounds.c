// SPDX-License-Identifier: GPL-2.0-or-later
// Non-reentrant renderer scratch avoids SDCC register-allocation failures.
#include "msxgl.h"
#include "world.h"
void BoundsRow(void);
extern u8 g_CurrentSegment;
extern volatile u16 camera_px;
extern volatile u8 camera_y;
u8 changed_l[11],changed_r[11];
volatile u8 bounds_mask;
volatile u8 bounds_left,bounds_right;
volatile u16 bounds_ptr;
static u8 row;
void ChangedBounds(i16 shift) __banked
{
    u8 saved_bank=g_CurrentSegment;
    i8 index=shift/8;
    if(active_level!=1){for(row=0;row<11;++row){changed_l[row]=0;changed_r[row]=32;}return;}
    u16 cell=camera_px>>3;
    index=index<0?index+6:index+5;
    // Temporary ASCII16 bank switch; restore map bank before physics/rendering.
    *(volatile u8*)0x77ff=6;
    bounds_ptr=0x8000+(u16)index*1258+(u16)camera_y*34+(cell>>3);
    bounds_mask=(u8)(1U<<(cell&7));
    for(row=0;row<11;++row)
    {
        BoundsRow();
        changed_l[row]=bounds_left;changed_r[row]=bounds_right;bounds_ptr+=34;
    }
    *(volatile u8*)0x77ff=saved_bank;
}
