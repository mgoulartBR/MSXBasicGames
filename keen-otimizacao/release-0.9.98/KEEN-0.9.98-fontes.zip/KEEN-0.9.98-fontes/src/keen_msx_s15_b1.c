#include "tomato.c"
#include "bridge.c"
#include "hill.c"
#include "mines.c"

#include "rapids.h"
void EnemyStep(CombatObject* a,u8 type) __banked{if(type)MinesAspar(a);else BridgeWalker(a,0);}
void EnemyCache(void) __banked{u8 i;for(i=0;i<8;++i)wall_key[i]=65535;}

#include "pass.h"
void EnemyBrocco(CombatObject* a) __banked{BridgeWalker(a,3);}
