// V9938 RGB333 palette for the supplied title artwork.
static const u8 title_palette[32]={0,0,5,0,7,0,55,3,0,7,0,4,119,0,114,7,112,4,64,2,112,0,64,0,116,4,68,4,36,0,119,7};
