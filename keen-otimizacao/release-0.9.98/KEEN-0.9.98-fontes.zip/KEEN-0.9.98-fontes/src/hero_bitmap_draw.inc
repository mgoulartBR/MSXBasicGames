void HERO_BITMAP_FUNCTION(u8 page,DrawObject* ob,u8 frame) __banked
{
    u8 row,texture_y,w,h,band,rows,band_end,iw=32,ih=32,view_h=hardware_scroll?192:176;
    u16 x,y,dx,dy;
    i16 left=ob->x-camera_px,top=ob->y-camera_py,l=0,t=0,r,b;
    const u8* pixels=hero_bitmap[frame];
    const SpriteDef* sp=&sprites[LEVEL_INDEX][ob->frame];
    l=SPR_OX(sp);t=SPR_OY(sp);r=l+sp->w;b=t+sp->h;
    if(left>=256 || top>=view_h || left+iw<=0 || top+ih<=0){ob->visible=0;return;}
    if(left+l<0)l=-left;if(top+t<0)t=-top;if(left+r>256)r=256-left;if(top+b>view_h)b=view_h-top;
    // Dedicated x128..191 scratch; carts/objects use x0..95.
    // Keep an original bitmap frame cached on each page while it is occluded.
    dx=HWTexture(page,ob->frame,ih);texture_y=dx;
    VDP_CommandWait();
    if(!(dx&256)){
        for(row=0;row<32;++row)VDP_WriteVRAM(pixels+(u16)row*16,(u16)page*32768+(u16)(u8)(texture_y+row)*128+64,0,16);
    }
    {
        for(y=t;y<b;y+=h){
            dy=hardware_scroll?(ob->y+y)&255:16+top+y;
            h=b-y;if(hardware_scroll && dy+h>256)h=256-dy;if(((texture_y+y)&255)+h>256)h=256-((texture_y+y)&255);
            for(x=l;x<r;x+=w){
                dx=hardware_scroll?(ob->x+x)&255:left+x;
                w=r-x;if(hardware_scroll && dx+w>256)w=256-dx;
                g_VDP_Command.SX=128+x;g_VDP_Command.SY=(u16)page*256+((texture_y+y)&255);
                g_VDP_Command.DX=dx;g_VDP_Command.DY=(u16)page*256+dy;
                g_VDP_Command.NX=w;g_VDP_Command.NY=h;g_VDP_Command.ARG=0;
                g_VDP_Command.CMD=VDP_CMD_LMMM+VDP_OP_TIMP;VDP_CommandSetupR32();
            }
        }
    }
}
