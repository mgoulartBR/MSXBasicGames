// Original object-plane order: Tater, Aspar, Squasher, Tomato, keys, doors, bombs.
static const u8 pass_spawn[12][3]={{30,9,47},{18,10,47},{9,13,47},{16,29,47},{16,40,45},{8,40,57},{26,40,57},{16,67,41},{36,20,49},{4,27,49},{4,32,32},{33,7,33}};
