#ifndef KEEN_SWAMP_SPAWNS_H
#define KEEN_SWAMP_SPAWNS_H
static const u8 swamp_spawn[9][3]={{61,7,45},{67,7,45},{32,15,41},{10,22,57},{13,22,57},{58,22,57},{66,3,31},{67,3,31},{68,3,31}};
#endif
