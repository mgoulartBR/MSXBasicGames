// VDP data-port pacing: plain OTIR (21 T/byte) overruns the V9938/V9958 data port at 7.16 MHz and
// bytes are dropped. outi+nop+jr = 32 T/byte. Static per bank: a banked helper would remap the
// 0x8000 window and hide the caller's source data.
typedef struct {const u8* src;u16 dst;u16 n;u8 page;} VramArgs;
static void VramPacedAsm(VramArgs* a) __sdcccall(1) __naked
{
 a;
 __asm
  push ix
  push hl
  pop ix
  ld e,4 (ix)
  ld d,5 (ix)
  ld a,d
  or e
  jr z,vp_done
  ld a,6 (ix)
  add a,a
  add a,a
  ld c,a
  ld a,3 (ix)
  rlca
  rlca
  and #3
  add a,c
  di
  out (0x99),a
  ld a,#0x8E
  out (0x99),a
  ld a,2 (ix)
  out (0x99),a
  ld a,3 (ix)
  and #0x3F
  or #0x40
  ei
  out (0x99),a
  ld l,0 (ix)
  ld h,1 (ix)
  ld c,#0x98
  ld a,(_vdp_fast)
  or a
  jr z,vp_fastloop
vp_loop:
  outi
  nop
  dec de
  ld a,d
  or e
  jr nz,vp_loop
  jr vp_done
vp_fastloop:
  ld b,e
  ld a,e
  or a
  jr z,vp_hi
  otir
vp_hi:
  ld a,d
  or a
  jr z,vp_done
vp_pg:
  ld b,#0
  otir
  dec a
  jr nz,vp_pg
vp_done:
  pop ix
  ret
 __endasm;
}
extern u8 vdp_fast;   // set by DetectClock(): CPU clock high enough to overrun the VDP data port
static void VP(const u8* src,u16 dst,u8 page,u16 n)
{
 {VramArgs a;a.src=src;a.dst=dst;a.n=n;a.page=page;VramPacedAsm(&a);}
}
