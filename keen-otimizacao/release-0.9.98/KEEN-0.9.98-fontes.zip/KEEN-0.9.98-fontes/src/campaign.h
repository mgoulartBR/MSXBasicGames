#ifndef KEEN_CAMPAIGN_H
#define KEEN_CAMPAIGN_H
#include "combat.h"
#define bonus_high world_collision[1151]
extern u16 boobus_bombs;
extern u32 game_score,next_extra,bonus_taken;
extern i8 game_lives;
extern u8 restart_pending;
void CampaignNew(void) __banked;
void GivePoints(u16 points) __banked;
void BonusReset(void) __banked;
void BonusTick(void) __banked;
u8 BonusCollect(DrawObject* dest,u8 capacity) __banked;
void DeathFinish(void) __banked;
void GameOver(void) __banked;
void GameFinale(void) __banked;
#endif
