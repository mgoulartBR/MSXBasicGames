// Measured separately before choosing the delivered configuration.
#define FAST_RING_COPY 0
#define FIXED_MINES_TEXTURES 1
#define MULTI_HW_TOMATO 0
