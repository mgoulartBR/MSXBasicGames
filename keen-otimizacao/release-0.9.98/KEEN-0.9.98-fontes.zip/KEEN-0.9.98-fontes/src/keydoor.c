#include "castle.h"
#include "grove.h"
#include "apple.h"
#include "city.h"
#include "pass.h"
#include "rapids.h"
// SPDX-License-Identifier: GPL-2.0-or-later
// kd_act1.c SpawnBonus/SpawnDoor; kd_keen.c key and door contact.
#include "game.h"
#include "combat.h"
#include "world.h"
#include "keydoor.h"
extern volatile u16 camera_px,camera_py;
u8 key_owned,key_taken,key_rise,door_state,door_ticks;
void KeyDoorReset(void) __banked
{
    key_owned=key_taken=key_rise=door_state=door_ticks=0;
    combat_dirty=1;
}
void KeyDoorTick(void) __banked
{
 if(active_level==12){CastleObjectsTick();return;}
 if(active_level==8){GroveObjectsTick();return;}
 if(active_level==7){AppleObjectsTick();return;}
 if(active_level==6){CityObjectsTick();return;}
 if(active_level==5){PassObjectsTick();return;}
 if(active_level==4){RapidObjectsTick();return;}
    u16 left,right,top,bottom,door_y;
    if(active_level!=2)return;
    left=player_x+64;right=player_x+304;top=player_y+48;bottom=player_y+496;
    if(key_rise){--key_rise;combat_dirty=1;}
    if(!key_taken){
        if(right>KEY_X && left<KEY_X+240 && bottom>KEY_Y && top<KEY_Y+112){
            key_taken=key_owned=1;key_rise=40;SoundPlay(SFX_KEY);combat_dirty=1;
        }else if(simulation_ticks%20==0 && (i16)(KEY_X/16-camera_px)>-16 && (i16)(KEY_X/16-camera_px)<256 &&
                 (i16)(KEY_Y/16-camera_py)>-8 && (i16)(KEY_Y/16-camera_py)<192)combat_dirty=1;
    }
    if(door_state==2)return;
    if(door_state==1){
        combat_dirty=1;
        if(++door_ticks>=24){door_state=2;return;}
    }
    door_y=DOOR_Y-(u16)door_ticks*32;
    if(right<=DOOR_X || left>=DOOR_X+240 || bottom<=door_y || top>=door_y+1008)return;
    if(!door_state && key_owned){key_owned=0;door_state=1;combat_dirty=1;}
    // Keep the moving door solid until it has risen clear of Keen.
    if(player_x+184<DOOR_X+120)player_x=DOOR_X-305;
    else player_x=DOOR_X+241-64;
    player_vx=0;
}
