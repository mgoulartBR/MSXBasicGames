// One-time CPU configuration, outside the crowded fixed bank.
#include "cpu.c"

#include "grove_init.c"

#include "keydoor.c"
