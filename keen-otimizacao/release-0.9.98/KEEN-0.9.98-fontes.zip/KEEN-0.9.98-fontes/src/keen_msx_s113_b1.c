#include "scroll_experiments.h"
#include "sprite_color_pass.h"
// Exact opaque interiors use one direct copy; boundaries retain AND/OR.
#include "game.h"
#include "combat.h"
#include "combat_assets.h"
#include "world.h"
#include "fast_enemy_ids.h"
#include "timp_frames.h"
#include "fast_enemy_data.h"
#include "fast_enemy_choices.h"
#include "render_cost.h"
extern volatile u8 hardware_scroll;
extern volatile u16 camera_px,camera_py;
void FastEnemy(u8 page,DrawObject* ob) __banked
{
 const SpriteDef* sp=sprites[LEVEL_INDEX]+ob->frame;
 const u8* data=fast_parts[fast_ids[LEVEL_INDEX][ob->frame]];
 u8 count=*data++,n,opaque,dx,dy,cw,ch,timp=timp_bits[LEVEL_INDEX][ob->frame>>3]&(1<<(ob->frame&7));
 i16 left=ob->x+SPR_OX(sp)-camera_px,top=ob->y+SPR_OY(sp)-camera_py;
 i16 l,t,r,b,x,y;u16 base=(u16)page*256;
 if(left>=256 || top>=(hardware_scroll?192:176) || left+sp->w<=0 || top+sp->h<=0){ob->visible=0;return;}
 // Compare the actual clipped/wrapped plan with a single masked rectangle.
#if EXP_COST_CHOICE
 // All full-view plans already win; consult the table only at a clip edge.
 if(left<0 || top<0 || left+sp->w>256 || top+sp->h>(hardware_scroll?192:176)){
 u8 whole[6]={1,0,0,0,0,0};
 whole[3]=sp->w;whole[4]=sp->h;
 dx=hardware_scroll?(ob->x+SPR_OX(sp))&255:left;
 dy=hardware_scroll?(ob->y+SPR_OY(sp))&255:top+16;
 if(WholeChoice(render_choices[fast_ids[LEVEL_INDEX][ob->frame]],left,top,sp->w,sp->h,dx,dy,0,0,hardware_scroll?192:176)){
  data=whole+1;count=1;
 }
 }
#endif
 for(n=0;n<count;++n,data+=5){
  l=data[0];t=data[1];r=data[2];b=data[3];opaque=data[4];
  if(left+l<0)l=-left;if(top+t<0)t=-top;
  if(left+r>256)r=256-left;if(top+b>(hardware_scroll?192:176))b=(hardware_scroll?192:176)-top;
  for(y=t;y<b;y+=ch){
   dy=hardware_scroll?(ob->y+SPR_OY(sp)+y)&255:top+y+16;
   ch=b-y;if((u16)dy+ch>256)ch=256-dy;
   for(x=l;x<r;x+=cw){
    dx=hardware_scroll?(ob->x+SPR_OX(sp)+x)&255:left+x;
    cw=r-x;if((u16)dx+cw>256)cw=256-dx;
    g_VDP_Command.DX=dx;g_VDP_Command.DY=base+dy;
    g_VDP_Command.NX=cw;g_VDP_Command.NY=ch;g_VDP_Command.ARG=0;
    if(!opaque && timp){
     g_VDP_Command.SX=sp->mx+x;g_VDP_Command.SY=SPR_MY(sp)+y;
     g_VDP_Command.CMD=VDP_CMD_LMMM+VDP_OP_TIMP;VDP_CommandSetupR32();continue;
    }
    if(!opaque){
     g_VDP_Command.SX=sp->mx+x;g_VDP_Command.SY=SPR_MY(sp)+y;
     g_VDP_Command.CMD=VDP_CMD_LMMM+VDP_OP_AND;VDP_CommandSetupR32();
    }
    g_VDP_Command.SX=sp->cx+x;g_VDP_Command.SY=SPR_CY(sp)+y;
    g_VDP_Command.CMD=opaque?(((sp->cx+x|dx|cw)&1)?VDP_CMD_LMMM+VDP_OP_IMP:VDP_CMD_HMMM):VDP_CMD_LMMM+VDP_OP_OR;
    if(opaque)VDP_CommandSetupR32();else SpriteColorPass();
   }
  }
 }
}
