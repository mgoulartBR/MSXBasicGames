#ifndef KEEN_COMBAT_H
#define KEEN_COMBAT_H
#include "msxgl.h"
#include "sound.h"
#include "pickups.h"
#define ACTOR_COUNT 29
extern volatile u8 enemy_mode;
extern volatile u8 enemy_probe[4];
typedef struct {u16 x,y; i16 vx,vy;u16 timer;u8 active,frame,ground,state,dir,tick;} CombatObject;
extern CombatObject enemy,shots[2];
extern volatile u8 hero_frame,hero_visible,death_ticks,throw_ticks,combat_dirty;
extern volatile u16 shots_fired,flower_hits,flower_returns,defeats;
void CombatReset(void) __banked;
void CombatTick(u8 input) __banked;
void ShotTick(CombatObject*) __banked;
typedef struct {u16 x,y;u8 frame,visible;} DrawObject;
extern u8 actors_partial;
extern DrawObject actors_old[2][ACTOR_COUNT];
void ActorsPrepare(u8 page,DrawObject* next,u8 preserve) __banked;
void ActorsDraw(u8 page) __banked;
#endif
