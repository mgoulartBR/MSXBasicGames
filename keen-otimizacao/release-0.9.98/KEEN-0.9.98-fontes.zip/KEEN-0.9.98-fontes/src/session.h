// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_SESSION_H
#define KEEN_SESSION_H
#include "combat.h"
// Startup experiments and normal Melon Mines gameplay never run together.
// Keep all experiment fields distinct within the diagnostic view.
typedef struct {
 u8 bench_done,bench_status,bench_hz,bench_cpu;
 u16 bench_frames,bench_elapsed,bench_shortest,bench_longest,bench_avg10,bench_min10,bench_max10,bench_scroll_x,bench_scroll_y;
 u8 phase2_done,phase2_stage,phase2_status,phase2_hz,phase2_cpu;
 u16 phase2_logic,phase2_cpu_ticks,phase2_vdp,phase2_checksum,phase2_steps,phase2_shots,phase2_hits;
 u8 p3done,p3stage,p3ok,p3cpu,p3slot,p3hz;
 u16 p3rom[2],p3ram[2],p3checks[4],p3size;
} ExperimentState;
typedef union {volatile ExperimentState experiments;CombatObject mines_walkers[6];} SessionState;
extern SessionState session;
#endif
