// Original EGA object plane: Taters, Asparagustos, right/down Melon Lips.
#ifndef KEEN_MINES_SPAWNS_H
#define KEEN_MINES_SPAWNS_H
static const u8 mines_spawn[9][3]={{9,17,47},{49,21,47},{62,42,47},{71,42,47},{28,68,45},{76,68,45},{65,16,51},{82,14,52},{78,15,52}};
#endif
