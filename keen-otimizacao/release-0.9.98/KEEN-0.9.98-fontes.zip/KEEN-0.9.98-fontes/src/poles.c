// Included in game.c (bank 7). Original pole tile flag, speeds and jump grace.

u8 climbing;
static u8 pole_column,pole_cooldown,pole_anim;
static u8 IsPole(u8 x,u8 y)
{
    u16 tile;
    if(x>=MAP_WIDTH || y>=MAP_HEIGHT)return 0;
    tile=MapTile((u16)y*MAP_WIDTH+x);
    return (world_collision[480+(tile>>3)]>>(tile&7))&1;
}
static u8 PoleTick(u8 input,i8 dir,u8 jump)
{
    u8 vertical=input&12,frame;
    if(pole_cooldown)--pole_cooldown;
    if(!climbing){
        if(pole_cooldown || (vertical!=4 && vertical!=8))return 0;
        pole_column=(player_x+184)>>8;
        if(!IsPole(pole_column,(player_y+(vertical==4?96:496))>>8))return 0;
        climbing=1;pole_anim=0;player_x=(u16)pole_column*256-128;
        player_y+=vertical==4?-32:32;
    }else{
        if(jump && !jump_previous){
            climbing=0;pole_cooldown=19;player_vx=dir*8;
            player_vy=-20;jump_hold=10;grounded=0;jump_previous=1;return 0;
        }
        if((vertical==8 && !IsPole(pole_column,(player_y+496)>>8)) ||
           (!vertical && dir && Wall(pole_column,((player_y+496)>>8)+1,0))){
            climbing=0;pole_cooldown=19;player_vx=dir*8;player_vy=0;
            jump_hold=0;grounded=0;return 0;
        }
        if(vertical==4 && IsPole(pole_column,player_y>>8))player_y-=8;
        else if(vertical==8)player_y+=24;
        if(vertical==4 || vertical==8)++pole_anim;
    }
    player_vx=player_vy=0;grounded=0;jump_hold=0;jump_previous=jump;
    if(vertical==8)frame=39+((pole_anim>>3)&3);
    else frame=(facing_left?43:36)+(vertical==4?(pole_anim/8)%3:0);
    player_frame=frame;return 1;
}
