// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_RAPIDS_H
#define KEEN_RAPIDS_H
#include "combat.h"
#include "world.h"
#define rapid_actors ((CombatObject*)(world_map+9000))
#define rapid_keys world_map[9200]
#define rapid_rise (world_map+9201)
#define rapid_doors (world_map+9203)
#define rapid_door_ticks (world_map+9205)
#define rapid_bombs world_map[9207]
#define rapid_random world_map[9208]
#define rapid_bomb_rise (world_map+9209)
typedef char RapidStorageFits[(10*sizeof(CombatObject)<=200)?1:-1];
void RapidReset(void) __banked;
void RapidSelect(void) __banked;
void RapidTick(void) __banked;
u8 RapidHit(CombatObject*) __banked;
void RapidCollect(DrawObject*) __banked;
void RapidObjectsTick(void) __banked;
void RapidLoseBombs(void) __banked;
void RapidPush(i16) __banked;
void EnemyStep(CombatObject*,u8) __banked;
void EnemyCache(void) __banked;
#endif
