#include "scroll_experiments.h"
// Cached Mines mask/color textures move within the hidden page before edges paint.
#include "msxgl.h"
#include "hw_tomato.h"
#include "game.h"
extern volatile u8 hardware_scroll;
extern DrawObject* actors_next;
static void MoveTexture(u8 page,u8 source,u8 target,u8 width,u8 height,i8 delta)
{
 u16 base=(u16)page*256;
 u8 done=0,sy,dy,n;
 while(done<height){
  if(delta>0){
   sy=source+height-1-done;dy=target+height-1-done;n=height-done;
   if((u16)sy+1<n)n=sy+1;if((u16)dy+1<n)n=dy+1;
  }else{
   sy=source+done;dy=target+done;n=height-done;
   if((u16)sy+n>256)n=256-sy;if((u16)dy+n>256)n=256-dy;
  }
  g_VDP_Command.SX=128;g_VDP_Command.DX=128;
  g_VDP_Command.SY=base+sy;g_VDP_Command.DY=base+dy;
  g_VDP_Command.NX=(u16)width*2;g_VDP_Command.NY=n;
  g_VDP_Command.ARG=delta>0?VDP_ARG_DIY_UP:0;
  g_VDP_Command.CMD=VDP_CMD_HMMM;VDP_CommandSetupR32();done+=n;
 }
}
u8 CacheScroll(u8 page,u8 new_y) __banked
{
 i8 delta=new_y-hw->bitmap_y[page];u8 slot,frame,w,h,start=delta>0?1:0;
 if(!hardware_scroll || active_level!=2 || delta>32 || delta<-32 || (hw->bitmap_tall&(1<<page)))return 0;
 // Decide after ActorsPrepare has marked the records that will be drawn.
 // Drop unused tags before moving either slot; retained copies preserve order.
#if EXP_TEXTURE_SELECT
 if(actors_next){
  u8 i,needed,frame;
  for(slot=0;slot<2;++slot){
   frame=slot?hw->bitmap_second[page]:hw->bitmap_cached[page];needed=0;
   if(frame==255)continue;
   for(i=0;i<ACTOR_COUNT;++i)if((actors_next[i].visible&3)==3 && actors_next[i].frame==frame){needed=1;break;}
   if(!needed){if(slot)hw->bitmap_second[page]=255;else hw->bitmap_cached[page]=255;}
  }
 }
#endif
 for(slot=0;slot<2;++slot){
  u8 index=start^slot;
  frame=index?hw->bitmap_second[page]:hw->bitmap_cached[page];
  if(frame==255)continue;
  if(frame>=108 && frame<116){w=40;h=16;}
  else if(frame>=136 && frame<140){w=32;h=32;}
  else if(frame==128 || frame==129 || frame==134 || frame==135){w=64;h=32;}
  else return 0;
  MoveTexture(page,hw->bitmap_y[page]+index*32,new_y+index*32,w,h,delta);
 }
 VDP_CommandWait();return 1;
}
