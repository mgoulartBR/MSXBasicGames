#include "castle.h"
#include "game.h"
#include "world.h"
#include "combat.h"
#include "tomato.h"
#include "mines.h"
#include "bridge.h"
#include "hill.h"
#include "rapids.h"
#include "pass.h"
#include "city.h"
#include "apple.h"
#include "grove.h"
#include "bay.h"
#include "swamp.h"
#include "boobus.h"
#include "campaign.h"
static const u8 seed_frame[141]={32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,32};
static u8 ShotTouch(u16 ax,u16 ay,u8 aw,u8 ah,u16 bx,u16 by,u8 bw,u8 bh){return (i16)(ax-bx)<(i16)bw*16 && (i16)(bx-ax)<(i16)aw*16 && (i16)(ay-by)<(i16)bh*16 && (i16)(by-ay)<(i16)ah*16;}
static u8 ShotWall(u8 x,u8 y,u8 side)
{
    u16 tile;
    if(x>=MAP_WIDTH || y>=MAP_HEIGHT) return 1;
    tile=MapTile((u16)y*MAP_WIDTH+x);
    return world_collision[352+world_collision[tile]*4+side];
}
// Exact wallclip heights from kd_play.c, including half-pixel slopes.
static u16 ShotHeight(u8 shape,u8 x)
{
    switch(shape&7)
    {
        case 0: return 256;
        case 1: return 0;
        case 2: return (u16)x*8;
        case 3: return 128+(u16)x*8;
        case 4: return (u16)x*16;
        case 5: return 120-(u16)x*8;
        case 6: return 248-(u16)x*8;
        default:return 240-(u16)x*16;
    }
}

#include "projectile.c"
