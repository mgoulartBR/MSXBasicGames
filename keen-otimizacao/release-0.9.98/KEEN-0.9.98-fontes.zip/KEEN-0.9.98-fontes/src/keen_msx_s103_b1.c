#include "game.h"
#include "combat.h"
#include "combat_assets.h"
#include "hw_tomato.h"
extern volatile u8 hardware_scroll;
extern volatile u16 camera_px,camera_py;

#include "city.h"
#include "city_french_images.h"
#define CITY_BITMAP CityFrenchBitmap
#define CITY_IMAGES city_french_images
#define CITY_BASE 152
#include "city_bitmap.inc"
