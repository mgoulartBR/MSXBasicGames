// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_KEYDOOR_H
#define KEEN_KEYDOOR_H
#include "msxgl.h"
#define KEY_FRAME 86
#define DOOR_FRAME 88
#define KEY_RISE_FRAME 89
#define KEY_X (77U*256)
#define KEY_Y (59U*256)
#define DOOR_X (76U*256)
#define DOOR_Y (81U*256)
extern u8 key_owned,key_taken,key_rise,door_state,door_ticks;
void KeyDoorReset(void) __banked;
void KeyDoorTick(void) __banked;
#endif
