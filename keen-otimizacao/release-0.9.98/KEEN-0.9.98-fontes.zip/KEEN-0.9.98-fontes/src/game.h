// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_GAME_H
#define KEEN_GAME_H
#include "msxgl.h"
#include "sound.h"
extern u8 climbing,level_done;
void LevelComplete(void) __banked;
extern u16 player_x, player_y;
extern volatile u16 simulation_ticks;
extern i16 player_vx, player_vy;
extern u8 grounded, facing_left, player_frame, floor_type, jump_hold;
extern volatile u16 wall_hits, ceiling_hits, slope_hits, respawns;
void GamePushSide(i16 dx);
void Game_Reset(void) __banked;
void Game_Tick(u8 input) __banked;
void Game_Tick2(u8 input) __banked;
void RapidPush(i16 dx) __banked;
#endif
