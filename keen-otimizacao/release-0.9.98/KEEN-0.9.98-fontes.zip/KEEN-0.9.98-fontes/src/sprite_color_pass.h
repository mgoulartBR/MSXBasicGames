// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_SPRITE_COLOR_PASS_H
#define KEEN_SPRITE_COLOR_PASS_H
// Only immediately after LMMM AND for the same rectangle, CLR and ARG.
// Rewrites SX/SY, DY, NY(low), CMD. DX/NX/CLR/ARG remain unchanged.
// Rectangle height <=255; NY high byte must already be zero.
void SpriteColorPass(void);
#endif
