// Generated from original INTILE flags; bank 7.
static const u8 pole_tiles[37]={0,0,1,196,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,1,8,0,21,0,0,0,0};
