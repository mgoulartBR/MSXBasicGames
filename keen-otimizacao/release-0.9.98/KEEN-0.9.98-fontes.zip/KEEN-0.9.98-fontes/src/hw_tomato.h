// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_HW_TOMATO_H
#define KEEN_HW_TOMATO_H
#include "world.h"
#include "combat.h"
// bitmap_recent bits 0/1: bitmap eviction; bit 6: prepared HW table;
// bit 7: displayed HW table. HW table selection is independent of front_page.
typedef struct {u8 bitmap_second[2],scene_map_dirty,visible[2],cached[2],frame,x,y;u8 bitmap_tall,bitmap_recent;u8 bitmap_cached[2],bitmap_y[2];u16 check_x,check_y;u8 check_frame,check_valid,check_result;} HWState;
typedef char HWStateFitsBeforeBonus[(sizeof(HWState)<=23)?1:-1];
#define hw ((HWState*)(world_collision+1128))
extern u8* hw_attributes;
extern u8 hw_tomato_second[2],hw_tomato_second_cached[2];
#define hw_tomato (world_collision+1164)
#define hw_tomato_cached (world_collision+1166)
void HWTomatoPrepare(u8 page,DrawObject* next) __banked;
void HWMinesUpload(u8 page) __banked;
u16 HWTexture(u8 page,u8 frame,u8 height) __banked;
u8 CacheScroll(u8 page,u8 new_y) __banked;
void HWPrepare(u8 page) __banked;
void HWUpload(u8 page) __banked;
void HWFlip(u8 page) __banked;
void HWHide(void) __banked;
void HWControl(void) __banked;
#endif
