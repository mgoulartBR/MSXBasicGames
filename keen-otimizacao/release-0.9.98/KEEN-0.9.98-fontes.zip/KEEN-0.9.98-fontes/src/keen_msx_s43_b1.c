// Phase 1 only: fixed-input, normal-rendering experiment. No live FPS drawing.
#include "msxgl.h"
#include "game.h"
#include "world.h"
#include "combat.h"
#include "tomato.h"
#include "campaign.h"
#include "benchmark.h"
#include "hotcode.h"
#include "pickups.h"
extern const u8 g_Font_MGL_Sample6[];
extern volatile u8 cpu_mode;
extern volatile u16 camera_px,camera_py,render_count;
extern u8 camera_x,camera_y;
void FollowCamera(void) __banked;
void DrawScene(void) __banked;
void HWHide(void) __banked;
u8 CpuRead(void) __banked;
u8 bench_requested;
#include "session.h"
#define bench_done (session.experiments.bench_done)
#define bench_status (session.experiments.bench_status)
#define bench_hz (session.experiments.bench_hz)
#define bench_cpu (session.experiments.bench_cpu)
#define bench_frames (session.experiments.bench_frames)
#define bench_elapsed (session.experiments.bench_elapsed)
#define bench_shortest (session.experiments.bench_shortest)
#define bench_longest (session.experiments.bench_longest)
#define bench_avg10 (session.experiments.bench_avg10)
#define bench_min10 (session.experiments.bench_min10)
#define bench_max10 (session.experiments.bench_max10)
#define bench_scroll_x (session.experiments.bench_scroll_x)
#define bench_scroll_y (session.experiments.bench_scroll_y)
static u16 Clock(void){return *((volatile u16*)M_JIFFY);}
static void Text(u8 y,const char* text){Print_SetPosition(4,y);Print_DrawText(text);}
static void Number(u16 n){Print_DrawInt(n);}
static void Decimal(u16 n){Number(n/10);Print_DrawChar('.');Number(n%10);}
// One 140-tick cycle: right/left, jump, short firing pulses. Based on physics
// ticks, never rendered frame number. No user input influences the scene.
static u8 Input(u8 t){
 u8 in=t<70?2:1;
 if(t<24 || (t>=70 && t<94))in|=16;
 if((t>=30 && t<34)||(t>=100 && t<104))in|=64;
 return in;
}
void BenchmarkRun(void) __banked
{
 u16 begin,last,now,previous,credit=0,dt,oldx,oldy,oldcx,oldcy;
 u8 phase=0,in,oldframe;
 bench_done=bench_status=0;bench_frames=bench_elapsed=0;
 bench_shortest=65535;bench_longest=bench_scroll_x=bench_scroll_y=0;
 bench_hz=VDP_GetFrequency()?50:60;
 bench_cpu=*((const u8*)0x2d)==3?CpuRead():cpu_mode;
 // Same original level and original Carrot Courier. Start near tile 108,31.
 player_x=102U*256;player_y=29U*256;player_vx=player_vy=0;
 simulation_ticks=0;flower_ammo=100;enemy_mode=0;
 camera_px=player_x/16-112;camera_py=player_y/16-80;
 camera_x=camera_px>>4;camera_y=camera_py>>4;
 Game_Tick(0);CombatTick(0);FollowCamera();DrawScene();
 simulation_ticks=0;
 previous=last=begin=Clock();
 while(simulation_ticks<700 && !bench_status){
  now=Clock();credit+=(u16)(now-last)*70;last=now;
  if(credit<bench_hz){Halt();continue;}
  oldx=player_x>>4;oldy=player_y>>4;oldframe=player_frame;
  TomatoSelect();
  while(credit>=bench_hz && simulation_ticks<700){
   credit-=bench_hz;in=Input(phase);if(++phase==140)phase=0;
   Game_Tick(in);CombatTick(in);
   if(death_ticks || restart_pending || level_done){bench_status=1;break;}
  }
  if(bench_status)break;
  oldcx=camera_px;oldcy=camera_py;FollowCamera();
  if(oldcx!=camera_px)++bench_scroll_x;
  if(oldcy!=camera_py)++bench_scroll_y;
  if(combat_dirty || oldx!=(player_x>>4) || oldy!=(player_y>>4) || oldframe!=player_frame){
   DrawScene();now=Clock();dt=now-previous;previous=now;
   ++bench_frames;
   if(dt<bench_shortest)bench_shortest=dt;
   if(dt>bench_longest)bench_longest=dt;
  }
 }
 bench_elapsed=Clock()-begin;
 bench_avg10=bench_elapsed?(u32)bench_frames*bench_hz*10/bench_elapsed:0;
 bench_min10=bench_longest?(u16)bench_hz*10/bench_longest:0;
 bench_max10=bench_shortest && bench_shortest!=65535?(u16)bench_hz*10/bench_shortest:0;
 HWHide();VDP_CommandWait();VDP_EnableDisplay(FALSE);
 VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetPage(0);VDP_SetVerticalOffset(0);
 if(*((const u8*)0x2d)>=2){VDP_RegWrite(25,0);VDP_RegWrite(26,0);VDP_RegWrite(27,0);}
 VDP_EnableSprite(FALSE);VDP_ClearVRAM();VDP_SetColor(0);
 Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(4,"KEEN 0.9.14 - PHASE 1 / HH-A");
 Text(19,bench_status?"ABORTED: DEATH/EXIT - NOT COMPARABLE":"COMPLETE: 700 PHYSICS TICKS");
 Text(34,"CPU RAW/MODE: ");Print_DrawHex8(bench_cpu);
 Text(48,hot_enabled?"MAPTILE RAM / RENDER ON / HZ ":"MAPTILE ROM / RENDER ON / HZ ");Number(bench_hz);
 Text(63,"FPS MIN / AVG / MAX");
 Print_SetPosition(4,76);Decimal(bench_min10);Print_DrawText(" / ");Decimal(bench_avg10);Print_DrawText(" / ");Decimal(bench_max10);
 Text(92,"FRAMES: ");Number(bench_frames);Print_DrawText("  JIFFIES: ");Number(bench_elapsed);
 Text(107,"FRAME MS AVG / WORST: ");
 Number(bench_frames?(u32)bench_elapsed*1000/bench_hz/bench_frames:0);Print_DrawText(" / ");Number((u32)bench_longest*1000/bench_hz);
 Text(122,"SCROLL X/Y: ");Number(bench_scroll_x);Print_DrawChar('/');Number(bench_scroll_y);
 Text(137,"SHOTS: ");Number(shots_fired);Print_DrawText("  FLOWER HITS: ");Number(flower_hits);
 Text(152,"TIMER RESOLUTION: 1 VBLANK");
 Text(169,"PHOTO RESULTS; RESET FOR NEXT CPU");
 Text(185,"NO LIVE FPS OVERLAY DURING TEST");
 VDP_CommandWait();VDP_EnableDisplay(TRUE);bench_done=1;
 for(;;)Halt();
}

#include "apple.h"
extern volatile u8 hardware_scroll;
#include "combat_assets.h"
#include "apple_stream.h"
#include "hw_tomato.h"
void AppleBitmap(u8 page,DrawObject* ob) __banked
{
 const SpriteDef* sp=sprites[6]+ob->frame;
 u8 index,bank;u16 address;
 if(ob->frame<114){index=ob->frame-108;bank=5;address=0x9c00;}
 else if(ob->frame<120){index=ob->frame-108;bank=36;address=0x9400;}
 else if(ob->frame<146){index=12+ob->frame-136;bank=58;address=0x9000;}
 else{index=22+ob->frame-146;bank=20;address=0xa800;}
 address+=apple_stream_offsets[index];

 u8 row,texture_y,w,h,part,iw=sp->w,ih=sp->h,view_h=hardware_scroll?192:176;
 u16 x,y,dx,dy;i16 left=ob->x+SPR_OX(sp)-camera_px,top=ob->y+SPR_OY(sp)-camera_py,l=0,t=0,r=iw,b=ih;
 if(left>=256 || top>=view_h || left+iw<=0 || top+ih<=0){ob->visible=0;return;}
 if(left<0)l=-left;if(top<0)t=-top;if(left+r>256)r=256-left;if(top+b>view_h)b=view_h-top;
 dx=HWTexture(page,ob->frame,ih);texture_y=dx;
 VDP_CommandWait();
 if(!(dx&256)){
  for(row=0;row<ih;++row)AppleUpload(bank,(const u8*)(address+(u16)row*iw),(u16)page*32768+(u16)(u8)(texture_y+row)*128+64,iw);
 }
 for(part=0;part<2;++part)for(y=t;y<b;y+=h){
  dy=hardware_scroll?(ob->y+SPR_OY(sp)+y)&255:16+top+y;h=b-y;if(hardware_scroll && dy+h>256)h=256-dy;if(((texture_y+y)&255)+h>256)h=256-((texture_y+y)&255);
  for(x=l;x<r;x+=w){dx=hardware_scroll?(ob->x+SPR_OX(sp)+x)&255:left+x;w=r-x;if(hardware_scroll && dx+w>256)w=256-dx;
   g_VDP_Command.SX=128+(part?iw:0)+x;g_VDP_Command.SY=(u16)page*256+((texture_y+y)&255);
   g_VDP_Command.DX=dx;g_VDP_Command.DY=(u16)page*256+dy;g_VDP_Command.NX=w;g_VDP_Command.NY=h;g_VDP_Command.ARG=0;
   g_VDP_Command.CMD=VDP_CMD_LMMM+(part?VDP_OP_OR:VDP_OP_AND);VDP_CommandSetupR32();}
 }
}
