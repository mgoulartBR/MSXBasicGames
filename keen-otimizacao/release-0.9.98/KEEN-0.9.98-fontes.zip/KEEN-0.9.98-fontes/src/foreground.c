// SPDX-License-Identifier: GPL-2.0-or-later
// Original INTILE bit 7: masked foreground between the hero and projectiles.
#include "combat_assets.h"

void ActorDraw(u8 page,DrawObject* ob) __banked;
void ForegroundHero(u8 page) __banked
{
    static DrawObject fg;
    u8 x,y,left,right,top,bottom,frame;
    const DrawObject* hero=actors_old[page];
    const SpriteDef* sp=&sprites[LEVEL_INDEX][hero->frame];
    left=(hero->x+SPR_OX(sp))>>4;
    right=(hero->x+SPR_OX(sp)+sp->w-1)>>4;
    top=(hero->y+SPR_OY(sp))>>4;
    bottom=(hero->y+SPR_OY(sp)+sp->h-1)>>4;
    for(y=top;y<=bottom && y<MAP_HEIGHT;++y)
        for(x=left;x<=right && x<MAP_WIDTH;++x){
            frame=world_collision[524+MapTile((u16)y*MAP_WIDTH+x)];
            if(!frame)continue;
            fg.x=(u16)x*16;fg.y=(u16)y*16;fg.frame=frame;fg.visible=1;
            ActorDraw(page,&fg);
        }
}
