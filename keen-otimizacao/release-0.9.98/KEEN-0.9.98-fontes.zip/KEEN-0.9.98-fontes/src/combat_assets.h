#ifndef KEEN_ASSETS_H
#define KEEN_ASSETS_H
#include "msxgl.h"
typedef struct {u8 mx,cx,my,cy,w,h,ox,oy;} SpriteDef;
#define SPR_OX(s) ((s)->ox&127)
#define SPR_OY(s) ((s)->oy&127)
#define SPR_MY(s) (512U+(s)->my+((s)->ox&128?256U:0U))
#define SPR_CY(s) (512U+(s)->cy+((s)->oy&128?256U:0U))
extern const SpriteDef* const sprites[12];
extern const u8* const tile_x[12];
extern const u16* const tile_y[12];
#endif
