// SPDX-License-Identifier: GPL-2.0-or-later
// Yamaha V9938 Technical Data Book, printed p85: LMMM changes SY, DY,
// NY and CMR. Never reuse these without restoring them after the mask.
#include "sprite_color_pass.h"
void SpriteColorPass(void) __naked
{
 __asm
  call _VDP_CommandWait
  di
  ld a,#32
  out (0x99),a
  ld a,#0x91
  out (0x99),a
  ld hl,#_g_VDP_Command
  ld c,#0x9B
  outi
  outi
  outi
  outi
  inc hl
  inc hl
  ld a,#38
  out (0x99),a
  ld a,#0x91
  out (0x99),a
  outi
  outi
  inc hl
  inc hl
  ld a,(hl)
  out (0x99),a
  ld a,#0xAA
  out (0x99),a
  ld a,(_g_VDP_Command+14)
  out (0x99),a
  ld a,#0xAE
  ei
  out (0x99),a
  ret
 __endasm;
}
