// SPDX-License-Identifier: GPL-2.0-or-later
#include "msxgl.h"

// 0: unchanged; 1: R800 ROM; 2: R800 DRAM; 3: Panasonic turbo; 4: OCM custom clock (preserved or level 7).
// One-time telemetry; no CPU detection or switching in the game loop.
volatile u8 cpu_mode;

void CpuAuto(void) __banked __naked
{
    __asm
        xor a
        ld (_cpu_mode),a
        ld a,(#0x002d)
        cp #3
        jp z,cpu_r800
        cp #1
        ret c
        cp #3
        ret nc
        // Expanded I/O ID 08 is shared by Panasonic and some Sanyo models.
        // Test availability (bit 2), not just the writable turbo latch.
        push bc
        di
        in a,(#0x40)
        cpl
        ld b,a
        // OCM-PLD first: FPGA BIOS can identify as MSX2 or MSX2+.
        // ID D4 -> complement 2B; command 0A = custom level 7 (8.06 MHz).
        ld a,#0xd4
        out (#0x40),a
        in a,(#0x40)
        cp #0x2b
        jr nz,cpu_panasonic
        in a,(#0x4f)
        and #0x1f
        jr z,cpu_restore
        cp #0x1f
        jr z,cpu_restore
        // Preserve a custom turbo already selected by the user (e.g. 10 MHz).
        in a,(#0x42)
        bit 0,a
        jr z,cpu_ocm_enable
        in a,(#0x48)
        bit 0,a
        jr nz,cpu_ocm_enable
        ld a,#4
        ld (_cpu_mode),a
        jr cpu_restore
cpu_ocm_enable:
        ld a,#0x0a
        out (#0x41),a
        in a,(#0x41)
        cp #0xf5
        jr nz,cpu_restore
        // Confirm active custom clock, level 7, and Panasonic mode off.
        in a,(#0x42)
        bit 0,a
        jr z,cpu_restore
        in a,(#0x47)
        and #7
        cp #7
        jr nz,cpu_restore
        in a,(#0x48)
        bit 0,a
        jr nz,cpu_restore
        ld a,#4
        ld (_cpu_mode),a
        jr cpu_restore
cpu_panasonic:
        // A recognized OCM never falls through to the slower Pana mode.
        ld a,(#0x002d)
        cp #2
        jr nz,cpu_restore
        ld a,#8
        out (#0x40),a
        in a,(#0x40)
        cp #0xf7
        jr nz,cpu_restore
        in a,(#0x41)
        bit 2,a
        jr nz,cpu_restore
        and #0xfe
        out (#0x41),a
        in a,(#0x41)
        bit 0,a
        jr nz,cpu_restore
        ld a,#3
        ld (_cpu_mode),a
cpu_restore:
        ld a,b
        out (#0x40),a
        pop bc
        ei
        ret
cpu_r800:
        // Preserve compiler frame/index registers across BIOS CPU switching.
        ld a,#0x82
cpu_change:
        push bc
        push de
        push hl
        push ix
        push iy
        call #0x0180
        call #0x0183
        and #3
        ld (_cpu_mode),a
        pop iy
        pop ix
        pop hl
        pop de
        pop bc
        ret
    __endasm;
}

// These entry points are offered only after detecting a turbo R BIOS.
void CpuZ80(void) __banked __naked { __asm
 xor a
 jp cpu_change
 __endasm; }
void CpuROM(void) __banked __naked { __asm
 ld a,#0x81
 jp cpu_change
 __endasm; }
void CpuDRAM(void) __banked __naked { __asm
 ld a,#0x82
 jp cpu_change
 __endasm; }
u8 CpuRead(void) __banked __naked { __asm
 push bc
 push de
 push hl
 push ix
 push iy
 call #0x0183
 pop iy
 pop ix
 pop hl
 pop de
 pop bc
 ret
 __endasm; }
