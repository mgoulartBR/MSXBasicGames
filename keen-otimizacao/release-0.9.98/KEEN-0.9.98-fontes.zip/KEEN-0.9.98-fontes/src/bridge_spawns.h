// Original Bridge Bottoms: Tater, Brocco, Melon left/right.
static const u8 bridge_spawn[7][2]={{19,20},{11,26},{45,37},{12,58},{41,58},{26,55},{29,55}};
