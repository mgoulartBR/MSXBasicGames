#include "castle.h"
#include "combat_assets.h"
#include "hw_tomato.h"
#include "castle_squash_images.h"
extern volatile u8 hardware_scroll;
extern volatile u16 camera_px,camera_py;
#define CITY_BITMAP CastleSquashBitmap
#define CITY_IMAGES castle_squash_images
#define CITY_BASE 116
#include "city_bitmap.inc"
