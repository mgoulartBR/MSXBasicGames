// SPDX-License-Identifier: GPL-2.0-or-later
// Scan 32 visual-difference bits, returning the first and last changed half-tile.
#include "msxgl.h"
extern volatile u8 bounds_mask;
extern volatile u8 bounds_left,bounds_right;
extern volatile u16 bounds_ptr;
void BoundsRow(void) __NAKED
{

    __asm
    ld hl, (_bounds_ptr)
    ld a, (_bounds_mask)
    ld b, a
    ld de, #0x2000
    ld c, #0
bounds_scan_1:
    ld a, (hl)
    and b
    jr z, bounds_scan_3
    ld a, d
    cp #32
    jr nz, bounds_scan_2
    ld d, c
bounds_scan_2:
    ld e, c
    inc e
bounds_scan_3:
    rlc b
    jr nc, bounds_scan_4
    inc hl
bounds_scan_4:
    inc c
    ld a, c
    cp #32
    jr c, bounds_scan_1
    ld a, d
    ld (_bounds_left), a
    ld a, e
    ld (_bounds_right), a
    ret
    __endasm;
}

