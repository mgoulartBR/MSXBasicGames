#ifndef KEEN_BOOBUS_H
#define KEEN_BOOBUS_H
#include "combat.h"
#include "world.h"
// VRAM 0x13000..0x13fff, after both hardware hero tables.
#define BOOBUS_STREAM_ROW 96
#define BOOBUS_STREAM_ROWS 32
#define boobus_actor ((CombatObject*)(world_map+7200))
#define boobus_hp world_map[7216]
#define boobus_start_bombs (*(u16*)(world_map+7218))
#define boobus_death_time (*(u16*)(world_map+7220))
#define boobus_random world_map[7222]
#define boobus_fx ((CombatObject*)(world_map+7248))
void BoobusLoad(void) __banked;
void BoobusReset(void) __banked;
void BoobusSelect(void) __banked;
void BoobusTick(void) __banked;
u8 BoobusHit(CombatObject*) __banked;
void BoobusCollect(DrawObject*) __banked;
void BoobusStatic(DrawObject*) __banked;
void BoobusRestoreBombs(void) __banked;
void BoobusBombTick(CombatObject*) __banked;
void BoobusBitmap(u8,DrawObject*) __banked;
void BoobusAtlas(u8);
void BoobusRows(u8,u8,u8,u8);
void BoobusTexture(u8 frame,u8 page,u8 texture_y,u8 width,u8 height);
#endif
