// Generated from the supplied EGA data. Do not edit.
#define TILE_COUNT 292
#define SPAWN_X 2080
#define SPAWN_Y 480
#define START_CAM_X 118
#define START_CAM_Y 24
const u8 scene_palette[] = {
    0,0,5,0,0,5,5,5,80,0,85,0,80,2,85,5,34,2,0,0,34,7,39,7,
    114,2,119,2,114,7,119,7,
};
