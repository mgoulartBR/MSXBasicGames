// Original EGA 1.93 object plane: four carrots, seven Taters.
static const u8 hill_spawn[11][2]={{71,22},{21,23},{37,31},{68,31},{55,8},{61,11},{108,11},{115,17},{116,17},{117,17},{119,17}};
