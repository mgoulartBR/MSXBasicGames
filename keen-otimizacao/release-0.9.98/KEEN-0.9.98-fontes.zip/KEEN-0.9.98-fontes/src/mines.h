// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef KEEN_MINES_H
#define KEEN_MINES_H
#include "session.h"
#include "world.h"
#define mines_walkers (session.mines_walkers)
typedef struct {u16 x,y;i8 vx,vy;u8 active,frame,tick;} MinesSeed;
// Last nine collision property entries are unused in this particular map.
#define mines_seeds ((MinesSeed*)(world_collision+444))
#define mines_timer (world_collision+1105)
#define mines_active (world_collision+1108)
#define mines_random (world_collision[1111])
#define mines_overflow (world_collision[1118])
typedef char MinesSeedFits[(sizeof(MinesSeed)*4<=36)?1:-1];
void MinesTaterBitmap(u8 page,DrawObject* ob) __banked;
void MinesBitmap(u8 page,DrawObject* ob) __banked;
void MinesBounce(MinesSeed* s,u8 wall) __banked;
void MinesReset(void) __banked;
void MinesSelect(void) __banked;
void MinesTick(void) __banked;
u8 MinesHit(CombatObject* shot) __banked;
void MinesCollect(DrawObject* out) __banked;
#endif
