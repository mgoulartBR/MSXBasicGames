Keen Dreams MSX - 0.9.98
Versao de desempenho sobre a 0.9.62. A jogabilidade e a arte sao as mesmas, com uma excecao registrada abaixo (passo de fisica do Keen a 35 Hz).

O que mudou desde a 0.9.62 (resumo; detalhes em keen-otimizacao/RELATORIO.md e RESUMO-DETALHADO.md):
- Desenho dos atores em um unico passe LMMM+TIMP (herois, atlas de Hill/Melon/Bridge e varios quadros das demais fases; o chefe de Boobus tambem).
- Rolagem do cenario (Columns/Rows), listas de atores, itens, chaves, bombas, carrinhos e varreduras de bonus/picapes reescritos em Z80.
- Troca de pagina/rolagem feita na interrupcao de vblank, sem espera pelo VDP.
- Barra de HUD fixa no rodape por interrupcao de linha (MSX2+ a partir de ~5 MHz; abaixo disso o HUD volta a ser desenhado no anel).
- Correcao de um congelamento da barra (0.9.76 a 0.9.87).
- Diferenca de comportamento: a fisica do Keen avanca dois ticks de 70 Hz por passada (35 Hz).

Medicoes feitas apenas no openMSX (C-BIOS MSX2+), com o Z80 forcado a 3,58 / 5,37 / 7,16 MHz. Nada foi testado em MSX real.

Compilacao:
MSXGL_ROOT=/caminho/MSXgl bash scripts/build.sh
Toolchain: MSXgl 1.5.2 com o SDCC 4.6.0 incluido. ROM ASCII16, 2 MiB. Saida: build/keen_msx.rom (SHA-256 em SHA256SUMS.txt do pacote).
