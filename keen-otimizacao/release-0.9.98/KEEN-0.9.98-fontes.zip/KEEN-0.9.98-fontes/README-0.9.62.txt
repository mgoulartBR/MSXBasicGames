Keen Dreams MSX - 0.9.62
Correcao de desempenho do HUD da 0.9.61, mantendo o painel turquesa e os efeitos PSG.

O painel e montado no cache de VRAM na entrada da fase. Durante o jogo, o VDP copia o cache; somente numeros alterados sao atualizados. Regioes de cache sao geradas e verificadas contra os atlas finais em tools/build_hud_cache.py. Nao realoca sprites/cenarios e usa apenas um byte persistente adicional (fim da RAM EFFE).

Leia VALIDACAO-0.9.62.txt para metodo, comparacao e limites das medidas. A ROM final usa a campanha normal, sem fixtures de teste, e o mapper ASCII16, 2 MiB.

Compilacao:
MSXGL_ROOT=/caminho/MSXgl bash scripts/build.sh
Toolchain mantida da 0.9.60/0.9.61. O pacote inclui as fontes do core15 utilizadas na compilacao. CompileSkipOld=false garante recompilacao dos includes em builds completos.
