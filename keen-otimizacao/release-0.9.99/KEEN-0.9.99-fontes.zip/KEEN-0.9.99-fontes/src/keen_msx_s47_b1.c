#include "city.h"
// Phase 4a: resident hot code and non-destructive mapper service discovery.
#include "msxgl.h"
#include "hotcode.h"
#include "world.h"
extern const u8 g_Font_MGL_Sample6[];
volatile u8 mapper_status,mapper_slot,mapper_total,mapper_free,mapper_segment;
volatile u16 mapper_table,mapper_jump;
static void Text(u8 y,const char* s){Print_SetPosition(4,y);Print_DrawText(s);}
// The software scroll path of the V9938 (MSX2) is not maintained (it crashes when scrolling left): stop with a message.
extern const u8 scene_palette[];
void RequireMsx2Plus(void) __banked
{
 if(Sys_GetMSXVersion()>=2)return;
 VDP_SetMode(VDP_MODE_SCREEN5);VDP_SetColor(0);VDP_ClearVRAM();VDP_SetPalette(scene_palette);
 Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(60,"COMMANDER KEEN: KEEN DREAMS MSX2");
 Text(90,"THIS VERSION NEEDS AN MSX2+ (V9958).");
 Text(106,"THE MSX2 (V9938) IS NOT SUPPORTED.");
 VDP_CommandWait();for(;;)Halt();
}
void HotInit(void) __banked {
 u16 i,n,size=(u16)MapTileKernelEnd-(u16)MapTileKernel,expected;
 hot_entry=(u16)MapTileKernel;hot_enabled=0;hot_ok=0;
 hot_slot=(g_PortPrimarySlot>>6)&3;
 if(g_EXPTBL[hot_slot]&0x80)hot_slot|=0x80|(((~g_SLTSL>>6)&3)<<2);
 if(size>sizeof(hot_code))return;
 Mem_Copy((const void*)MapTileKernel,hot_code,size);
 for(i=0;i<size;++i)if(hot_code[i]!=((const u8*)MapTileKernel)[i])return;
 // Before any level is loaded. Exercise all bit offsets and 9-bit results.
 for(i=0;i<sizeof(world_map);++i)world_map[i]=(u8)(i*37+(i>>8));
 hot_entry=(u16)hot_code;
 for(i=0;i<8700;++i){
  n=i+(i>>3);expected=(((u16)world_map[n]|((u16)world_map[n+1]<<8))>>(i&7))&511;
  if(MapTile(i)!=expected || MapTileKernel(i)!=expected){hot_entry=(u16)MapTileKernel;return;}
 }
 hot_entry=(u16)MapTileKernel;hot_ok=1;
}
void HotToggle(void) __banked {
 if(!hot_ok)return;
 hot_enabled=!hot_enabled;
 hot_entry=active_level==12?(u16)CastleMapTile:active_level==6?(u16)CityMapTile:hot_enabled?(u16)hot_code:(u16)MapTileKernel;
}
// EXTBIO may corrupt both index registers. No assumed segment numbers.
static void MapperQuery(void) __naked {
 __asm
 push ix
 push iy
 xor a
 ld (_mapper_status),a
 ld a,(#0xfb20)
 and #1
 jr z,mq_end
 xor a
 ld hl,#0
 ld de,#0x0401
 call #0xffca
 ld (_mapper_table),hl
 // Query 2 detects support even if primary slot is zero.
 xor a
 ld hl,#0
 ld de,#0x0402
 call #0xffca
 ld (_mapper_total),a
 ld (_mapper_jump),hl
 ld a,b
 ld (_mapper_slot),a
 ld a,c
 ld (_mapper_free),a
 ld a,#1
 ld (_mapper_status),a
mq_end:
 pop iy
 pop ix
 ret
 __endasm;
}
// Only after validation of a page-3 jump table. Allocate in primary, then free.
static void MapperReserveProbe(void) __naked {
 __asm
 push ix
 push iy
 ld hl,(_mapper_jump)
 ld b,#0
 xor a
 call mq_call
 jr c,mq_allocfail
 ld (_mapper_segment),a
 push af
 ld hl,(_mapper_jump)
 ld de,#3
 add hl,de
 pop af
 ld b,#0
 call mq_call
 ld a,#5
 jr c,mq_store
 ld a,#4
 jr mq_store
mq_allocfail:
 ld a,#3
mq_store:
 ld (_mapper_status),a
 pop iy
 pop ix
 ret
mq_call:
 jp (hl)
 __endasm;
}
void MapperReport(void) __banked {
 u8* table;u8 good;
 mapper_slot=mapper_total=mapper_free=mapper_segment=0;mapper_table=mapper_jump=0;
 MapperQuery();
 if(mapper_status){
  // Do not dereference a table hidden by the cartridge or arbitrary BIOS bytes.
  good=mapper_table>=0xc000 && mapper_table<=0xff00 && mapper_jump>=0xc000 && mapper_jump<=0xff00;
  if(good){
   table=(u8*)mapper_table;
   good=mapper_total && mapper_slot==hot_slot && table[0]==mapper_slot && table[1]==mapper_total && table[2]==mapper_free;
   good=good && *((u8*)mapper_jump)==0xc3 && *((u8*)(mapper_jump+3))==0xc3;
  }
  if(good){mapper_status=2;if(mapper_free)MapperReserveProbe();}
 }
 VDP_CommandWait();VDP_ClearVRAM();Print_SetBitmapFont(g_Font_MGL_Sample6);Print_SetColor(15,0);
 Text(4,"KEEN 0.9.14 - MEMORY / PHASE 4A");
 Text(22,"CURRENT PAGE3 SLOT: ");Print_DrawHex8(hot_slot);
 Text(38,"HOT CODE RAM: ");Print_DrawHex16((u16)hot_code);Print_DrawText(" BYTES: ");Print_DrawInt((u16)MapTileKernelEnd-(u16)MapTileKernel);
 Text(54,hot_ok?"MAPTILE COPY + 8700 QUERIES: PASS":"MAPTILE VALIDATION: FAIL");
 Text(74,"MAPPER API STATUS: ");Print_DrawInt(mapper_status);
 Text(90,"PRIMARY SLOT: ");if(mapper_status>=2)Print_DrawHex8(mapper_slot);else Print_DrawText("--");
 Text(106,"TOTAL/FREE SEGMENTS: ");if(mapper_status>=2){Print_DrawInt(mapper_total);Print_DrawChar('/');Print_DrawInt(mapper_free);}else Print_DrawText("UNAVAILABLE");
 Text(122,"TABLE/JUMP: ");Print_DrawHex16(mapper_table);Print_DrawChar('/');Print_DrawHex16(mapper_jump);
 Text(138,mapper_status==4?"ALLOCATED + RELEASED SEGMENT: ":"NO SEGMENT USED FOR EXECUTION");
 if(mapper_status==4)Print_DrawHex8(mapper_segment);
 Text(158,mapper_status==0?"NO EXTBIO; NO SEGMENTS TOUCHED":mapper_status==1?"API UNAVAILABLE OR INCONSISTENT":mapper_status==3?"ALLOCATION FAILED":mapper_status==5?"RELEASE FAILED; RESET REQUIRED":mapper_status==2?"NO FREE SEGMENTS":"PRIMARY ALLOCATION TEST PASSED");
 Text(178,"PHOTO RESULTS; RESET TO CONTINUE");
 VDP_CommandWait();for(;;)Halt();
}
