// Fixed 16 KB code bank; atlas banks 1..4 and map bank 5.
ProjName = "keen_msx";
ProjModules = ["main", "scan", "world", "combat_assets"];
LibModules = ["system", "bios", "vdp", "print", "input", "memory"];
Machine = "2";
Target = "ROM_ASCII16";
ROMSize = 2048;
ROMMainSegments = 1;
BankedCall = true;
CustomISR = "NONE";
CheckVersion = true;
DoRun = false;
BuildLibrary = true;
CompileSkipOld = false;
Optim = "Speed";
CompileComplexity = "Default";
AppSignature = true;
AppCompany = "MC";
AppID = "KD";
AddROMSignature = true;
RawFiles = [
    {offset: 0x37e00, file: "../assets/grove/atlas_part0.bin"},
    {offset: 0x53500, file: "../assets/grove/atlas_part1.bin"},
    {offset: 0x77800, file: "../assets/grove/atlas_part2.bin"},
    {offset: 0x92500, file: "../assets/grove/atlas_part3.bin"},
    {offset: 0x93500, file: "../assets/grove/atlas_part4.bin"},
    {offset: 0xeba00, file: "../assets/grove/atlas_part5.bin"},
    {offset: 0x17a00, file: "../assets/grove/atlas_part6.bin"},
    {offset: 0x1bb00, file: "../assets/grove/atlas_part7.bin"},
    {offset: 0xa3d00, file: "../assets/grove/atlas_part8.bin"},
    {offset: 0xc4800, file: "../assets/grove/atlas_part9.bin"},
    {offset: 0xa4800, file: "../assets/grove/atlas_part10.bin"},
    {offset: 0xb4900, file: "../assets/grove/atlas_part11.bin"},




































































































































































































































    {offset: 0x170000, file: "../assets/castle/atlas.bin"},
    {offset: 0x180000, file: "../assets/castle/load_data.bin"},
    {offset: 0x182000, file: "../assets/castle/stage_data.bin"},





    {offset: 0x148000, file: "../assets/boobus/boss_0.bin"},
    {offset: 0x14c000, file: "../assets/boobus/boss_1.bin"},
    {offset: 0x150000, file: "../assets/boobus/boss_2.bin"},
    {offset: 0x154000, file: "../assets/boobus/boss_3.bin"},
    {offset: 0x158000, file: "../assets/boobus/boss_4.bin"},
    {offset: 0x15c000, file: "../assets/boobus/boss_5.bin"},
    {offset: 0x160000, file: "../assets/boobus/boss_6.bin"},
    {offset: 0x164000, file: "../assets/boobus/boss_7.bin"},
    {offset: 0x168000, file: "../assets/boobus/boss_8.bin"},

    {offset: 0x130000, file: "../assets/boobus/atlas.bin"},
    {offset: 0x140000, file: "../assets/boobus/load_data.bin"},
    {offset: 0x142000, file: "../assets/boobus/stage_data.bin"},


    {offset: 0x118000, file: "../assets/swamp/atlas.bin"},
    {offset: 0x128000, file: "../assets/swamp/load_data.bin"},
    {offset: 0x12a000, file: "../assets/swamp/stage_data.bin"},


    {offset: 0x100000, file: "../assets/bay/atlas.bin"},
    {offset: 0x110000, file: "../assets/bay/load_data.bin"},
    {offset: 0x112000, file: "../assets/bay/stage_data.bin"},








    {offset: 0x35900, file: "../assets/grove/load_data.bin"},
    {offset: 0x37900, file: "../assets/grove/stage_data.bin"},
    {offset: 0xeb500, file: "../assets/rapids/ram_sprites.bin"},
    {offset: 0xad000, file: "../assets/apple/atlas_part0.bin"},
    {offset: 0xbc800, file: "../assets/apple/atlas_part1.bin"},
    {offset: 0xa9000, file: "../assets/apple/atlas_part2.bin"},
    {offset: 0x6a500, file: "../assets/apple/atlas_part3.bin"},
    {offset: 0xceb00, file: "../assets/apple/atlas_part4.bin"},
    {offset: 0xd2600, file: "../assets/apple/atlas_part5.bin"},
    {offset: 0xef500, file: "../assets/apple/atlas_part6.bin"},
    {offset: 0x57600, file: "../assets/apple/atlas_part7.bin"},
    {offset: 0x5b800, file: "../assets/apple/map_part0.bin"},
    {offset: 0x5f800, file: "../assets/apple/map_part1.bin"},
    {offset: 0x63800, file: "../assets/apple/map_part2.bin"},
    {offset: 0x67800, file: "../assets/apple/map_part3.bin"},
    {offset: 0x7fc00, file: "../assets/apple/map_part4.bin"},
    {offset: 0x57b00, file: "../assets/apple/stage_data.bin"},
    {offset: 0x15770, file: "../assets/scene/ram_tables.bin"},
    {offset: 0x15c00, file: "../assets/apple/apel_walk.bin"},
    {offset: 0x91400, file: "../assets/apple/apel_pole.bin"},
    {offset: 0xe9000, file: "../assets/apple/pod.bin"},
    {offset: 0x52800, file: "../assets/apple/pea.bin"},

    {offset: 0x79000, file: "../assets/city/atlas_part0.bin"},
    {offset: 0xa5000, file: "../assets/city/atlas_part1.bin"},
    {offset: 0xc5000, file: "../assets/city/atlas_part2.bin"},
    {offset: 0xb5000, file: "../assets/city/atlas_part3.bin"},
    {offset: 0xb1000, file: "../assets/city/atlas_part4.bin"},
    {offset: 0xbf000, file: "../assets/city/atlas_part5.bin"},
    {offset: 0x75000, file: "../assets/city/load_data.bin"},
    {offset: 0x77300, file: "../assets/city/stage_data.bin"},
    {offset: 0xf0000, file: "../assets/pass/atlas.bin"},
    {offset: 0xa1400, file: "../assets/pass/load_data.bin"},
    {offset: 0xa3800, file: "../assets/pass/stage_data.bin"},
    {offset: 0xd8000, file: "../assets/rapids/atlas.bin"},
    {offset: 0xe8000, file: "../assets/rapids/packed_map.bin"},
    {offset: 0xeb000, file: "../assets/rapids/stage_data.bin"},
    {offset: 0xc0000, file: "../build/core15/CORE15.BIN"},
    {offset: 0x94000, file: "../assets/title/screen7.bin"},
    {offset: 0x80000, file: "../assets/bridge/atlas.bin"},
    {offset: 0x90000, file: "../assets/bridge/packed_map.bin"},
    {offset: 0x93000, file: "../assets/bridge/stage_data.bin"},
    {offset: 0x40000, file: "../assets/melon/atlas.bin"},
    {offset: 0x50000, file: "../assets/melon/packed_map.bin"},
    {offset: 0x53000, file: "../assets/melon/stage_data.bin"},
    {offset: 0x24000, file: "../assets/tuberia/atlas.bin"},
    {offset: 0x34000, file: "../assets/tuberia/packed_map.bin"},
    {offset: 0x4000, file: "../assets/scene/atlas.bin"},
    {offset: 0x14000, file: "../assets/scene/packed_map.bin"},
    {offset: 0x17000, file: "../assets/scene/stage_data.bin"},
    {offset: 0x18000, file: "../assets/scene/scroll_diff.bin"},
    {offset: 0x17500, file: "../assets/scene/half_ids.bin"}
];
