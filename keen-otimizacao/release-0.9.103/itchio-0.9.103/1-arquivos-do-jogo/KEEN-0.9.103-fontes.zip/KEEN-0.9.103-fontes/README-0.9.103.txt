Keen Dreams MSX - 0.9.103
Versao de desempenho sobre a 0.9.62 (continuacao da 0.9.99). A jogabilidade e a arte sao as mesmas, com uma excecao registrada abaixo (passo de fisica do Keen a 35 Hz). Requer MSX2+ (a ROM para com uma mensagem em MSX2).

O que mudou da 0.9.99 para a 0.9.103 (detalhes em keen-otimizacao/RELATORIO.md):
- Soldados com baioneta (Tater), Aspar/Mouth e Brocco desenhados em um unico passe LMMM+TIMP (antes: AND + OR); metade dos bytes de textura.
- AppleCollect/AppleStatic (fase 7) e CityCollect/CitySelect (fase 6) reescritos em Z80.
- CartContact (fases 2 e 7) reescrito em Z80.
- Bancos de ROM menores (sobra espaco nos bancos 7, 42 e 50).

Medicoes feitas apenas no openMSX (C-BIOS MSX2+), com o Z80 forcado a 3,58 / 5,37 / 7,16 MHz. Nada foi testado em MSX real.

Compilacao:
MSXGL_ROOT=/caminho/MSXgl bash scripts/build.sh
Toolchain: MSXgl 1.5.2 com o SDCC 4.6.0 incluido. ROM ASCII16, 2 MiB. Saida: build/keen_msx.rom (SHA-256 em SHA256SUMS.txt do pacote).
