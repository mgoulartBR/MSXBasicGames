"""Controlled camera reversals across both circular VRAM boundaries.
Native enemy simulation remains enabled; camera injection is correctness-only.
"""
from pathlib import Path
import re,os,subprocess,sys
r=Path(__file__).resolve().parents[1];out=r/'build/0954-scroll-edges';out.mkdir(exist_ok=True)
sym={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
s='\n'.join(f'set {n} {a}' for n,a in sym.items())+'\n'+snap+r'''
set throttle off
set renderer SDL
set sound_driver null
set save_settings_on_exit false
set z80_freq_locked false
set z80_freq 10738635
set too_fast_vram_access ignore
set active 0
set index 0
set positions {{1018 250} {1022 254} {1024 256} {1026 258} {1032 264} {1026 258} {1024 256} {1022 254} {1018 250} {1024 250} {1032 250} {1024 250} {1018 250} {1018 256} {1018 264} {1018 256} {1018 250}}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
proc check {} {
 if {[byte $::scene_ready]!=165 || [byte $::active_level]!=2} {keymatrixdown 8 1;after time 0.1 {keymatrixup 8 1;after time 0.2 check};return}
 keymatrixup 8 255;set ::active 1
}
proc fixture {} {
 if {!$::active} {return}
 putword $::player_x [expr {1232*16}];putword $::player_y [expr {288*16}]
 putword $::player_vx 0;putword $::player_vy 0
 debug write memory $::climbing 1;debug write memory $::death_ticks 0
 debug write memory $::combat_dirty 1
}
proc camera {} {
 if {!$::active} {return}
 lassign [lindex $::positions [expr {$::index%[llength $::positions]}]] x y
 putword $::camera_px $x;putword $::camera_py $y
}
proc capture {} {
 if {!$::active} {return}
 set name edge$::index;after time 0.0001 [list snap $name];incr ::index
 if {$::index==68} {set ::active 0;after time 0.05 {exit}}
}
after time 1 check
after time 30 {error "Camera edge fixture timed out";exit}
'''
for name,callback in [('Game_Tick','fixture'),('DrawScene','camera'),('HWFlip','capture')]:
 a=sym[name];s+=f'\ndebug set_bp {a&65535} {{[byte $::g_CurrentSegment]=={a>>16}}} {callback}\n'
(out/'test.tcl').write_text(s)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out),KEEN_STAGE='2')
with (out/'emulator.log').open('w') as f:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r.parent/'audit0956/K0956T3.ROM'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=f,stderr=f,check=True,timeout=90)
names=[f'edge{i}' for i in range(68)];subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
print('PASS: 68 full frames with live enemies, camera reversals and diagonal/horizontal/vertical circular edges.')
