"""Read actual pattern/color/SAT data; verify 56 compact hero poses and tomatoes.
The compact-hero phase explicitly forces uploaded poses at HWMinesUpload.
The tomato phase uses the real selector, with controlled scene geometry.
"""
from pathlib import Path
import os,re,sys,json,subprocess
import numpy as np
r=Path(__file__).resolve().parents[1]
hz=int(sys.argv[1]) if len(sys.argv)>1 else 3579545
out=r/'build'/('0944-hybrid' if hz==3579545 else '0944-hybrid-3x');out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
base=(r.parent/'audit0944/keen0944-10738635-separate/test.tcl').read_text().split('\nset profile_bank ')[0]
base='\n'.join(f'set {n} {a}' for n,a in sym.items())+'\nset z80_freq 10738635\nset kind separate\n'+base[base.index('set throttle off'):]

base=base.replace('set z80_freq 10738635',f'set z80_freq {hz}')
if hz==3579545:base=base.replace('set too_fast_vram_access ignore','set too_fast_vram_access real')
base=base.replace('after time 3 measure','set ::enabled 1')
base=base.replace('debug write memory $::combat_dirty 1', 'debug write memory $::combat_dirty 1;debug write memory [expr {$::world_collision+1130}] 3')
base=base.replace('90+($tick/20)%4','90+($::case>=56?$::case-56:0)')
base=base.replace('after time 90 {fail timeout}','after time 120 {fail timeout}')
base=base.replace('1120+$i*64+($tick%16)','1120+$i*64').replace('set y [expr {$y+($tick/4)%8}]','')
base+='\nset enabled 0\nset case 0\nset ready 0\n'
base+=r'''
proc pose {} {
 if {!$::enabled} {return}
 if {$::case<56} {
  set page [expr {[byte $::front_page]^1}]
  set a [expr {$::world_collision+1128}]
  debug write memory [expr {$a+3+$page}] 1
  debug write memory [expr {$a+7}] $::case
  debug write memory [expr {$a+8}] 32
  debug write memory [expr {$a+9}] 120
  debug write memory [expr {$::world_collision+1164+$page}] 255
 }
 set ::ready 1
}
proc capture {} {
 if {!$::ready} {return}
 set ::ready 0
 set n $::case
 foreach {suffix device start size} [list vram VRAM 0 131072 regs {VDP regs} 0 64 hw memory [expr {$::world_collision+1128}] 40] {
  set f [open $::env(KEEN_TEST_OUTPUT)/pose$n.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f
 }
 set page [byte $::front_page]
 set id [byte [expr {$::world_collision+1164+$page}]]
 set f [open $::env(KEEN_TEST_OUTPUT)/pose$n.json w]
 puts $f "\{\"page\":$page,\"id\":$id,\"camera_x\":[word $::camera_px],\"camera_y\":[word $::camera_py],\"tomato_x\":[expr {$id==255?0:[word [expr {$::world_collision+1026+$id*13}]]/16}],\"tomato_y\":[expr {$id==255?0:[word [expr {$::world_collision+1028+$id*13}]]/16}],\"frame\":[expr {$id==255?0:[byte [expr {$::world_collision+1035+$id*13}]]}]\}"
 close $f
 if {[incr ::case]==66} {exit}
 debug write memory $::combat_dirty 1
}
'''
base+=r'''
proc selection_fixture {} {
 if {!$::enabled || $::case<60} {return}
 set sp [reg SP];set page [byte [expr {$sp+5}]];set next [word [expr {$sp+6}]]
 set c $::case;set h [expr {$::world_collision+1128}]
 debug write memory [expr {$h+3+$page}] [expr {$c==61 || $c==62 || $c==65}]
 debug write memory [expr {$h+7}] [expr {$c==61?5:0}]
 debug write memory [expr {$h+8}] 32;debug write memory [expr {$h+9}] [expr {$c==65?150:220}]
 putword $::player_y [expr {($c==65?150:220)*16}]
 debug write memory $::enemy_mode [expr {$c==64?2:1}]
 for {set i 0} {$i<29} {incr i} {debug write memory [expr {$next+$i*6+5}] 0}
 for {set i 0} {$i<3} {incr i} {
  set x [expr {$c==60?1120+$i:1120+$i*64}];set y [expr {200+$i*30}]
  if {$c==60} {set y 200}
  if {$c==63} {set x [expr {$i==0?1095:($i==1?1352:1248)}];if {$i==2} {set y 269}}
  set a [expr {$next+(20+$i)*6}];putword $a $x;putword [expr {$a+2}] $y
  debug write memory [expr {$a+4}] 90;debug write memory [expr {$a+5}] 1
  set t [expr {$::world_collision+1026+$i*13}];putword $t [expr {$x*16}];putword [expr {$t+2}] [expr {$y*16}]
  debug write memory [expr {$t+8}] 1;debug write memory [expr {$t+9}] 90
 }
}
'''
base+=f'\ndebug set_bp {sym["HWTomatoPrepare"]&65535} {{[byte $::g_CurrentSegment]==105}} selection_fixture\n'
base+=f'\ndebug set_bp {sym["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
base+=f'debug set_bp {sym["HWMinesUpload"]&65535} {{[byte $::g_CurrentSegment]==105}} pose\n'
base+=f'debug set_bp {sym["ReadInput"]&65535} {{[byte $::g_CurrentSegment]==31}} capture\n'
(out/'test.tcl').write_text(base)
(out/'FAIL.txt').unlink(missing_ok=True)
for old in out.glob('pose*'):old.unlink()
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with (out/'emulator.log').open('w')as log:
 subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=150)
assert not(out/'FAIL.txt').exists(),(out/'FAIL.txt').read_text()
layout_check=json.loads((r/'assets/melon/combat_assets.json').read_text())
for i,sp in enumerate(layout_check['sprites']):
 if i in list(range(16))+[30,31]+list(range(36,46)) or sp['mask']==sp['color']==[0,0]:continue
 assert min(sp['mask'][1],sp['color'][1])>=64,(i,sp)
assert min(y for x,y in layout_check['tiles'])>=64
hero=json.loads((r/'assets/scene/hw_hero.json').read_text())['frames']
counts=json.loads((r/'assets/melon/hw_compact_hero.json').read_text())['counts']
layout=json.loads((r/'assets/melon/combat_assets.json').read_text())
tomato=json.loads((r/'assets/melon/hw_tomato.json').read_text())['frames']
def decode(vram,regs,start,count,x0,y0,width,height):
 cb=((regs[11]&3)<<15)|((regs[5]&0xf8)<<7);sat=cb+512;pb=(regs[6]&63)*2048
 image=np.full((height,width),-1)
 for i in range(start,start+count):
  y,x,p,_=vram[sat+i*4:sat+i*4+4]
  dy=(y+1-y0)&255;dx=x-x0
  for yy in range(16):
   color=vram[cb+i*16+yy]
   for xx in range(16):
    if not vram[pb+p*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7)):continue
    assert 0<=dy+yy<height and 0<=dx+xx<width,(i,dy,dx,yy,xx)
    if color&64:image[dy+yy,dx+xx]|=color&15
    else:image[dy+yy,dx+xx]=color&15
 return image
for n in range(66):
 v=(out/f'pose{n}.vram').read_bytes();regs=(out/f'pose{n}.regs').read_bytes();hw=(out/f'pose{n}.hw').read_bytes();state=json.loads((out/f'pose{n}.json').read_text())
 if n<56:
  actual=decode(v,regs,0,counts[n],32,120,32,33)
  expected=np.full((33,32),-1);expected[n&1:(n&1)+32]=hero[n//2]
 elif n<60:
  assert state['id']!=255,('No hardware tomato',n,state)
  start=counts[hw[7]] if hw[3+state['page']] else 0
  entries=[12,14,12,14][n-56]
  actual=decode(v,regs,start,entries,state['tomato_x']-state['camera_x'],state['tomato_y']&255,24,32)
  expected=np.array(tomato[n-56])
 else:
  wanted=[255,255,2,255,255,0][n-60]
  assert state['id']==wanted,(n,state,wanted)
  continue
 assert np.array_equal(actual,expected),(n,np.count_nonzero(actual!=expected))
(out/'PASS.txt').write_text('PASS: 56 compact hero uploads and four selected hardware tomato poses reconstruct exact accepted pixels; six real-selector fixtures check overlap, slot budget, scanline conflict, clipping, disabled enemies and allowed coexistence.\n')
print((out/'PASS.txt').read_text())
