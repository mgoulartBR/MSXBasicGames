"""Compare every opaque source pixel with packed data, without canvas assumptions."""
from pathlib import Path
import sys,json,struct
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'tools'))
from import_ega import planar
layout=json.loads((r/'assets/scene/combat_assets.json').read_text());atlas=(r/'assets/scene/atlas.bin').read_bytes();meta=(r/'assets/generated/chunk_0002.bin').read_bytes()
def pixel(x,y):
 v=atlas[y*128+x//2];return v&15 if x&1 else v>>4
count=0
for index,ch in enumerate(range(138,148),36):
 w,h,ox,oy,*_=struct.unpack_from('<9h',meta,(ch-71)*18);w*=8;ox//=16;oy//=16
 col,mask=planar((r/f'assets/generated/chunk_{ch:04}.bin').read_bytes(),w,h,True)
 d=layout['sprites'][index];l,t,cw,cht=d['crop'];mx,my=d['mask'];cx,cy=d['color']
 for y in range(h):
  for x in range(w):
   if not mask[y*w+x]:
    xx=x+ox;yy=y+oy
    assert l<=xx<l+cw and t<=yy<t+cht,(ch,'truncated',xx,yy)
    assert pixel(mx+xx,my+yy)==0 and pixel(cx+xx,cy+yy)==col[y*w+x],(ch,xx,yy)
    count+=1
print('PASS: all',count,'opaque pixels from all 10 original pole sprites are preserved, including positive origins.')
