"""ROM render/interaction fixtures at original spawns, plus keyboard-only entry.
State-controlled render fixtures are separate from natural-input checks.
"""
from pathlib import Path
import os,re,subprocess,sys,json
r=Path(__file__).resolve().parents[1];machine=sys.argv[1] if len(sys.argv)>1 else 'C-BIOS_MSX2+';out=r/'build'/('0943-mines-rom' if machine=='C-BIOS_MSX2+' else '0943-mines-msx2');out.mkdir(exist_ok=True)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_WORLD_TEST='1',KEEN_TEST_OUTPUT=str(out),KEEN_STAGE='2')
subprocess.run([sys.executable,str(r/'tests/make_game_test.py'),str(r)],env=env,check=True)
base=(r/'build/game-test.tcl').read_text();snap=base[base.index('proc snap {name}'):base.index('proc probe_jump')]
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+', (r/'build/keen_msx.map').read_text(),re.M)}
syms['WorldInput']=int(re.search(r'([0-9A-F]{8})\s+\d+ _WorldInput:',(r/'src/out/keen_msx_s8_b1.lst').read_text())[1],16)+0x8000
snap+=r'''
rename snap bitmap_snap
proc snap {name} {bitmap_snap $name;set f [open $::env(KEEN_TEST_OUTPUT)/$name.allvram wb];puts -nonewline $f [debug read_block VRAM 0 131072];close $f}
'''
s='\n'.join(f'set {n} {a}' for n,a in syms.items())+'\n'+snap
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set held 0
set row8 0
set names {}
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a n} {debug write memory $a [expr {$n&255}];debug write memory [expr {$a+1}] [expr {($n>>8)&255}]}
proc check {c msg} {if {![uplevel 1 [list expr $c]]} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit;error $msg}}
proc keys {bits} {keymatrixup 8 255;if {$bits} {keymatrixdown 8 $bits}}
proc actor {i} {if {$i<6} {return [expr {$::session+16*$i}]} elseif {$i<15 && $i>=9} {return [expr {$::world_collision+1026+13*($i-9)}]} elseif {$i==15} {return $::enemy} else {return 0}}
set spawnx {9 49 62 71 28 76 65 82 78 68 75 80 35 58 74 31 0 0 0 0}
set spawny {17 21 42 42 68 68 16 14 15 17 20 20 84 88 88 87 0 0 0 0}
proc fixture {} {if {$::held} {putword $::player_x $::hx;putword $::player_y $::hy;putword $::player_vx 0;putword $::player_vy 0;debug write memory $::climbing 1;debug write memory $::combat_dirty 1}}
proc control {} {
 if {$::phase==0 && [byte $::world_active]==1} {
  putword $::world_x 608;putword $::world_y 448;keys 0;set ::phase 1;after time 1 {keys 1;after time 0.3 {keys 0}}
 } elseif {$::phase==1 && [byte $::world_active]==0 && [byte $::active_level]==2 && [byte $::scene_ready]==165} {
  keys 0;set ::phase 2;set ::held 1
  set ::hx [expr {5*256}];set ::hy [expr {14*256}];set ::startx [word $::session]
  after time 2 native_done
 }
}
proc native_done {} {
 check {[word $::session]!=$::startx} "Native Tater movement at original spawn"
 check {![byte $::death_ticks]} "Native movement fixture survives"
 set ::phase 3;debug write memory $::enemy_mode 1;set ::index 0;set ::pose 0
 # Restore original positions for independent visual fixtures after native motion.
 for {set i 0} {$i<6} {incr i} {
  set a [actor $i];putword $a [expr {256*[lindex $::spawnx $i]}]
  putword [expr {$a+2}] [expr {256*[lindex $::spawny $i]-($i<4?497:0)}]
 }
 next_pose
}
proc next_pose {} {
 if {$::index==20} {
  set f [open $::env(KEEN_TEST_OUTPUT)/names.txt w];puts $f [join $::names "\n"];close $f
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS: native Tater movement; original sixteen enemy spawn neighborhoods; Tater, Asparagusto, mouth idle/spit in right/down directions, Tomatooth, Carrot and hostile seed poses captured in actual ROM; no draw-record overflow.";close $f;exit;return
 }
 set i $::index;set a [actor $i]
 set x [expr {256*[lindex $::spawnx $i]}];set y [expr {256*[lindex $::spawny $i]-($i<4?497:0)}]
 if {$i>=16} {set x [expr {65*256}];set y [expr {16*256}]}
 set ::hx [expr {$x-80*16}];set ::hy $y
 if {$i<6} {
  set frame [expr {$i<4?124+$::pose:108+$::pose}]
  if {($i<4 && $::pose==12) || ($i>=4 && $::pose==8)} {set frame 26}
  debug write memory [expr {$a+11}] $frame
  debug write memory [expr {$a+13}] [expr {$frame==26?1:0}]
  putword [expr {$a+2}] [expr {$y-($i>=4 && $frame==26?256:0)}]
 } elseif {$i<9} {
  debug write memory [expr {$::world_collision+1105+$i-6}] [expr {$::pose?10:200}]
 } elseif {$i<15} {
  set frame [expr {$::pose==4?26:90+$::pose}];debug write memory [expr {$a+9}] $frame
 } elseif {$i==15} {putword $a $x;putword [expr {$a+2}] $y;debug write memory [expr {$a+10}] 1;debug write memory [expr {$a+11}] [expr {16+$::pose}]
 } else {
  set a [expr {$::world_collision+444+9*($i-16)}];putword $a $x;putword [expr {$a+2}] $y
  debug write memory [expr {$a+6}] 1;debug write memory [expr {$a+7}] [expr {140+$i-16}]
 }
 set ::frame [expr {$i<6?[byte [expr {[actor $i]+11}]]:($i<9?($i==6?138:136)+$::pose:($i<16?[byte [expr {[actor $i]+($i<15?9:11)}]]:140+$i-16))}]
 after time 1.2 pose_ready
}
proc pose_ready {} {
 if {[byte $::render_commit]} {after time 0.001 pose_ready;return}
 check {![byte [expr {$::world_collision+1118}]]} "Visible actor pool overflow"
 set found 0
 for {set slot 0} {$slot<26} {incr slot} {
  set old [expr {$::actors_old+[byte $::front_page]*174+$slot*6}]
  if {[byte [expr {$old+5}]] && [byte [expr {$old+4}]]==$::frame} {set found 1}
 }
 if {!$found && $::index>=9 && $::index<15} {
  set id [byte [expr {$::world_collision+1164+[byte $::front_page]}]]
  if {($id==($::index-9) || [byte [expr {$::hw_tomato_second+[byte $::front_page]}]]==($::index-9)) && [byte [expr {[actor $::index]+9}]]==$::frame} {set found 1}
 }
 if {!$found} {after time 0.01 pose_ready;return}
 set name "actor-$::index-pose-$::pose";snap $name;lappend ::names $name
 incr ::pose;set i $::index
 set limit [expr {$i<4?13:($i<6?9:($i<9?2:($i<15?5:($i==15?14:1))))}]
 if {$::pose==$limit} {incr ::index;set ::pose 0}
 next_pose
}
set phase 0
# Leave diagnostics and title with normal keyboard input only.
'''
s+=''.join(f'after time {t} {{if {{$::phase==0 && [byte $::world_active]!=1}} {{keys 1;after time 0.3 {{keys 0}}}}}}\n' for t in range(5,36,5))
s+=f'\ndebug set_bp {syms["WorldInput"]&65535} {{[byte $::g_CurrentSegment]==8}} control\n'
s+=f'\ndebug set_bp {syms["ReadInput"]&65535} {{[byte $::g_CurrentSegment]==31}} control\n'
s+=f'\ndebug set_bp {syms["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
s+='after time 400 {check {0} "Timeout phase=$::phase world=[byte $::world_active] x=[word $::world_x]"}\n'
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
with (out/'emulator.log').open('w') as log:
 subprocess.run(['openmsx','-machine',machine,'-cart',str(r/'build/keen_msx.rom'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=240)
assert not (out/'FAIL.txt').read_text().strip(),(out/'FAIL.txt').read_text()
assert (out/'PASS.txt').read_text().startswith('PASS:'),(out/'PASS.txt').read_text()
names=(out/'names.txt').read_text().splitlines()
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
(out/'VERIFIED.txt').write_text(f'PASS: independent full viewport pixel reconstruction for {len(names)} original actor/pose snapshots.\n')
print((out/'PASS.txt').read_text(),(out/'VERIFIED.txt').read_text())
