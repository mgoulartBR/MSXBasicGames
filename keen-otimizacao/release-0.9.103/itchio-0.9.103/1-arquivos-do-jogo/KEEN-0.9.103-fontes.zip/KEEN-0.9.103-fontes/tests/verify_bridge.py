"""Verify exact imported map, rendered background pixels, and world completion patches."""
from pathlib import Path
import json,struct,sys
from PIL import Image
root=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);asset=root/'assets/bridge'
assert (out/'bridge-map.bin').read_bytes()==(asset/'packed_map.bin').read_bytes()
layout=json.loads((asset/'combat_assets.json').read_text());atlas=(asset/'atlas.bin').read_bytes();m=struct.unpack('<4030H',(asset/'map.bin').read_bytes())
pal=[(0,0,0),(0,0,182),(0,182,0),(0,182,182),(182,0,0),(182,0,182),(182,73,0),(182,182,182),(73,73,73),(73,73,255),(73,255,73),(73,255,255),(255,73,73),(255,73,255),(255,255,73),(255,255,255)]
def px(buf,x,y):return (buf[y*128+x//2]>>(0 if x&1 else 4))&15
for name in ('spawn','descent'):
 cx,cy,hx,hy,frame,page,hw=map(int,(out/f'{name}.txt').read_text().split());hx//=16;hy//=16
 v=(out/f'{name}.vram').read_bytes();height=192 if hw else 176
 actual=[];checked=0
 for y in range(height):
  for x in range(256):
   color=px(v,(cx+x)&255 if hw else x,page*256+((cy+y)&255 if hw else y+16));actual.append(pal[color])
   if 192<=x<240 and 4<=y<20:continue
   if hx-4<=cx+x<hx+36 and hy-4<=cy+y<hy+36:continue
   tile=m[((cy+y)//16)*65+(cx+x)//16];tx,ty=layout['tiles'][tile]
   expected=px(atlas,tx+(cx+x)%16,ty+(cy+y)%16)
   assert color==expected,(name,x,y,color,expected,cx,cy)
   checked+=1
 im=Image.new('RGB',(256,height));im.putdata(actual);im.save(out/f'{name}-background.png')
 print(name,checked,'background pixels match')
def unpack(data):return [((data[(i*9)//8]|data[(i*9)//8+1]<<8)>>(i*9%8))&511 for i in range(5610)]
# Last map entry has enough trailing byte in 6312-byte storage.
actual=unpack((out/'world-map.bin').read_bytes());expected=list(struct.unpack('<5610H',(root/'assets/tuberia/map.bin').read_bytes()))
for i,old,new,owner in json.loads((root/'assets/tuberia/manifest.json').read_text())['patches']:
 if owner&4:expected[i]=new
assert actual==expected,'Tuberia completion patch mismatch'
print('PASS: map bytes, displayed background and original Bridge completion patches')
