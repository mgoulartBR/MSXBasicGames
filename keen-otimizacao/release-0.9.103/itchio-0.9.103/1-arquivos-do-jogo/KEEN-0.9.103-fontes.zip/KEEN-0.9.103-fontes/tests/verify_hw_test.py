"""Check actual openMSX screenshots against bitmap controls and VDP tables."""
from pathlib import Path
from PIL import Image
import numpy as np,json,sys
r=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);meta=json.loads((r/'assets/melon/hw_tomato.json').read_text());phases=set();ys=[]
for n in range(0,16,2):
 f=(n//2)%4;expected=np.array(meta['frames'][f]);mask=expected>=0
 a=np.array(Image.open(out/f'hw{n}.png'))[88:120,64:88]
 b=np.array(Image.open(out/f'hw{n+1}.png'))[88:120,64:88]
 assert np.array_equal(a[mask],b[mask]),('Hardware/bitmap opaque pixels differ',n)
 state=(out/f'hw{n}.state').read_bytes();off=(out/f'hw{n+1}.state').read_bytes();regs=(out/f'hw{n}.regs').read_bytes();vram=(out/f'hw{n}.allvram').read_bytes()
 assert state[2]==0 and off[2]==255,(n,state,off)
 assert regs[5]==255 and regs[6]==32 and regs[11]==3
 phases.add(regs[27]);ys.append(regs[23])
 # Decode every pattern/color plane independently, including transparent pixels.
 actual=np.full((32,24),-1);count=meta['entries'][f]
 for i in range(count):
  at=0x1fe00+4*i;y,x,pat,_=vram[at:at+4];dy=(y+1-state[9])&255;dx=x-state[8]
  for yy in range(16):
   color=vram[0x1fc00+i*16+yy]
   for xx in range(16):
    bit=vram[0x10000+pat*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7))
    if not bit:continue
    assert 0<=dy+yy<32 and 0<=dx+xx<24
    if color&64:actual[dy+yy,dx+xx]|=color&15
    else:actual[dy+yy,dx+xx]=color&15
 assert np.array_equal(actual,expected),('VDP data reconstruction mismatch',n)
 assert vram[0x1fe00+count*4]==216
assert phases=={0,2,4,6},phases
assert any(a>b for a,b in zip(ys,ys[1:])),ys
rows=[(float(a),int(b)) for a,b in (line.split()for line in (out/'vblank.txt').read_text().splitlines())]
# Updates begin after VBlank. A 32-line top exclusion protects sprites when
# an animation upload extends into the start of the active picture.
assert max(a for a,b in rows)<5.0,rows
report=f'PASS: 8 hardware/bitmap screenshot pairs; 4 EGA frames; all four even horizontal fine phases; vertical wrap; exact pattern/color reconstruction; max commit {max(a for a,b in rows):.3f} ms at Z80 7.16 MHz.\n'
(out/'PASS.txt').write_text(report);print(report,end='')
