from pathlib import Path
import json,struct,sys
r=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);meta=json.loads((r/'assets/tuberia/manifest.json').read_text());a=(r/'assets/tuberia/atlas.bin').read_bytes();original=list(struct.unpack('<5610H',(r/'assets/tuberia/map.bin').read_bytes()))
def pixel(pattern,x,y):
 if pattern>=512:
  b=(r/'assets/tuberia/extra.bin').read_bytes()[(pattern-512)*128+y*8+x//2];return b&15 if x&1 else b>>4
 x+=(pattern%16)*16;y+=(pattern//16)*16;v=a[y*128+x//2];return v&15 if x&1 else v>>4
for name in sys.argv[2:]:
 wx,wy,frame,cx,cy,done,hw,notice=map(int,(out/f'{name}.txt').read_text().split());m=original.copy()
 if done:
  for i,old,new,flag in meta['patches']:
   if done&flag:m[i]=new
 packed_map=(out/f'{name}.map').read_bytes()+b'\0'
 decoded=[(int.from_bytes(packed_map[(i*9)//8:(i*9)//8+2],'little')>>((i*9)%8))&511 for i in range(5610)]
 assert decoded==m,(name,'complete RAM map')
 expected=[]
 for y in range(176):
  for x in range(256):expected.append(pixel(meta['tiles'][m[((cy+y)//16)*85+(cx+x)//16]],(cx+x)%16,(cy+y)%16))
 mask,col=meta['sprites'][frame];dx=wx-cx;dy=wy-cy
 for y in range(16):
  for x in range(16):
   pos=(dy+y)*256+dx+x;expected[pos]=(expected[pos]&pixel(mask,x,y))|pixel(col,x,y)
 packed=bytes(expected[i]*16+expected[i+1]for i in range(0,len(expected),2));vram=(out/f'{name}.vram').read_bytes()
 if hw:
  raw=bytes(vram[((cy+y)&255)*128+(((cx+x)&255)//2)] for y in range(176) for x in range(0,256,2))
 else:raw=vram[2048:24576]
 header=bytes(vram[((cy-16+y)&255)*128+(((cx+x)&255)//2)] for y in range(16) for x in range(0,256,2)) if hw else vram[:2048]
 assert header==(r/'assets/tuberia/headers.bin').read_bytes()[notice*2048:(notice+1)*2048],(name,'fixed header')
 assert raw==packed,(name,sum(a!=b for a,b in zip(raw,packed)))
 print('PASS:',name,'full world viewport, original tiles/sprite/completion patches')
