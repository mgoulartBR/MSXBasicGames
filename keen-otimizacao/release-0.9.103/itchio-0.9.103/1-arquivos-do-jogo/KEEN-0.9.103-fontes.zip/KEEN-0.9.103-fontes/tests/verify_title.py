from pathlib import Path
import re,sys
r=Path(__file__).resolve().parents[1];p=Path(sys.argv[1]);expected=(r/'assets/title/screen7.bin').read_bytes();actual=(p/'title.vram').read_bytes()
for y in range(212):
 for x in range(0,512,2):
  if 199<=y<210 and 190<=x<322:continue
  i=y*256+x//2;assert actual[i]==expected[i],(x,y)
palette=bytes(map(int,re.search(r'\{([^}]+)',(r/'src/title_palette.h').read_text())[1].split(',')))
assert (p/'title.palette').read_bytes()==palette
s=(r/'src/scene_data.h').read_text();scene=bytes(map(int,re.search(r'scene_palette\[\] = \{([^}]+)',s)[1].strip().rstrip(',').split(',')))
assert (p/'tuberia.palette').read_bytes()==scene
assert (p/'bridge.palette').read_bytes()==scene
print('PASS: every title pixel outside the prompt matches the asset; exact title palette; Tuberia and Bridge restore the gameplay palette.')
