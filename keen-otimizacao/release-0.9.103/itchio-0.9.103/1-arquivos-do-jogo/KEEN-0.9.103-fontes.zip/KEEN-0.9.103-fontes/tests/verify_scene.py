"""Verify mapper content and exact 4bpp pixels from emulated VRAM."""
from pathlib import Path
import json,struct,sys
root=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);scene=root/'assets/scene'
a=(scene/'atlas.bin').read_bytes();m=(scene/'map.bin').read_bytes();rom=(root/'build/keen_msx.rom').read_bytes()
assert rom[0x4000:0x14000]==a, 'ROM atlas packaging'
assert rom[0x14000:0x14000+len(m)]==m, 'ROM map packaging'
assert (out/'atlas-vram.bin').read_bytes()==a, 'ROM bank transfer to VRAM'
meta=json.loads((scene/'scene_manifest.json').read_text());w=meta['width_tiles'];spawnx,spawny=meta['spawn_pixels']
def check_view(file,cx,cy):
    frame=(out/file).read_bytes(); expected=bytearray(176*128)
    for y in range(11):
        for x in range(16):
            tile=struct.unpack_from('<H',m,2*((cy+y)*w+cx+x))[0]
            sx=tile%16*8;sy=tile//16*16
            for line in range(16):
                off=(y*16+line)*128+x*8
                expected[off:off+8]=a[(sy+line)*128+sx:(sy+line)*128+sx+8]
    # All camera steps and spawn X are multiples of 16, so no subbyte shifts.
    dx=spawnx-cx*16;dy=spawny-cy*16
    for y in range(32):
        for x in range(12):
            if 0<=dy+y<176 and 0<=dx//2+x<128:
                idx=(dy+y)*128+dx//2+x
                mask=a[(480+y)*128+x];color=a[(480+y)*128+16+x]
                expected[idx]=(expected[idx]&mask)|color
    actual=frame[16*128:192*128]
    bad=sum(a!=b for a,b in zip(actual,expected))
    assert len(actual)==len(expected) and bad==0, f'{file}: {bad} pixel-byte mismatches'
check_view('spawn-vram.bin',118,24)
cx,cy=map(int,(out/'camera.txt').read_text().split());check_view('scrolled-vram.bin',cx,cy)
print('PASS: exact VRAM atlas (65536 bytes); spawn and scrolled viewports (22528 bytes each).')
