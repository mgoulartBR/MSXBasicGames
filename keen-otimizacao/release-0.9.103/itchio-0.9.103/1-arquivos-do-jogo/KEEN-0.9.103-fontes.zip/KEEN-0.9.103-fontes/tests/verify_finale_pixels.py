"""Compare finale VRAM against exact MSXgl font pixels; also export memory captures.
Raw renderer screenshots can lag the emulated frame, so VRAM is authoritative.
"""
from pathlib import Path
import re,ast,sys
from PIL import Image
r=Path(__file__).resolve().parents[1]
font=Path(sys.argv[1]).read_text(encoding="latin1")
font=re.sub(r'//[^\n]*','',font)
b=bytes(int(v,16)for v in re.findall(r'0x([0-9A-Fa-f]{2})',font[font.index('{'):]))
assert b[:4]==bytes([0x88,0x68,0,191])
source=(r/'src/finale_text.inc').read_text()
texts=[''.join(ast.literal_eval(s)for s in re.findall(r'"(?:[^"\\]|\\.)*"',part))for part in re.findall(r'finale_text_\d\[\]=(.*?);',source,re.S)]
for folder in sorted((r/'build').glob('0941-finale-*')):
 assert (folder/'PASS.txt').exists(),folder
 for page,text in enumerate(texts,1):
  expected=bytearray(256*212)
  def draw(s,x,y):
   for c in s:
    if c=='\n':y+=8;x=12;continue
    glyph=b[4+ord(c)*8:4+(ord(c)+1)*8]
    for row,v in enumerate(glyph):
     for col in range(8):
      if v&(128>>col):expected[(y+row)*256+x+col]=15
    x+=6
  draw('KEEN DREAMS - THE END',16,8);draw(text,12,28)
  if page==3:draw('SCORE: 100000',12,160)
  draw('SPACE / FIRE: NEW GAME' if page==3 else 'SPACE / FIRE: CONTINUE',12,180)
  packed=(folder/f'page-{page}.vram').read_bytes()
  actual=bytearray(v for n in packed for v in (n>>4,n&15))
  assert actual==expected,(folder,page,sum(x!=y for x,y in zip(actual,expected)))
  im=Image.frombytes('L',(256,212),bytes(v*17 for v in actual)).convert('RGB')
  im.save(folder/f'finale-{page}.png')
 (folder/'PIXELS-PASS.txt').write_text('PASS: every pixel in all three 256x212 finale pages matches original epilogue text rendered with the MSXgl bitmap font, including 32-bit score 100000 and input prompts.\n')
 print(folder.name,'all three pages pixel exact: PASS')
