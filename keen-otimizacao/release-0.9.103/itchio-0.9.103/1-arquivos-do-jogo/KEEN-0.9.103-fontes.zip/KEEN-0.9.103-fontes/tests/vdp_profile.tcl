# Non-invasive openMSX profiler. All durations use emulated time.
namespace eval keenprof {
 variable enabled 0
 variable last 0
 variable busy 0
 variable waiting 0
 variable totals [dict create busy 0.0 wait 0.0 both 0.0]
 variable wait_start 0
 variable wait_calls 0
 variable polls 0
 variable stack [dict create]
 variable ret_bps [dict create]
 variable funcs [dict create]
 variable commands [dict create]
 variable command_start 0
 variable command_type 0
 variable wait_sites [dict create]
 variable current_site {}
 variable site_start 0
 variable seq 0
 variable visible_hist [dict create]
 proc frame {} {
  variable enabled;variable visible_hist
  if {!$enabled} {return}
  set base [expr {$::profile_actors+[byte $::profile_front]*156}]
  set n [byte [expr {$base+11}]]
  for {set i 20} {$i<26} {incr i} {incr n [byte [expr {$base+$i*6+5}]]}
  dict incr visible_hist $n
 }
 proc sample {} {
  variable enabled;variable last;variable busy;variable waiting;variable totals
  set now [machine_info time]
  if {$enabled} {
   set dt [expr {$now-$last}]
   foreach {key flag} [list busy $busy wait $waiting both [expr {$busy && $waiting}]] {
    if {$flag} {dict set totals $key [expr {[dict get $totals $key]+$dt}]}
   }
  }
  set last $now
 }
 proc vdp {} {
  variable busy;variable enabled;variable command_start;variable command_type;variable commands
  sample
  set busy [debug probe read VDP.commandExecuting]
  if {!$enabled} {return}
  if {$busy} {
   set command_start [machine_info time]
   set command_type [format %02X [debug read {VDP regs} 46]]
   dict incr commands $command_type,count
  } elseif {$command_start} {
   set key $command_type,time
   if {![dict exists $commands $key]} {dict set commands $key 0.0}
   dict set commands $key [expr {[dict get $commands $key]+[machine_info time]-$command_start}]
   set command_start 0
  }
 }
 proc wait_enter {} {
  variable enabled;variable waiting;variable wait_calls;variable polls
  if {!$enabled} {return}
  if {$waiting} {incr polls;return}
  sample;set waiting 1;incr wait_calls
  variable current_site;variable site_start
  set current_site [format %04X:%02X [word [reg SP]] [byte $::profile_bank]]
  set site_start [machine_info time]
 }
 proc wait_exit {} {
  variable enabled;variable waiting
  if {!$enabled} {return}
  sample;set waiting 0
  variable current_site;variable site_start;variable wait_sites
  if {![dict exists $wait_sites $current_site]} {dict set wait_sites $current_site {0 0.0}}
  lassign [dict get $wait_sites $current_site] count duration
  dict set wait_sites $current_site [list [expr {$count+1}] [expr {$duration+[machine_info time]-$site_start}]]
 }
 proc enter {name} {
  variable enabled;variable stack;variable ret_bps;variable totals
  if {!$enabled} {return}
  sample
  set sp [reg SP];set addr [word $sp];set key $addr,[expr {$sp+2}]
  dict set stack $key [list $name [machine_info time] [dict get $totals wait]]
  if {![dict exists $ret_bps $addr]} {
   dict set ret_bps $addr [debug set_bp $addr {} [list keenprof::returned $addr]]
  }
 }
 proc returned {addr} {
  variable enabled;variable stack;variable funcs;variable totals
  if {!$enabled} {return}
  set key $addr,[reg SP]
  if {![dict exists $stack $key]} {return}
  sample
  lassign [dict get $stack $key] name start wait
  dict unset stack $key
  if {![dict exists $funcs $name]} {dict set funcs $name {0 0.0 0.0}}
  lassign [dict get $funcs $name] count duration blocked
  dict set funcs $name [list [expr {$count+1}] [expr {$duration+[machine_info time]-$start}] [expr {$blocked+[dict get $totals wait]-$wait}]]
 }
 proc begin {scenario} {
  variable enabled;variable totals;variable funcs;variable commands;variable stack;variable waiting;variable busy;variable last;variable wait_calls;variable polls;variable started;variable frames;variable label;variable command_start
  variable wait_sites;set wait_sites [dict create]
  variable visible_hist;set visible_hist [dict create]
  set totals [dict create busy 0.0 wait 0.0 both 0.0];set funcs [dict create];set commands [dict create];set stack [dict create]
  set waiting 0;set wait_calls 0;set polls 0;set command_start 0
  set busy [debug probe read VDP.commandExecuting]
  set started [machine_info time];set last $started;set frames [word $::render_count];set label $scenario;set enabled 1
 }
 proc finish {} {
  variable enabled;variable totals;variable funcs;variable commands;variable wait_calls;variable polls;variable started;variable frames;variable label;variable busy;variable command_start;variable command_type
  sample
  if {$busy && $command_start} {
   set key $command_type,time
   if {![dict exists $commands $key]} {dict set commands $key 0.0}
   dict set commands $key [expr {[dict get $commands $key]+[machine_info time]-$command_start}]
  }
  set enabled 0
  set f [open $::env(KEEN_TEST_OUTPUT)/profile.txt a]
  puts $f [list SCENE $label frequency [set ::z80_freq] locked [set ::z80_freq_locked] seconds [expr {[machine_info time]-$started}] frames [expr {[word $::render_count]-$frames}] totals $totals calls $wait_calls polls $polls]
  dict for {name value} $funcs {puts $f [list FUNCTION $label $name {*}$value]}
  variable visible_hist
  puts $f [list VISIBLE $label $visible_hist]
  variable wait_sites
  dict for {site value} $wait_sites {puts $f [list WAIT_SITE $label $site {*}$value]}
  puts $f [list COMMANDS $label $commands]
  close $f
 }
}
