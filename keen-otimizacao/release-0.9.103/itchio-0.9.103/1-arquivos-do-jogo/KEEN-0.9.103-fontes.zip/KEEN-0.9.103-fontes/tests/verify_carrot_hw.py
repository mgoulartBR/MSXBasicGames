from pathlib import Path
import numpy as np,json,sys
r=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);meta=json.loads((r/'assets/scene/hw_carrot.json').read_text())
for n in range(28):
 state=(out/f'carrot{n}.state').read_bytes();regs=(out/f'carrot{n}.regs').read_bytes();vram=(out/f'carrot{n}.allvram').read_bytes()
 f=state[7];assert f//2==n//2,(n,f)
 count=24 if f&1 else 16
 cb=((regs[11]&3)<<15)|((regs[5]&0xf8)<<7);sat=cb+512;pb=(regs[6]&63)*2048
 expected=np.array(meta['frames'][n//2]);actual=np.full((33,32),-1)
 for i in range(count):
  y,x,pat,_=vram[sat+4*i:sat+4*i+4];assert y!=216
  dy=(y+1-state[9])&255;dx=x-state[8]
  for yy in range(16):
   color=vram[cb+i*16+yy]
   for xx in range(16):
    if not vram[pb+pat*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7)):continue
    assert 0<=dy+yy<33 and 0<=dx+xx<32,(n,i,dy,dx)
    if color&64:actual[dy+yy,dx+xx]|=color&15
    else:actual[dy+yy,dx+xx]=color&15
 exp=np.full((33,32),-1);exp[f&1:(f&1)+32]=expected
 assert np.array_equal(actual,exp),(n,np.count_nonzero(actual!=exp),cb,sat,pb)
 assert vram[sat+count*4]==216
report='PASS: 14 Carrot/flower frames, both Y parities; all uploaded pattern/color/attribute tables reconstruct the adapted sprite exactly.\n'
(out/'PASS.txt').write_text(report);print(report)
# Decode clipped hardware output in screen coordinates, independently of bitmap VRAM.
for n,sx in enumerate([-31,-16,-1,240,255,256,-32,32],28):
 state=(out/f'carrot{n}.state').read_bytes();regs=(out/f'carrot{n}.regs').read_bytes();vram=(out/f'carrot{n}.allvram').read_bytes()
 actual=np.full((256,256),-1);exp=actual.copy();sy=64+n%2
 # R23=0 on standard MSX2; its viewport starts sixteen lines lower.
 isplus=int((out/f'carrot{n}.txt').read_text().splitlines()[0].split()[7]);sy+=0 if isplus else 16
 if not regs[8]&2:
  cb=((regs[11]&3)<<15)|((regs[5]&0xf8)<<7);sat=cb+512;pb=(regs[6]&63)*2048
  for i in range(32):
   y,x,pat,_=vram[sat+i*4:sat+i*4+4]
   if y==216:break
   dy=(y+1-regs[23])&255
   for yy in range(16):
    color=vram[cb+i*16+yy];dx=x-(32 if color&128 else 0)
    for xx in range(16):
     if not vram[pb+pat*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7)):continue
     py=(dy+yy)&255;px=dx+xx
     if not 0<=px<256:continue
     if color&64:actual[py,px]|=color&15
     else:actual[py,px]=color&15
 for yy,row in enumerate(meta['frames'][0]):
  for xx,col in enumerate(row):
   if 0<=sx+xx<256:exp[sy+yy,sx+xx]=col
 # Hidden half-sprites are parked below the 192-line visible display.
 assert np.array_equal(actual[:192],exp[:192]),('clipping',n,np.count_nonzero(actual[:192]!=exp[:192]))
with (out/'PASS.txt').open('a') as f:f.write('PASS: eight horizontal edge cases, including early-clock clipping and wholly offscreen hiding.\n')
print('PASS: horizontal clipping and offscreen hiding.')
