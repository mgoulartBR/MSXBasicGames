#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../../src/world.c"
#include "../../src/tomato.c"
#include "../../src/bridge.c"
#include "../../src/keen_msx_s50_b1.c"
u8 cart_cache_valid;
volatile u16 camera_px,camera_py;
u16 player_x,player_y;
volatile u16 simulation_ticks;
CombatObject enemy,shots[2];
volatile u8 enemy_mode,death_ticks,combat_dirty;
volatile u16 flower_hits,flower_returns,defeats;
static void batch(void){for(int i=0;i<4;i++)BridgeTick();}
int main(int argc,char**argv){
 FILE*f=fopen(argv[1],"rb");assert(f);assert(fread(world_map,1,4534,f)==4534);fclose(f);
 f=fopen(argv[2],"rb");assert(f);assert(fread(world_collision,1,1168,f)==1168);fclose(f);
 active_level=3;BridgeReset();camera_px=400;camera_py=96;BridgeSelect();
 for(int i=0;i<7;i++)assert(!bridge_actors[i].active);
 unsigned char saved[4534];memcpy(saved,world_map,4534);
 for(int i=0;i<5;i++){
  BridgeReset();CombatObject*a=bridge_actors+i;
  assert(a->x==bridge_spawn[i][0]*256 && a->y==(bridge_spawn[i][1]-2)*256+(i<3?15:0));
  camera_px=a->x/16-80;camera_py=a->y/16-80;BridgeSelect();assert(a->active);
  // Walk with Keen well away vertically, on the real map.
  player_x=a->x;player_y=a->y-2048;u16 x=a->x;
  for(int j=0;j<10;j++)batch();fprintf(stderr,"walk %d: %u -> %u y %u dir %d\n",i,x,a->x,a->y,a->dir);assert(a->x!=x);
  // Stand just ahead: wind-up must not kill, active attack must kill.
  player_y=a->y;player_x=a->dir?a->x+432:a->x-304;
  for(int j=0;j<5 && !a->state;j++)batch();assert(a->state==2);assert(!death_ticks);
  for(int j=0;j<10 && !death_ticks;j++)batch();assert(death_ticks);death_ticks=0;
  // Direct projectile contact through the actual hit routine.
  a->state=0;a->frame=BridgeBase(i,a->dir);
  CombatObject shot={0};shot.x=a->x+128;shot.y=a->y+128;shot.active=1;
  assert(BridgeHit(&shot) && !shot.active && a->state==1);
  player_x=a->x;player_y=a->y;
  for(int j=0;j<80;j++)batch();assert(!death_ticks && a->state==1);
  player_y=a->y-2048;for(int j=0;j<8;j++)batch();assert(a->state==0);
  camera_px=0;camera_py=0;BridgeSelect();assert(!a->active);
  x=a->x;for(int j=0;j<8;j++)batch();assert(a->x==x);
 }
 BridgeReset();player_x=60000;player_y=60000;
 for(int i=5;i<7;i++){
  CombatObject*a=bridge_actors+i;a->active=1;a->timer=1;camera_px=a->x/16-80;camera_py=a->y/16-80;
  CombatObject shot={0};shot.x=a->x;shot.y=a->y;shot.active=1;assert(!BridgeHit(&shot));
  batch();assert(a->state==2);
 }
 for(int t=0;t<6;t++)batch();
 assert(bridge_actors[7].active && bridge_actors[8].active);
 assert(bridge_actors[7].vx<0 && bridge_actors[8].vx>0);
 CombatObject*s=bridge_actors+7;player_x=s->x;player_y=s->y;batch();assert(death_ticks);death_ticks=0;
 DrawObject ob[11];BridgeCollect(ob);assert(ob[5].visible && ob[6].visible);
 BridgeReset();for(int i=0;i<11;i++)assert(!bridge_actors[i].active);
 assert(!memcmp(saved,world_map,4534));
 // Other stage map tails must never be overwritten by bridge reset.
 active_level=2;memset(world_map+9600,0x5a,235);BridgeReset();BridgeSelect();BridgeTick();
 for(int i=9600;i<9835;i++)assert(world_map[i]==0x5a);
 active_level=3;death_ticks=0;player_x=player_y=60000;
 // Native mouth state transitions: six windup ticks before each seed.
 for(int i=5;i<7;i++){
  BridgeReset();CombatObject*a=bridge_actors+i;a->active=1;a->timer=1;
  BridgeMelon(a,i);assert(a->state==2 && a->timer==12 && !bridge_actors[7].active);
  for(int n=0;n<5;n++){BridgeMelon(a,i);assert(!bridge_actors[7].active);}
  BridgeMelon(a,i);CombatObject*s=bridge_actors+7;
  assert(a->timer==6 && s->active && s->y==a->y+128 && s->x==a->x+(i==5?384:0));
  assert(s->vy==-20 && (i==5?(s->vx>=-63 && s->vx<=-48):(s->vx>=48 && s->vx<=63)));
  int seen[16]={0};seen[(s->vx<0?-s->vx:s->vx)-48]=1;
  for(int n=0;n<6;n++)BridgeMelon(a,i);assert(a->state==0 && a->timer==200);
  for(int cycle=0;cycle<32;cycle++){
   for(int n=0;n<200;n++)BridgeMelon(a,i);assert(a->state==2 && a->timer==12);
   s->active=0;for(int n=0;n<6;n++)BridgeMelon(a,i);
   assert(s->active);seen[(s->vx<0?-s->vx:s->vx)-48]=1;
   for(int n=0;n<6;n++)BridgeMelon(a,i);assert(a->state==0 && a->timer==200);
  }
  int distinct=0;for(int n=0;n<16;n++)distinct+=seen[n];assert(distinct>8);
 }
 // Expected results derived from original ProjectileReact/bounceangle.
 const int expected[2][7][2]={{{-15,-30},{0,-33},{0,-33},{23,-23},{-30,-15},{-30,-15},{-23,23}},{{15,-30},{30,-15},{30,-15},{23,23},{0,-33},{0,-33},{-23,-23}}};
 for(int right=0;right<2;right++)for(int shape=1;shape<8;shape++){
  CombatObject a={0};a.vx=right?55:-55;a.vy=60;a.active=1;BridgeBounce(&a,shape);
  fprintf(stderr,"bounce %d %d: %d,%d expect %d,%d\n",right,shape,a.vx,a.vy,expected[right][shape-1][0],expected[right][shape-1][1]);assert(a.active && a.vx==expected[right][shape-1][0] && a.vy==expected[right][shape-1][1]);
 }
 CombatObject weak={0};weak.active=1;weak.vx=weak.vy=8;BridgeBounce(&weak,1);assert(!weak.active);
 // The original step applies its 128-unit displacement at the END of smash9.
 BridgeReset();CombatObject*b=bridge_actors+3;b->active=1;for(int n=0;n<32;n++)BridgeWalker(b,3);assert(b->ground);b->state=2;b->tick=33;b->frame=120;
 u16 bx=b->x;for(int n=0;n<6;n++){BridgeWalker(b,3);assert(b->x==bx && b->state==2);}
 BridgeWalker(b,3);assert(b->x==bx && b->state==3 && !b->tick);
 for(int n=0;n<5;n++){BridgeWalker(b,3);assert(b->x==bx && b->state==3);}
 BridgeWalker(b,3);assert(b->x==bx+128 && b->state==0 && !b->tick);
 // One native actor step per simulation tick, independent of render groups.
 BridgeReset();CombatObject*t=bridge_actors;t->active=1;for(int n=0;n<32;n++)BridgeWalker(t,0);assert(t->ground);t->tick=0;
 u16 tx=t->x;for(int n=0;n<9;n++){BridgeTick();assert(t->tick==n+1 && t->x==tx);}BridgeTick();assert(!t->tick && t->x==tx+128);
 // No artificial four-second expiration: park a seed in an empty real-map cell.
 BridgeReset();int cell=-1;
 for(int n=0;n<65*62;n++)if(!Wall(n%65,n/65,0) && !Wall(n%65,n/65,1) && !Wall(n%65,n/65,2) && !Wall(n%65,n/65,3)){cell=n;break;}
 assert(cell>=0);CombatObject*live=bridge_actors+7;live->active=1;live->timer=1;live->dir=0;
 camera_px=cell%65*16;camera_py=cell/65*16;
 for(int n=0;n<400;n++){live->x=cell%65*256+32;live->y=cell/65*256+32;live->vx=live->vy=0;BridgeSeed(live);assert(live->active && live->timer==1 && (live->frame==142 || live->frame==143));}
 puts("PASS: windup and 212-tick cycles, left/right origins and varied speeds, all seven slope reflections and exhaustion, six-tick Brocco recovery, exact native logic cadence, seeds survive beyond obsolete TTL.");
 puts("PASS: original seven spawns; real-map walking; attack-only damage; flowers/recovery; distant sleep; melon immunity, left/right seeds and damage; render records; reset; map isolation.");
}

void PassReset(void){} void PassSelect(void){} void PassTick(void){} u8 PassHit(CombatObject* a){return 0;} void PassObjectsTick(void){}

volatile u8 hardware_scroll;
void CityFrenchTick(CombatObject* a){}
void CityFriesTick(void){}

#include "grove_stubs.inc"

#include "bay_stubs.inc"

#include "swamp_stubs.inc"

#include "boobus_stubs.inc"
