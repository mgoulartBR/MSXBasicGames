"""Controlled crowded enemy views: four background slots, overlaps and wrap.
This changes fixture positions; it is a correctness test, never an FPS result.
"""
from pathlib import Path
import re,os,subprocess,sys
r=Path(__file__).resolve().parents[1];out=r/'build/0954-cache-overlap';out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
s=(r/'build/0954-scroll-edges/test.tcl').read_text().replace('edge$::index','crowded$::index')
s=s.replace('set positions ', 'set positions ')
s=s.replace('proc camera {} {','''proc crowd {} {
 if {!$::active} {return}
 debug write memory $::enemy_mode 1
 for {set i 0} {$i<6} {incr i} {debug write memory [expr {$::session+$i*16+10}] 0}
 for {set i 0} {$i<3} {incr i} {debug write memory [expr {$::world_collision+1108+$i}] 0}
 for {set i 0} {$i<6} {incr i} {
  set a [expr {$::world_collision+1026+$i*13}]
  putword $a [expr {(1130+$i*18+($::index&1))*16}]
  putword [expr {$a+2}] [expr {(280)*16}]
  debug write memory [expr {$a+8}] 1
  debug write memory [expr {$a+9}] [expr {90+($::index%4)}]
 }
 if {$::index>=34} {debug write memory [expr {$::world_collision+1130}] 3}
}
set merges 0
proc merge_probe {} {incr ::merges;set f [open $::env(KEEN_TEST_OUTPUT)/merge-count.txt w];puts $f $::merges;close $f}
set extended_saves 0
set extended_restores 0
proc clean_probe {} {
 if {!$::active || [reg L]<2} {return}
 if {[byte [expr {[reg SP]+4}]]} {incr ::extended_restores} else {incr ::extended_saves}
 set f [open $::env(KEEN_TEST_OUTPUT)/cache-counts.txt w]
 puts $f "$::extended_saves $::extended_restores";close $f
}
proc camera {} {''')
a=sym['MinesCollect'];s+=f'\ndebug set_bp {a&65535} {{[byte $::g_CurrentSegment]=={a>>16}}} crowd\n'
lst=(r/'src/out/keen_msx_s114_b1.lst').read_text();address=int(re.search(r'([0-9A-F]{8})\s+\d+ _CleanCopy:',lst)[1],16)+0x8000
lines=lst.splitlines();idx=next(i for i,l in enumerate(lines)if ';' in l and 'a->l=nl;a->t=nt' in l);ma=int(next(re.match(r'\s+([0-9A-F]{8})',l)[1]for l in lines[idx+1:]if re.match(r'\s+([0-9A-F]{8})',l)),16)+0x8000
s+=f'\ndebug set_bp {ma} {{[byte $::g_CurrentSegment]==114}} merge_probe\n'
s+=f'\ndebug set_bp {address} {{[byte $::g_CurrentSegment]==114}} clean_probe\n'
(out/'test.tcl').write_text(s)
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out),KEEN_STAGE='2')
with (out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r.parent/'audit0956/K0956T3.ROM'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,check=True,timeout=90)
names=[f'crowded{i}' for i in range(68)]
subprocess.run([sys.executable,str(r/'tests/verify_game_pixels.py'),str(out),*names],env=env,check=True)
saves,restores=map(int,(out/'cache-counts.txt').read_text().split());assert saves>0 and restores>0,(saves,restores)
merges=int((out/'merge-count.txt').read_text());assert merges>0
print('PASS: 68 crowded views; extra slots saves/restores',saves,restores,'overlap merges',merges)
