"""Execute ROM Wall for every in-map cell/side in all three original maps.
Independent packed-map oracle; includes boundaries and real gameplay queries.
Usage: test_wall_z80.py label ROM MAP LISTING
"""
from pathlib import Path
import sys,re,os,subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];label=sys.argv[1];rom=Path(sys.argv[2]).resolve();mp=Path(sys.argv[3]);lst=Path(sys.argv[4]).read_text()
syms={n:int(a,16) for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',mp.read_text(),re.M)}
wall=0x8000+int(re.search(r'([0-9A-F]{8})\s+\d+ _Wall:',lst)[1],16)
out=r/'build'/('wall-z80-'+label);out.mkdir(exist_ok=True);count=0
for stage in ['scene','melon','bridge','fallback']:
 asset_stage='scene' if stage=='fallback' else stage
 m=(r/f'assets/{asset_stage}/packed_map.bin').read_bytes();p=bytearray((r/f'assets/{asset_stage}/stage_data.bin').read_bytes())
 if stage=='fallback':p[1120]=67;p[1121]=3;(out/'fallback.map').write_bytes(m);(out/'fallback.props').write_bytes(p)
 w,h=p[1120:1122]
 queries=[(x,y,side) for y in range(h) for x in range(w) for side in range(4)]
 queries += [(x,y,side) for x,y in [(w,0),(0,h),(255,0),(0,255),(255,255),(w,h)] for side in range(4)]
 # A real-frame query sequence, identical for reference and candidate.
 for f in (r/'build/pauses-0926-batches-crowded-3579545-fire-v3-deep/wall.csv',):
  if stage=='melon' and f.exists():
   import csv
   queries += [(int(q['x']),int(q['y']),int(q['side'])) for q in csv.DictReader(f.open())]
 with (out/(stage+'.queries')).open('w') as f:
  for x,y,side in queries:
   if x>=w or y>=h:value=1
   else:
    i=y*w+x;n=i+(i>>3);tile=((m[n]|m[n+1]<<8)>>(i&7))&511;value=p[352+p[tile]*4+side]
   f.write(f'{x} {y} {side} {value}\n')
 # Exercise live edits at the same queried coordinate, including each bit offset.
 with (out/(stage+'.queries')).open('a') as f:
  for x in range(8):
   y=1;i=y*w+x;n=i+(i>>3);shift=i&7
   tile=(x*37)%min(292,len(p[:352]));v=m[n]|m[n+1]<<8;v=(v&~(511<<shift))|(tile<<shift)
   for side in range(4):f.write(f'{x} {y} {side} {p[352+p[tile]*4+side]} {n} {v&255} {v>>8}\n')
 count+=len(queries)+32
s='\n'.join(f'set sym({k}) {v}' for k,v in syms.items())+f'\nset wall_addr {wall}\nset project {{{r}}}\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
proc byte {a} {return [debug read memory $a]}
proc word {a} {return [expr {[byte $a]+256*[byte [expr {$a+1}]]}]}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
proc fail {msg} {set f [open $::env(KEEN_TEST_OUTPUT)/FAIL.txt w];puts $f $msg;close $f;exit}
set started 0
set stages {scene melon bridge fallback}
set stage_index -1
set count 0
set seconds 0
proc next_stage {} {
 incr ::stage_index
 if {$::stage_index==4} {
  set f [open $::env(KEEN_TEST_OUTPUT)/PASS.txt w];puts $f "PASS $::count $::seconds";close $f;exit
 }
 set ::stage [lindex $::stages $::stage_index]
 foreach {file addr} [list packed_map.bin $::sym(world_map) stage_data.bin $::sym(world_collision)] {
  if {$::stage=="fallback"} {set path $::env(KEEN_TEST_OUTPUT)/fallback.[expr {$file=="packed_map.bin"?"map":"props"}]} else {set path $::project/assets/$::stage/$file}
  set f [open $path rb];debug write_block memory $addr [read $f];close $f
 }
 set ::queries [open $::env(KEEN_TEST_OUTPUT)/$::stage.queries r]
}
proc next_query {} {
 if {[gets $::queries line]<0} {close $::queries;next_stage;gets $::queries line}
 lassign $line ::qx ::qy ::side ::expected
 if {[llength $line]>4} {lassign [lrange $line 4 end] n low high;debug write memory [expr {$::sym(world_map)+$n}] $low;debug write memory [expr {$::sym(world_map)+$n+1}] $high}
 reg SP $::call_sp;putword $::call_sp $::ret
 debug write memory [expr {$::call_sp+2}] $::side
 reg A $::qx;reg L $::qy
 set ::ix [reg IX];set ::iy [reg IY]
 reg PC $::wall_addr
 set ::start_time [machine_info time]
}
proc finish {} {
 if {[reg A]!=$::expected} {fail "$::stage query $::count ($::qx,$::qy,$::side): [reg A] != $::expected"}
 if {[reg IX]!=$::ix || [reg IY]!=$::iy} {fail "index register corrupted"}
 set ::seconds [expr {$::seconds+[machine_info time]-$::start_time}]
 incr ::count
 next_query
}
proc start {} {
 if {$::started} {return}
 set ::started 1;set ::call_sp [reg SP];set ::ret [word $::call_sp]
 debug set_bp $::ret "\[reg SP\]==[expr {$::call_sp+3}]" {finish}
 next_stage;next_query
}
debug set_bp $wall_addr {[byte $sym(active_level)]==2 && [byte $sym(g_CurrentSegment)]==7} {start}
after time 25 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 28 {keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 40 {putword $::sym(world_x) 608;putword $::sym(world_y) 448;keymatrixdown 8 1;after time 0.3 {keymatrixup 8 1}}
after time 110 {fail "timeout"}
'''
(out/'test.tcl').write_text(s);(out/'PASS.txt').write_text('PENDING');(out/'FAIL.txt').write_text('')
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with (out/'emulator.log').open('w') as f:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(rom),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=f,stderr=f,timeout=150,check=True)
assert not (out/'FAIL.txt').read_text(),(out/'FAIL.txt').read_text()
parts=(out/'PASS.txt').read_text().split();assert parts[0]=='PASS' and int(parts[1])==count,parts
result=dict(queries=count,seconds=float(parts[2]),sha256=hashlib.sha256(rom.read_bytes()).hexdigest())
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(label,result)
