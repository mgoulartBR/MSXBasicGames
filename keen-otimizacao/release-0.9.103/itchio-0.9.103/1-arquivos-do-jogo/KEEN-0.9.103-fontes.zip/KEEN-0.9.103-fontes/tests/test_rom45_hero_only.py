"""Exercise front-page hardware-only presentation in an isolated quiet scene.
Enemy suppression and controlled hero motion are a correctness fixture, not a performance measurement.
"""
from pathlib import Path
import os,re,subprocess,json
import numpy as np
r=Path(__file__).resolve().parents[1];out=r/'build/0945-hero-only';out.mkdir(exist_ok=True)
sym={n:int(a,16)for a,n in re.findall(r'^\s+([0-9A-F]{8})\s+_(\w+)\s+',(r/'build/keen_msx.map').read_text(),re.M)}
s='\n'.join(f'set {n} {a}'for n,a in sym.items())+'\n'
s+=r'''
set throttle off
set save_settings_on_exit false
set renderer SDL
set sound_driver null
set z80_freq_locked false
set z80_freq 10738635
set too_fast_vram_access ignore
set measuring 0
set count 0
proc byte {a} {debug read memory $a}
proc word {a} {expr {[byte $a]+256*[byte [expr {$a+1}]]}}
proc putword {a v} {debug write memory $a [expr {$v&255}];debug write memory [expr {$a+1}] [expr {($v>>8)&255}]}
proc fixture {} {
 if {!$::measuring} {return}
 putword $::player_x [expr {(1232+([word $::simulation_ticks]&15))*16}]
 putword $::player_y 4608
 putword $::player_vx 0;putword $::player_vy 0
 debug write memory $::climbing 1
 debug write memory $::combat_dirty 1
}
proc check {} {
 if {[byte $::scene_ready]!=165 || [byte $::active_level]!=2} {keymatrixdown 8 1;after time 0.1 {keymatrixup 8 1;after time 0.2 check};return}
 keymatrixup 8 255
 debug write memory $::enemy_mode 2
 after time 0.7 {set ::measuring 1;}
 after time 1.5 {keymatrixup 8 255}
 after time 2.2 {keymatrixup 8 255}
 after time 2.6 {keymatrixup 8 255;}
 after time 3.5 {keymatrixup 8 255;exit}
}
proc capture {} {
 if {!$::measuring || [byte $::actors_partial]!=3} {return}
 set n $::count;incr ::count
 foreach {suffix device start size} [list vram VRAM 0 131072 regs {VDP regs} 0 64 hw memory [expr {$::world_collision+1128}] 23] {
  set f [open $::env(KEEN_TEST_OUTPUT)/fast$n.$suffix wb];puts -nonewline $f [debug read_block $device $start $size];close $f
 }
}
after time 1 check
after time 30 {exit}
'''
s+=f'\ndebug set_bp {sym["HWFlip"]&65535} {{[byte $::g_CurrentSegment]==21}} capture\n'
s+=f'debug set_bp {sym["InventoryTick"]&65535} {{[byte $::g_CurrentSegment]==7}} fixture\n'
(out/'test.tcl').write_text(s)
for f in out.glob('fast*'):f.unlink()
env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',KEEN_TEST_OUTPUT=str(out))
with (out/'emulator.log').open('w')as log:subprocess.run(['openmsx','-machine','C-BIOS_MSX2+','-cart',str(r.parent/'deliverables0945/K945T3.ROM'),'-romtype','ASCII16','-script',str(out/'test.tcl')],env=env,stdout=log,stderr=log,timeout=90,check=True)
hero=json.loads((r/'assets/scene/hw_hero.json').read_text())['frames'];counts=json.loads((r/'assets/melon/hw_compact_hero.json').read_text())['counts']
def decode(vram,regs,start,count,x0,y0,width,height):
 cb=((regs[11]&3)<<15)|((regs[5]&0xf8)<<7);sat=cb+512;pb=(regs[6]&63)*2048
 image=np.full((height,width),-1)
 for i in range(start,start+count):
  y,x,p,_=vram[sat+i*4:sat+i*4+4]
  dy=(y+1-y0)&255;dx=x-x0
  for yy in range(16):
   color=vram[cb+i*16+yy]
   for xx in range(16):
    if not vram[pb+p*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7)):continue
    assert 0<=dy+yy<height and 0<=dx+xx<width,(i,dy,dx,yy,xx)
    if color&64:image[dy+yy,dx+xx]|=color&15
    else:image[dy+yy,dx+xx]=color&15
 return image

files=list(out.glob('fast*.hw'));assert files,'Hardware-only path was not exercised'
positions=set()
for p in files:
 name=p.stem;hw=p.read_bytes();f=hw[7];positions.add((hw[8],hw[9]))
 actual=decode((out/(name+'.vram')).read_bytes(),(out/(name+'.regs')).read_bytes(),0,counts[f],hw[8],hw[9],32,33)
 expected=np.full((33,32),-1);expected[f&1:(f&1)+32]=hero[f//2]
 assert np.array_equal(actual,expected),(name,np.count_nonzero(actual!=expected))
assert len(positions)>1,positions
(out/'PASS.txt').write_text(f'PASS: {len(files)} hardware-only moving hero presentations reconstruct exact pixels at {len(positions)} positions. Quiet-scene correctness fixture, not gameplay FPS.\n')
print((out/'PASS.txt').read_text())
