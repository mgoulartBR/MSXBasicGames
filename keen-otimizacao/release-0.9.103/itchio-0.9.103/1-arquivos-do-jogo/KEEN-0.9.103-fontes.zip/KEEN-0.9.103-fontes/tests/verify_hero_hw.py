from pathlib import Path
import numpy as np,json,sys
r=Path(__file__).resolve().parents[1];out=Path(sys.argv[1]);meta=json.loads((r/'assets/scene/hw_hero.json').read_text())
for n in range(56):
 state=(out/f'hero{n}.state').read_bytes();regs=(out/f'hero{n}.regs').read_bytes();vram=(out/f'hero{n}.allvram').read_bytes()
 f=state[7];assert f//2==n//2,(n,f)
 count=24 if f&1 else 16
 cb=((regs[11]&3)<<15)|((regs[5]&0xf8)<<7);sat=cb+512;pb=(regs[6]&63)*2048
 expected=np.array(meta['frames'][n//2]);actual=np.full((33,32),-1)
 for i in range(count):
  y,x,pat,_=vram[sat+4*i:sat+4*i+4];assert y!=216
  dy=(y+1-state[9])&255;dx=x-state[8]
  for yy in range(16):
   color=vram[cb+i*16+yy]
   for xx in range(16):
    if not vram[pb+pat*8+yy+(16 if xx>=8 else 0)]&(128>>(xx&7)):continue
    assert 0<=dy+yy<33 and 0<=dx+xx<32,(n,i,dy,dx)
    if color&64:actual[dy+yy,dx+xx]|=color&15
    else:actual[dy+yy,dx+xx]=color&15
 exp=np.full((33,32),-1);exp[f&1:(f&1)+32]=expected
 assert np.array_equal(actual,exp),(n,np.count_nonzero(actual!=exp),cb,sat,pb)
 assert vram[sat+count*4]==216
report='PASS: 28 Keen frames, both Y parities; all uploaded pattern/color/attribute tables reconstruct the adapted sprite exactly.\n'
(out/'PASS.txt').write_text(report);print(report)
